def send_notifcation(notification_payload):
    print(notification_payload)
    