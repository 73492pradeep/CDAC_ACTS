class DESD:
    def __init__(self, name,age, favourite_subject):
        self.name = name
        self.age = age
        self.favourite_subject = favourite_subject
    def display_details(self):
        print("name: ",self.name)
        print("age: ",self.age)
        print("favourite_subject: ",self.favourite_subject)
    def get_subject(self,favourite_subject):
        return f"{self.name} favourite subject is {favourite_subject}"
        

desd = DESD("Surya",21,("RTOS","Device driver"))
desd.display_details()
print(desd.get_subject(["test1","test2"]))
