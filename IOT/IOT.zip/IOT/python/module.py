from math_lib import *
import math_lib as math
print(math.add(90,80))
print(math.sub(20,10))
