#!/usr/bin/python3.8

# Don't touch this program make new file

student_list = ("x","y","z") #tuple object
student_list_1 = ["x","y","z"] # list
print(type(student_list))
print(student_list)
student_list_1[1] = "m"
print(student_list_1)
#student_list[1] =  "m"  # TypeError: 'tuple' object does not support item assignment