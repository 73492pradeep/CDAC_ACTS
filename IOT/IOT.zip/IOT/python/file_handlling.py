fd = open("desd_iot.txt", 'r')
for line in fs:
    if "12" in line:
        print(line,end=" ")
    else:
        print("No")
        