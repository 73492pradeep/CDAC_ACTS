#!/usr/bin/python3.8

# Don't touch this program make new file
# Did't resolved write now
def user_input():
    number1 = int(input ( "Enter the number 1 : "))
    number2 = int(input ( "Enter the number 2 : "))
    output = number1 / number2
    print(output)
max_user_attempt = 3
user_attempt = 0

try:
    #number1 = input ( "Enter the number 1 : ")
    #number2 = input ( "Enter the number 2 : ")
    #output = number1 / number2
    #print(output)
    user_input()

#except Exception as e:
except TypeError as e:
    #number1 = int(number1)
    #number2 = int (number2)
    #output = number1 / number2
    #print(output)
    print(e)
    print("Data type is wrong")
except Exception as e:
    user_attempt = +1
    print(e)
    print("Only integer values are allowed")
    while True:
        if user_attempt == max_user_attempt:
            break
        else:
            user_input()