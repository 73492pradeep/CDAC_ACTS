#!/usr/bin/python3.8
#Display

# Don't touch this program make new file

"""
How to display name 
print("HelloWorld")
print("PG-DESD")
---> Moves the cursor to newline by default
"""
address="""Pradeep vishwakarma"""
print("This is my first program in Python", end=" ")
print("Today", end=" ")
print("is", end=" ")
print("Thuresday", end="\n")
print(f"{address}")