with open ("student_list.txt","r") as stu:
    student_list = stu.readlines()
    for student in student_list:
        student_name_with_space_list = student_name_list.split()
        print(student_name_with_space_list)