def usr_input():
    try:
        max_user_ttempt = 3
        global user attempt
        user_attempt = usr_attempt + 1
        number1 = int(input ("Enter Number 1 : "))
        number2 = int(input ("Enter Number 2 : "))
        output =  number1 // number2
        print(output)
        except Exception as e:
            while user_attempt !=max_user_attempt:
                remaining_user_attempt = max_user_attempt - user
                print("Attempt Remaining : ",remaining_user_attempt)
                user_input()
                

    try:
        user_attempt = 0
        user_input()
        except Exception as e:
            #printf(e)
        print("on;ly integer values are allowed")
        print("exception block user_attempt = " user_attempt)
                