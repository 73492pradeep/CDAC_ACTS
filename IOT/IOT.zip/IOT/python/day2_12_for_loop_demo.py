#!/usr/bin/python3.8
# Don't touch this program make new file
"""

start from 5 and end with 1

"""
#====================================================================

#for count in range(10,3,-2):
#    print(count)

print("Hello ",end="")
print("World")
#====================================================================

"""

*
* *
* * *
* * * *

"""
#=====================================================================

n = 4
for i in range(0,n):
    for j in range(0, i+1):
        print("*",end=" ") # If you want to sepret the line end="space" will help
    print()
