#!/usr/bin/python3

# Don't touch this program make new file

number = '12'
print(type(number))
val_num = int(number)
print(type(val_num))

def add_two_number(num1, num2):
    return num1+num2

print(add_two_number(40, 30))
sum = add_two_number(30, 40)
print(sum)

def desd_class_room_device_status(
    device_status_value
):
    if device_status_value == 0:
        return True
    elif device_status_value == 1:
        return False
    else:
        return "Invalid Payload"

def Vishwakarma(var):
    if var == 5:
        return True
    elif var == 4:
        return False
    else:
        "Invalid Payload 1!"

# calling the function from here
var = desd_class_room_device_status(0)
print(var)

print(Vishwakarma(5))

# user input
device_action = int(input("Enter the command 1 -> True ON, 0-> OFF "))
if(desd_class_room_device_status(device_action)):
    print("Device is online")
else:
    print("Device is offline")

a = str(input("Enter the name "))
print(a,end=" ")
b = str(input("Enter the branch "))
print(b,end=" ")
c = int(input("Enter the Roll "))
print(c,end=" ")

list_of_numbers = []
print(id(list_of_numbers))
for num in range(1, 11):
    print(num)
    list_of_numbers.append(num)
print(list_of_numbers)
list_of_numbers.reverse()
print(id(list_of_numbers))
print(list_of_numbers)
for reverse_value in list_of_numbers:
    print(reverse_value)
