#!/usr/bin/python3.8

# Don't touch this program make new file

list_of_fruits = []
for count in range(3):  # count till range
    fruit = input(f"Enter the fruit[{count}] : ") # it will accept the input
    list_of_fruits.append(fruit)  # It will store the hole input whatever user give input (append)

for fruit in list_of_fruits:  
    if fruit == "Apple":
        print("Apple found Leaving")
        break
    elif fruit == "Banana":
        print("Banana found Ignoring")
        continue
    elif fruit == "Guava":
        print("Its tasty")
    else:
        pass