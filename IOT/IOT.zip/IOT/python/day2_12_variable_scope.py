#!/usr/bin/python3.8

# Don't touch this program make new file

number = 7 
def change_value(num):
    global number
    #number = 8
    number = num
    print(number)
change_value(10)
print(number)