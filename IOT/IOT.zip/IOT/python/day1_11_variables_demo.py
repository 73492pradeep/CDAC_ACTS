#!/usr/bin/python3

# Don't touch this program make new file

"""
you want to run a python program as a script

1.Write shebang -> interpreter pathshebang -> interpreter path
2.Give executable permission {chmod 700 (filename.py)
3.Run it 

./filename.py

Default way:

python/python3 <filename.py>

Style guide for Python : 

https://peps.python.org/pep-0008/

"""

#Integer
num_int = 20
#Float
num_float = 56.5555

status_of_led = True
status_of_motor = False

name = "Pradeep vishwakarma"
subject_name = "DESD"
address = """Panchwati Pasan"""

print(f"Value of num_int is {num_int} and is type of", type(num_int))
print(f"Value of num_float is {num_float} and is type of", type(num_float))
print(num_int)
print(f"The address {address} is of type", type(address))
print(f"Status_of_led {status_of_led}")
print(f"Value of address {subject_name} is of type", type(subject_name))
print(f"Status of led { status_of_motor}")
print(name)







