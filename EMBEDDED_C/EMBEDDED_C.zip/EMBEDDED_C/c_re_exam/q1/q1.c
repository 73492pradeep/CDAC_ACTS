// there is the hearder file
#include <stdio.h>
#include <stdio_ext.h>
#include <string.h>
#include <stdlib.h>

// micro define
#define BEGAIN int main(){
#define END return 0;}

// function decleration
void remove_digit_and_special();
void remove_space();

// main function start execution from here
BEGAIN 
      
       int choice;
       FILE *fp = fopen ( "file.txt","w");     // it will open the file in write mode
       if (fp == NULL){
	       printf("There is error in opening file\n");
	       exit(0);
       }
       char *str = NULL;
       str = (char *)malloc(100*sizeof(char));   // memory is allocated in heap section
       if (str == NULL){
	       printf("Memory is not allocated\n");
	       exit(0);
       }
       printf("Enter the string with special and space : ");
       __fpurge(stdin);
       scanf("%[^\n]s",str);                      //user scan the string with speceial character
       fwrite(str, strlen(str), 1, fp);           //user will writer the string in file
       free(str);                                 //free the dynamic memory
       fclose(fp);                                // closing the file
       while(1){
	       printf("\n1-> remove digit\n2-> remove space\n0-> exit\nEnter the choice : ");
	       scanf("%d",&choice);
	       switch(choice){
		       case 1:
			       remove_digit_and_special();  // call the remove digit and special character
			       break;
		       case 2:
			       remove_space();              // call remove space from file
			       break;
		       case 0:
			       printf("closing the program\n");
			       exit(0);
		       default:
			       printf("You have entered wrong choice\n");
	       }
       }
END
//main function is end

// function difinition
// it will remove special char
void remove_digit_and_special()
{
	FILE *fp1;
	fp1 = fopen ("file.txt","r");           // file will open in read mode
       if (fp1 == NULL){
	       printf("There is error in opening file\n");
	       exit(0);
       }
       char *str1;
       str1 = (char *)malloc(100*sizeof(char)); // user allocated the memory in heap section
       if (str1 == NULL){
	       printf("Memory is not allocated\n");
	       exit(0);
       }
       char ch;
       int i = 0;
       while((ch = fgetc(fp1)) != EOF){         
	       if ((ch >= 'a' && ch <= 'z' || ch >= 'A' && ch <= 'Z') || ch == ' '){  // here it will remove special char
		       str1[i] = ch;
		       i++;
	       }
       }
       str1[i] = '\0';
       printf("The str with space : %s\n",str1);
       fclose(fp1);                             // after reading we close the file
       FILE *fp2;
       fp2 = fopen ("file.txt","w+");           // and writing in file we open in w+ mode
       if (fp2 == NULL){
	       printf("There is error in opening file\n");
	       exit(0);
       }
       fwrite(str1, strlen(str1), 1, fp2);      //here user will write in file after removing the space
       free(str1);                              //free the memory in heap section
       fclose(fp2);                             //and close the file
}
// function definition
// it wil remove the space
void remove_space()
{
	FILE *fp3;
	fp3 = fopen ("file.txt","r");   // user reopen the file in read mode
       if (fp3 == NULL){
	       printf("There is error in opening file\n");
	       exit(0);
       }
       char *str2;
       str2 = (char *)malloc(100*sizeof(char));  //memory allocated in heap section for storing the data from file
       if (str2 == NULL){
	       printf("Memory is not allocated\n");
	       exit(0);
       }
       char ch;
       int i = 0;
       while((ch = fgetc(fp3)) != EOF){
	       if (ch >= 'a' && ch <= 'z' || ch >= 'A' && ch <= 'Z'){
		       str2[i] = ch;
		       i++;
	       }
       }
       str2[i] = '\0';
       printf("The str without space : %s\n",str2);
       fclose(fp3);                              // close the file
       FILE *fp4;
       fp4 = fopen ("file.txt","w+");            //again reopen the file in w+ mode for writing
       if(fp4 == NULL){
	       printf("There is error in opening file\n");
       }
       fwrite(str2, strlen(str2), 1, fp4);       //user write the data
       free(str2);                               //free heap section memory
       fclose(fp4);                              //and finaly closed file
}
