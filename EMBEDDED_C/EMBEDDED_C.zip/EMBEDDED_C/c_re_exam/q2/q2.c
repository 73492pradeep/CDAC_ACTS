// header files
#include <stdio.h>
#include <stdlib.h>
#include <stdio_ext.h>
//structure decleration
struct book{
	char book_author[15];
	int book_isbn;
	int book_id;
	char book_title[15];
	char book_type[15];
};
int c = 0;
//function decleration
void add_data(struct book var[]);
void search_data(struct book var[]);
void display_data(struct book var[]);
//start main function
int main()
{
	int n,choice;
	printf("Enter : how many data you want to store : ");
	scanf("%d",&n);
	struct book var[n];
	while(1){                // loop will run till press 0
		printf("\n1-> add_data\n2-> search_data\n3-> display_data\n0-> exit\nEnter the choice : ");
		scanf("%d",&choice);
		switch(choice){  // switch case will help to chose the function
			case 1:
				add_data(var);          // call add function
				break;
			case 2:
				search_data(var);      // call search function
				break;
			case 3:
				display_data(var);     // call display function
				break;
			case 0:
				printf("closing the program\n");
				exit(1);
		}
	}
	return 0;
}
// function definition
// it will add data
void add_data(struct book var[])
{ 
	int id;
	printf("Enter the book author      : ");
	__fpurge(stdin);
	scanf("%[^\n]s",var[c].book_author);
	printf("Enter the book isbn        : ");
	scanf("%d",&var[c].book_isbn);
        level:
	printf("Enter the book id          : ");
	scanf("%d",&id);
	if(id>=100&&id<=999){                         // if user will enter the less than or greater than 'three' digit it will goto level again
		var[c].book_id = id;
	}else{
		printf("Enter the three digit number\n");
		goto level;
	}
	printf("Enter the book title       : ");
	__fpurge(stdin);
	scanf("%[^\n]s",var[c].book_title);
	printf("Enter the book type        : ");
	__fpurge(stdin);
	scanf("%[^\n]s",var[c].book_type);
	c++;
}
// function definition
// it will search data
void search_data(struct book var[])
{
	int id;
	printf("Enter the book id for search : ");
	scanf("%d",&id);
	for(int i=0;i<=c;i++){
		if(var[i].book_id == id){            // if data is found it will print and stop
			printf("==========Your data is presented here ==========\n");
		        printf("\n\tThe book author   is  : %s\n",var[i].book_author);
		        printf("\n\tThe book isbn     is  : %d\n",var[i].book_isbn);
		        printf("\n\tThe book id       is  : %d\n",var[i].book_id);
		        printf("\n\tThe book title    is  : %s\n",var[i].book_title);
		        printf("\n\tThe book type     is  : %s\n",var[i].book_type);
			break;
		}
	}
}
// function definition
// it will desplay all list
void display_data(struct book var[])
{
	for(int i=0;i<c;i++){
		printf("==========Data is presented here ==========\n");
	        printf("\n\tThe book author   is  : %s\n",var[i].book_author);
	        printf("\n\tThe book isbn     is  : %d\n",var[i].book_isbn);
                printf("\n\tThe book id       is  : %d\n",var[i].book_id);
		printf("\n\tThe book title    is  : %s\n",var[i].book_title);
		printf("\n\tThe book type     is  : %s\n",var[i].book_type);
	}
}

			
