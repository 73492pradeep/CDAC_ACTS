#include<stdio.h>
#include <stdlib.h>
int num1,num2;
int add();
int sub();
int multi();
int divid();
int main()
{
   int choice,x;
   printf("1 - Addition : \n");
   printf("2 - Substraction : \n");
   printf("3 - Multiplication : \n");
   printf("4 - Division : \n");
   while(1){
         printf("Enter your choice : \n");
         scanf("%d",&choice);
         switch(choice){
                        case 1:
                               x=add();
                               break;
                        case 2:
                               x=sub();
                               break;
                        case 3:
                               x=multi();
                               break;
                        case 4:
                               x=divid();
                               break;
                        case 0:
                               exit(0);
         }
         printf("The result is = %d\n",x);
   } 
   return 0;
}
int add()
{
    printf("Enter the num1 : ");
    scanf("%d",&num1);
    printf("Enter the num2 : ");
    scanf("%d",&num2);
    return num1+num2;
}
int sub()
{
    printf("Enter the num1 : ");
    scanf("%d",&num1);
    printf("Enter the num2 : ");
    scanf("%d",&num2);
    return num1-num2;
}
int multi()
{
    printf("Enter the num1 : ");
    scanf("%d",&num1);
    printf("Enter the num2 : ");
    scanf("%d",&num2);
    return num1*num2;
}
int divid()
{
    printf("Enter the num1 : ");
    scanf("%d",&num1);
    printf("Enter the num2 : ");
    scanf("%d",&num2);
    return num1/num2;
}