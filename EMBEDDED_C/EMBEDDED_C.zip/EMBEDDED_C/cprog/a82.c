#include<stdio.h>
#include<string.h>
int main()
{
    int j=0,x,y;
    char str[]="this is the books";
    char str1[10];
    printf("Enter the string : ");
    //__fpurge(stdin);
    scanf("%s",&str1);
    x=strlen(str1);
    y=strlen(str);
    int z=y;
    for(int i=0;str[i]!=' ';i++){
        if(str[i]==str1[j]){
           j++;
        }
        else{
         j=0;
        }
    }
    if(x==j){
      printf("The string start with sub string\n");
    }
    else{
      printf("The string is not start with sub string\n");
    }
    int flag=0;
    for(int i=x;str[i]!=' ';i--){
        if(str[i]==str1[y]){
           y--;
           flag++;
        }
      //   else{
      //    y=0;
      //   }
    }
    if(flag==z){
      printf("The string end with sub string\n");
    }
    else{
      printf("The string is not end with sub string\n");
    }
    return 0;
}