#include<stdio.h>
#include<string.h>
int main()
{
    int x,j=0;
    char main[50]="This is my colleig";
    char sub[10];
    printf("Enter the sub string : ");
    scanf("%s",&sub);
    x=strlen(sub);
    for(int i=0;i<strlen(main)&&j<strlen(sub);i++){
        if(main[i]==sub[j]){
            j++;
        }
        else
        {
            j=0;
        }
    }
        if(x==j)
        {
            printf("Given string is a substrng of main string:");
        }
        else{
            printf("Given string is not a substring of main string:");
        }
    
    return 0;
}