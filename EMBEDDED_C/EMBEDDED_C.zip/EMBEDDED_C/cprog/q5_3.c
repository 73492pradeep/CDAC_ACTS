#include<stdio.h>
void revarr(int arr1[]);
int main()
{
	int j;
	int  arr[5]={1,2,3,4,5};
	for(j=0;j<=4;j++)
		printf("%d ",arr[j]);
	printf("\n");
	revarr(arr);
return 0;
}
void revarr(int arr1[])
{
	for(int i=4;i>=0;i--)
		printf("%d ",arr1[i]);
}


