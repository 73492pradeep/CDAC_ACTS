#include<stdio.h>
int main()
{
    int b,rem,a;
    char arr[10];
    int i=0;
    printf("Entern the number : ");
    scanf("%d",&a);
    b=a;
    while(a!=0){
        i++;
        a=a/10;
    }
    i=i-1;
    while(b!=0){
        rem=b%10;
        arr[i]=rem+'0';
        b=b/10;
        i--;
    }
    arr[i]='\0';
    puts(arr);
}