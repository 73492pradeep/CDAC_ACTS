#include<stdio.h>
int main()
{
    int a=123,res=0;
    while(a!=0){
        res=a%10;
        printf("%d",res);
        a=a/10;
    }
    
}