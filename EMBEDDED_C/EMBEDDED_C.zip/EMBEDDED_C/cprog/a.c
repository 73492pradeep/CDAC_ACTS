// #include <stdio.h>
// #include <stdlib.h>
// #include <unistd.h>
// #include <pthread.h>
// #include <sys/types.h>
// #include <sys/wait.h>
// #include <sys/mman.h>

// // Define the structure to hold shared data
// typedef struct {
//     double principal;
//     double rate;
//     double time;
//     double simple_interest;
// } SharedData;

// // Function to calculate simple interest
// void calculateSimpleInterest(SharedData *data) {
//     data->simple_interest = (data->principal * data->rate * data->time) / 100.0;
// }

// int main() {
//     // Create shared memory
//     SharedData *sharedData = mmap(NULL, sizeof(SharedData), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);

//     if (sharedData == MAP_FAILED) {
//         perror("Error creating shared memory");
//         exit(EXIT_FAILURE);
//     }

//     // Initialize shared data
//     sharedData->principal = 1000.0;
//     sharedData->rate = 5.0;
//     sharedData->time = 2.0;

//     // Create two child processes
//     pid_t pid1, pid2;

//     pid1 = fork();

//     if (pid1 < 0) {
//         perror("Error creating child process");
//         exit(EXIT_FAILURE);
//     } else if (pid1 == 0) {
//         // Child process 1
//         calculateSimpleInterest(sharedData);
//         printf("Child Process 1 - Simple Interest: %.2f\n", sharedData->simple_interest);
//         exit(EXIT_SUCCESS);
//     }

//     // Parent process
//     pid2 = fork();

//     if (pid2 < 0) {
//         perror("Error creating child process");
//         exit(EXIT_FAILURE);
//     } else if (pid2 == 0) {
//         // Child process 2
//         calculateSimpleInterest(sharedData);
//         printf("Child Process 2 - Simple Interest: %.2f\n", sharedData->simple_interest);
//         exit(EXIT_SUCCESS);
//     }

//     // Parent waits for both child processes to complete
//     waitpid(pid1, NULL, 0);
//     waitpid(pid2, NULL, 0);

//     // Cleanup: Unmap the shared memory
//     munmap(sharedData, sizeof(SharedData));

//     return 0;
// }
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
//#include <sys/wait.h>
#include <pthread.h>
//#include <sys/mman.h>

// Shared memory variables
int *principal, *rate, *time, *result;

// Function to calculate simple interest
void calculateSimpleInterest() {
    *result = (*principal * *rate * *time) / 100;
}

// Thread 1 function
void *thread1Function(void *arg) {
    printf("Enter principal amount: ");
    scanf("%d", principal);
    return NULL;
}

// Thread 2 function
void *thread2Function(void *arg) {
    printf("Enter rate of interest: ");
    scanf("%d", rate);

    printf("Enter time (in years): ");
    scanf("%d", time);

    // Calculate simple interest
    calculateSimpleInterest();

    return NULL;
}

int main() {
    // Allocate shared memory
    principal = mmap(NULL, sizeof(int), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    rate = mmap(NULL, sizeof(int), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    time = mmap(NULL, sizeof(int), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    result = mmap(NULL, sizeof(int), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);

    // Initialize shared memory variables
    *principal = 0;
    *rate = 0;
    *time = 0;
    *result = 0;

    // Create thread 1
    pthread_t thread1;
    pthread_create(&thread1, NULL, thread1Function, NULL);

    // Create thread 2
    pthread_t thread2;
    pthread_create(&thread2, NULL, thread2Function, NULL);

    // Wait for both threads to finish
    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);

    // Print the result
    printf("Simple Interest: %d\n", *result);

    // Cleanup and deallocate shared memory
    munmap(principal, sizeof(int));
    munmap(rate, sizeof(int));
    munmap(time, sizeof(int));
    munmap(result, sizeof(int));

    return 0;
}
