#include<stdio.h>
int main()
{
    unsigned int a = 0x11223344;
    char *ptr=(char*) &a;
    // printf("ptr = %x ",*ptr);
    // printf("ptr = %x ",*(ptr+0));
    // printf("ptr = %x ",*(ptr+1));
    // printf("ptr = %x ",*(ptr+2));
    // printf("ptr = %x ",*(ptr+3));
    if(*ptr==0x44)
        printf("little\n");
    else
        printf("big\n");
    return 0;
}
