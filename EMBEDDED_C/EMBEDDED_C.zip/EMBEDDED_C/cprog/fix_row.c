#include<stdio.h>
#include<stdlib.h>
int main()
{
    int *a[3];
    //int **a;
    for(int i=0;i<3;i++){
        a[i]=(int*)malloc(sizeof(int)*3);
    }
    for(int i=0;i<3;i++){
        for(int j=0;j<3;j++){
            scanf("%d",&a[i][j]);
        }
    }
    for(int i=0;i<3;i++){
        for(int j=0;j<3;j++){
            printf("%d ",a[i][j]);
        }
    }
    for(int i=0;i<3;i++){
        free(a[i]);
    }
    //free(a);
}