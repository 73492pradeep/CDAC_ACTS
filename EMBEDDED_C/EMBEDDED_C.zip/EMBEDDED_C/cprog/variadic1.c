#include<stdio.h>
#include<stdarg.h>
void fun( int count,...);
int main()
{
    int count=5;
    fun(count,10,20,30,40,50);
    return 0;
}
// void fun(int count,...)
// {
//     va_list ap;
//     va_start(ap,count);
//     // int v = va_arg(ap,int);
//     // printf("%d ",v);
//     // printf("%d ",va_arg(ap,int));
//     // printf("%d\n",va_arg(ap,int));
//     va_end(ap);
// }
void fun(int count,...)
{
    va_list ap;
    va_start(ap,count);
    for(int i = 0 ; i < count ; i++){
        printf("%d ",va_arg(ap,int));
    }
    va_end(ap);
}