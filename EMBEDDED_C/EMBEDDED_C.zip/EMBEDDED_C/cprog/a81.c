#include<stdio.h>
#include<string.h>
int main()
{
    int j=0,a,b,i;
    char str[50]="The college is this";
    char str1[50]="mine";
    a=strlen(str);
    for(i=0;i<strlen(str);i++){
        str[a]=str1[i];
        a++;
    }
    str[i]='\0';
    puts(str);
    return 0;
}