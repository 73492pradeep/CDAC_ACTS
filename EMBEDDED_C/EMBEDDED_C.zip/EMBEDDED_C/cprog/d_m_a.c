#include<stdio.h>
#include<stdlib.h>
int main()
{
    int r=3,c=3;
    int (*a)[c];
    printf("Enter the element : ");
    a=(int(*)[c])malloc(r*sizeof(int)*c);
    for(int i=0;i<r;i++){
        for(int j=0;j<c;j++){
             scanf("%d",&a[i][j]);
        }
    }
    for(int i=0;i<r;i++){
        for(int j=0;j<c;j++){
             printf("%d",a[i][j]);
        }
    }
    
        free(a);
    return 0;
}