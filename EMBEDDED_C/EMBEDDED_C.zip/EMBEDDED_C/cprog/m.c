#include<stdio.h>
#include<stdlib.h>
int main()
{
    int a,i=0;
    char *str="12345";
    int arr[10];
    a=strlen(str);
    while(a>0){
        arr[a]=str[i]-'0';
    }
    for(int i=0;i<a;i++){
        printf("%d",arr[i]);
    }
    return 0;
}
