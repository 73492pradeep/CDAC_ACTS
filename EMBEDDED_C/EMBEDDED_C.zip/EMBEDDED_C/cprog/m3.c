#include<stdio.h>
int main()
{
    int a,b,c;
    printf("ENter the number a b c");
    scanf("%d%d%d",&a,&b,&c);
    if(a>b&&a>c){
        printf("A is grest=%d",a);
    }
    else if(b>c){
        printf("b is grest=%d",b);
    }
    else
    printf("c is grest=%d",c);
}