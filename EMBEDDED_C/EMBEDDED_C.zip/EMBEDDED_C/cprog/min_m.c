#include<stdio.h>
int main()
{
    int temp;
    int arr[5]={3,5,6,21,11};
    temp=arr[0];
    for(int i=1;i<5;i++)
    {
        if(temp>arr[i]){
            temp=arr[i];
        }
        // if(temp<arr[i]){
        //     temp=arr[i];
        //}
    }
    printf("The min ele is = %d\n",temp);
    //printf("The max ele is = %d\n",temp);
}