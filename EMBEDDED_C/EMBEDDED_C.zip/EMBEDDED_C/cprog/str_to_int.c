#include<stdio.h>
#include<string.h>
int main()
{
    int rem=0,i,k=0,a;
    char *str="12345";
    int arr[10];
    i=strlen(str);
    //i=i-1;
    a=i;
    // for(int j=i-1;j>=0;j--){
        for(int j=0;j<a;j++){
           arr[j]=str[j]-'0';
    }
    for(int i=0;i<a;i++){
    printf("%d",arr[i]);
    }
}