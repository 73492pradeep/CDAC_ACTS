#include<stdio.h>
#include<math.h>
int main()
{
    int n,m,r,s,res=0,count=0;
    printf("Enter the number : ");
    scanf("%d",&n);
    s=m=n;
    while(n!=0){
        count++;
        n=n/10;
    }
    while(m!=0){
        r=m%10;
        res=res+pow(r,count);
        m=m/10;
    }
    if(res==s)
            printf("The given number is armstrong = %d\n",res);
    else
            printf("The given number is not armstrong : \n");
    return 0;
}