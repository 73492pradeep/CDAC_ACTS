#include<stdio.h>
#include<unistd.h>
#include<string.h>
#include <fcntl.h>
int main()
{
    int fd;
    ssize_t a,b;
    char buff[30];
    char str[]="Pradeep vishwakarma";
    fd=open("file1.txt",O_CREAT|O_WRONLY|O_TRUNC,0644);
    if(-1==fd){
        perror("error\n");
        return 0;
    }
    a=write(fd,str,sizeof(str));
    if(a==-1){
        perror("error\n");
    }
    close(fd);
    fd=open("file1.txt",O_RDONLY);
    if(-1==fd){
        printf("error\n");
        return 0;
    }
    b=read(fd,buff,sizeof(buff)-1);
    buff[b]='\0';
    printf("%s\n",buff);
}

