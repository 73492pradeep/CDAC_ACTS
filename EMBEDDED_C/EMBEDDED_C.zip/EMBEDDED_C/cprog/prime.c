#include<stdio.h>
int main()
{
    int n,flag=0;
    printf("Enter the number : ");
    scanf("%d",&n);
    for(int i=2;i<n;i++){
        if(n%i==0){
            flag=1;
        }
    }
    if(flag!=1){
        printf("The number is a prime number\n");
    }
    else
        printf("The number is not prime number\n");
    return 0;
   
}
