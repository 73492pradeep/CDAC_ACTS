#include<stdio.h>
void strlength(char *ptr1);
int main()
{
    char arr[20];
    char *ptr=arr;
    strlength(ptr);
}
void strlength(char *ptr1)
{
    printf("Enter the string : ");
    gets(ptr1);
    int count=0;
    for(int i=0;ptr1[i]!='\0';i++)
    {
        count++;
    }
    printf("The length of str is = %d\n",count);
}