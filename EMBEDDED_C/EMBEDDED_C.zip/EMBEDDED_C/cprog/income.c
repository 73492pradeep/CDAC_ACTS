#include<stdio.h>
#include <stdlib.h>
int main()
{
    int income,tax;
    printf("Enter the income \n");
    scanf("%d",&income);
    if(income<=250000){
        tax=0;
    }
    else if(income>250000&&income<=500000){
        tax=(income-250000)*.5;
    }
    else if(income>500000&&income<=750000){
        tax=250000*.5+(income-500000)*.20;
    }
    int choice,tax1,tax2;
    while(1){
    printf("Enter the choice \n");
    scanf("%d",&choice);
    switch(choice){
                  case 1:
                        tax1=tax-tax*.10;
                        printf("The tax for women = %d\n",tax1);
                        break;
                  case 2:
                        tax2=tax-tax*.15;
                        printf("The tax for senior citizen = %d\n",tax2);
                        break;
                  case 3:
                        tax=tax;
                        printf("The tax for men = %d\n",tax);
                        break;
                  case 0:
                        exit(0);
    }
}
return 0;
}

