#include<stdio.h>
int sum1(int n);
int main()
{
    int n,res;
    printf("Enter the number : ");
    scanf("%d",&n);
    res=sum1(n);
    printf("The number is = %d\n",res);
    return 0;
}
int sum1(int n){
    int res,sum=0;
    if(n<=9&&n>=1){
        return n;
    }
        while(n!=0){
            res=n%10;
            sum=sum+res;
            n=n/10;
        }
        return sum1(sum);
}