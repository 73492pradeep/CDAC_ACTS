#include<stdio.h>
#include<string.h>
int main()
{
    char str[]="pradeep";
    char ch;
    int i=strlen(str);//count=0;
    printf("Enter the char\n");
    scanf("%c",&ch);
       while(i>=0){
        if(str[i]==ch){
         //   count++;
           printf("The last occurrence index=%d char=%c\n",i,str[i]);
           break;
        }
        i--;
       }
    //printf("The first occurrence = %d\n",count);
    return 0;
}