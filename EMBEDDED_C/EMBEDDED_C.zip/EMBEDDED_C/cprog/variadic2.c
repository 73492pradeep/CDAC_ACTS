// #include<stdio.h>
// #include<stdarg.h>
// void fun(int count,...);
// int main()
// {
//     int count=5;
//     fun(count,"cdac","abc","acts","123","desd");
//     fun(3,"cdac-acts","desd-2023","sept-2023");
//     return 0;
// }
// void fun(int count,...)
// {
//     va_list ap;
//     va_start(ap,count);
//     for(int i = 0 ; i < count ; i++){
//         printf("%s ",va_arg(ap,char*));
//     }
//     va_end(ap);
// }
#include <stdarg.h>
#include <stdio.h>

void fun(int arg_count, ...)
{
    va_list ap;
    va_start(ap, arg_count);
    printf("%s \n", va_arg(ap, char *));
    printf("%d \n", va_arg(ap, int));
    va_end(ap);

}
int main()
{
    fun(2, "cdac-acts", 10, "desd", 20);
    return 0;
}