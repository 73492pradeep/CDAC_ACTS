#include<stdio.h>
#define SWAP(a,b) {int t=a;a=b;b=t;}
void find_second_larg(int arr[]);
void sort(int arr[]);
void scan(int arr[]);
int main()
{
    int arr[10];//={9,7,5,1,8,6,4,1,1,11};
    scan(arr);
    sort(arr);
    find_second_larg(arr);
}
void scan(int arr[])
{
    for(int i=0;i<10;i++){
        scanf("%d",&arr[i]);
    }
}
void sort(int arr[])
{
    for(int i=0;i<9;i++){
        for(int j=i+1;j<10;j++){
            if(arr[i]>arr[j]){
                SWAP(arr[i],arr[j]);
            }
        }
    }
}
void find_second_larg(int arr[])
{
    int temp=arr[0],i;
    for(i=0;i<10;i++){
        if(temp<arr[i]){
           break;
        }
    }
    printf("The second larg is %d\n",arr[i]);
}