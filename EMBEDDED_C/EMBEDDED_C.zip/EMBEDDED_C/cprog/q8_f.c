#include<stdio.h>
void occurrence(char *ptr1);
int main()
{
    char arr[20];
    char *ptr=arr;
    printf("Enter the string: ");
    gets(ptr);
    occurrence(ptr);
}
void occurrence(char *ptr1)
{
    char ch;
    printf("Enter the char for occur: ");
    scanf("%c",&ch);
    for(int i=0;ptr1[i]!='\0';i++){
        if(ptr1[i]==ch){
            printf("The first %c occurr is = %d index\n",ch,i);
            break;
        }
    }
}
