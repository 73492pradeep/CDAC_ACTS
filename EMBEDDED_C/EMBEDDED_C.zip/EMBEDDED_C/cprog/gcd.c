#include<stdio.h>
int gcd(int a,int b);
int main()
{
    int a,b,x;
    printf("Enter the number a and b : ");
    scanf("%d%d",&a,&b);
    x=gcd(a,b);
    printf("The gcd is =%d\n",x);
    return 0;
}
int gcd(int a,int b)
{
    if(a==b){
        return a;
    }
    else if(a>b){
        return gcd(b,(a-b));
    }
    else if(a<b){
        return gcd(a,(b-a));
    }
}