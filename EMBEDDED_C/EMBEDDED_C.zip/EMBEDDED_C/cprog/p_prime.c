#include<stdio.h>
int prime(int n);
int main()
{
    int n;
    printf("The prime number is : \n");
    scanf("%d",&n);
    for(int i=2;i<=n;i++){
        prime(i);
    }
    return 0;
}
int prime(int n)
{
    int flag=0;
    for(int i=2;i<n;i++){
        if(n%i==0){
            flag=1;
        }
    }
    if(flag!=1)
    printf("%d ",n);
}