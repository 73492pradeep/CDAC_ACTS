#include<stdio.h>
#include<stdlib.h>
int main()
{
    int **a,r=3;
    a=(int**)malloc(sizeof(int*)*r);
    for(int i=0;i<9;i++){
            scanf("%d",&a[i]);
        }
    for(int i=0;i<9;i++){
            printf("%d ",a[i]);
        }
    for(int i=0;i<3;i++){
			free(a[i]);
    }
    free(a);
    return 0;
}