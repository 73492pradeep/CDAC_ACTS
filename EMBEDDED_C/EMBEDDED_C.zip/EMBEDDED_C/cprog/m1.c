#include <stdio.h>
#include <string.h>

int main() {
    char str[] = "Hello this is the";
    char substring[] = "the";

    if (strstr(str + strlen(str) - strlen(substring), substring) != NULL) {
        printf("The string ends with the substring.\n");
    } else {
        printf("The string does not end with the substring.\n");
    }
    return 0;
}
