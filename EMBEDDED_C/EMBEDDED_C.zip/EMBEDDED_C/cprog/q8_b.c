#include<stdio.h>
void str_cpy(char *ptr1,char *pptr1);
void printpptr(char *pptr1);
int main()
{
    char arr[20];
    char *ptr=arr;
    char *pptr;
    str_cpy(ptr,pptr);
    printpptr(pptr);
}
void str_cpy(char *ptr1,char *pptr1)
{
    printf("Enter the string : ");
    gets(ptr1);
    int i;
        for(i=0;ptr1[i]!='\0';i++){
            pptr1[i]=ptr1[i];
        }
        pptr1[i]='\0';
}
void printpptr(char *pptr2)
{
    int i=0;
    while(pptr2[i]!='\0'){
        printf("%c",pptr2[i]);
        i++;
    }
}