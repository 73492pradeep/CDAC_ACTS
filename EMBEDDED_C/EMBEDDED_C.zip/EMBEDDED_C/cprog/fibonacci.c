#include<stdio.h>
int fibonacci(int a,int b);
int n;
int main()
{
    int a=0,b=1;
    printf("Enter the number : ");
    scanf("%d",&n);
    printf("%d %d",a,b);
    fibonacci(a,b);
    return 0;
}
int fibonacci(int a,int b)
{
    int next,i=0;
    while(n>i){
        
        next=a+b;
        a=b;
        b=next;
        printf(" %d",next);
        i++;
    }
}