#include<stdio.h>
int main()
{
    int i=0;
    int j=7;
    char ptr[30]="pradeep";
    char pptr[30]=" Vishwakarma";
    while(pptr[i]!='\0')
    {
        ptr[j]=pptr[i];
           i++;
           j++;

    }
    ptr[j]='\0';
    printf("After catencation =%s",ptr);
}