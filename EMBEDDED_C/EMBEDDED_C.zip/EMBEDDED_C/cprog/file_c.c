#include<stdio.h>
void copy();
int main()
{
    FILE *ptr1,*ptr = fopen("file.txt","w");
    if(ptr==NULL){
        printf("file could not open");
    }
    //fputc('B',ptr);
    fputs("This is 5 6 # the pen which is mine who is",ptr);
    ptr=fopen("file.txt","r");
    if(ptr==NULL){
        printf("failed");
    }
    ptr1=fopen("file1.txt","w");
    if(ptr==NULL){
        printf("failed");
    sprintf(ptr1,"%s",ptr);
    // char ch;
    // while((ch=fgetc(ptr))!=EOF){
    //     fputc(ch,ptr1);
    //    // ch=fgetc(ptr);
    }
    fclose(ptr);
    fclose(ptr1);
    // ptr = fopen("file.ext","r");
    // char ch=fgetc(ptr);
    // while(ch!=EOF){
    //       printf("%c",ch);
    //       ch=fgetc(ptr);
    // }
    //fclose(ptr);
    //puts(str);
    //printf("The string is = %s",ch);
    
    return 0;
}
// void copy()
// {
//     FILE *ptr,*ptr1;
//     ptr=fopen("file.txt","r");
//     if(ptr==NULL){
//         printf("failed");
//     }
//     ptr1=fopen("file1.txt","w");
//     if(ptr==NULL){
//         printf("failed");
//     }
//     char ch=fgetc(ptr);
//     while((ch)!=EOF){
//         fputc(ch,ptr1);
//        // ch=fgetc(ptr);
//     }
//     fclose(ptr);
//     fclose(ptr1);
// }