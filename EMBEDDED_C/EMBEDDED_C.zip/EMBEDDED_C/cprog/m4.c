#include<stdio.h>
int main()
{
    int n;
    printf("En ter the number trangle");
    scanf("%d",&n);
    for(int i=1;i<=n;i++){
        for(int j=i;j<=n;j++)
        {
            printf(" ");
        }
        for(int j=1;j<i*2;j++)
        {
            printf("%d",i);
        }
        printf("\n");
    }
    return 0;
   
}