#include<stdio.h>
#include<stdlib.h>
#include<stdio_ext.h>
struct student
{
	char name[50];
	char f_name[40];
	int age;
	int class;
	int stud_id;
	int id_proof;
};
int c=0,temp;
void add(struct student var[]);
int search(struct student var[]);
void display(struct student var[],int i);
void modify(struct student var[],int j);
int main()
{
	int flag;
	struct student var[4];
	int choice,x;
	for(int i=0;i<c;i++)
	{
		if(temp==var[c].stud_id)
			flag=1;

	}
	if(flag==1)
	{
		printf("You have already registered:");
	}
	while(1)
	{
		printf("Enter the choice \n1-> For add\n2-> For search\n3-> For display\n4-> For modify\n0-> For exit : ");
		scanf("%d",&choice);
		switch(choice)
		{
			case 1:
				add(var);
				break;
			case 2:
				x=search(var);
				break;
			case 3:
				display(var,x);
				break;
			case 4:
				modify(var,x);
				break;
			case 0:
				exit(0);
		}
	}
return 0;
}
void add(struct student var[])
{
	printf("Enter the name        :");
	__fpurge(stdin);
	scanf("%[^\n]s",var[c].name);
	printf("Enter the father name :");
	__fpurge(stdin);
	scanf("%[^\n]s",var[c].f_name);
	printf("Enter the age         :");
	scanf("%d",&var[c].age);
	printf("Enter the class       :");
	scanf("%d",&var[c].class);
	printf("Enter the student id  :");
	scanf("%d",&var[c].stud_id);
	printf("Enter the id proof    :");
	scanf("%d",&var[c].id_proof);
	c++;
	int temp=var[c].stud_id;
}
int search(struct student var[])
{
	int id;
	printf("Enter the id for search : ");
	scanf("%d",&id);
	for(int i=0;i<4;i++)
	{
		if(var[i].stud_id==id)
		{
			return i;
		}
	}
	printf("You have entered a wrong id no choose a valid id :\n");
}
void display(struct student var[],int i)
{
	printf("Name          =%s\n",var[i].name);
	printf("Father name   =%s\n",var[i].f_name);
	printf("Age           =%d\n",var[i].age);
	printf("Class         =%d\n",var[i].class);
	printf("Student id    =%d\n",var[i].stud_id);
	printf("Id_proof      =%d\n",var[i].id_proof);
}
void modify(struct student var[],int j)
{
	int id_c,i,a;
	printf("Enter the id for modify : ");
	scanf("%d",&id_c);
	for(i=0;i<4;i++)
	{
		if(var[i].stud_id==id_c)
		{
			break;
		}
	}
	printf("Enter the number for edit\n1->Name\n2->Father name\n3->Age\n4->Class\n5->Id proof : ");
	scanf("%d",&a);
	switch(a){
		case 1:
	              printf("Edit your name        :");
	              __fpurge(stdin);
	              scanf("%[^\n]s",var[i].name);
		      break;
		case 2:
	              printf("Edit your father name :");
	              __fpurge(stdin);
	              scanf("%[^\n]s",var[i].f_name);
		      break;
		case 3:
	              printf("Edit your age         :");
	              scanf("%d",&var[i].age);
		      break;
		case 4:
	              printf("Edit your class       :");
	              scanf("%d",&var[i].class);
		      break;
		case 5:
	              printf("Edit your id proof    :");
	              scanf("%d",&var[i].id_proof);
		      break;
	}
}







