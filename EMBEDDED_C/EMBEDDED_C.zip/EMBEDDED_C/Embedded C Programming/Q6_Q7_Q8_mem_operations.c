#include <stdio.h>
#include <string.h>

void swap(void *vp1, void *vp2, int);

int main() {
    char src[] = "Happy DAYS";
    char dest[20];
	
	// copy one array to another
	//	int arr[5]={1,2,3,4,5};
	//	int arr2[5];
	
	// generic swap using memcpy
	// int x=100;
	// int y=200;
	// swap(&x,&y);
	 // res x=200 , y=100
	 // swap(arr,arr2, );
	 // swap(str,str1, );
	 // swap(structure variables)
		
	
    memcpy(dest, src, strlen(src)+1); // copy null character also 

    // Print the result
    printf("Source: %s\n", src);
    printf("Destination: %s\n", dest);

    char str1[] = "Hello";
    char str2[] = "DESD";

    int res = memcmp(str1, str2, 4);  // Compare the first 4 characters

    if (res == 0) {
        printf("The strings are equal.\n");
    } else if (res < 0) {
        printf("str1 is less than str2.\n");
    } else {
        printf("str1 is greater than str2.\n");
    }

    int arr[5];

    // Initialize the entire array to 0
    memset(arr, 0, sizeof(arr));

    for (int i = 0; i < 5; i++) {
        printf("arr[%d] = %d\n", i, arr[i]);
    }


    char str[] = "Hello, World!";

    // Clear the memory of the string
    bzero(str, strlen(str)+1);

    // Print the result
    printf("After clearing: %s\n", str);

    return 0;
}



void swap(void *vp1, void *vp2, int size)
{
}





