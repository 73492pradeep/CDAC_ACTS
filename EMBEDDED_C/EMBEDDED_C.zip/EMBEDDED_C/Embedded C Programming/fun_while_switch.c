#include<stdio.h>
#include<stdlib.h>
int add(int, int);
int sub(int, int);
int mul(int , int);
int divide(int, int);

int main(){
	
	int choice,n1,n2;
	printf("Enter two nos");
	scanf("%d%d",&n1,&n2);
	
	while(1){
		printf("1:add\t2:sub\t3:mul\t4:div\t5:exit\n");
		printf("Enter your choice:");
		scanf("%d",&choice);
		switch(choice){

			case 1:
				add(n1,n2);
				break;

			case 2:

				sub(n1,n2);
				break;

			case 3:
				mul(n1,n2);
				break;

			case 4:
				divide(n1,n2);
				break;

			case 5:
				exit(0);

			default:
				printf("Enter the choice again\n");
				break;


		}

	}

	return 0;
}

int add(int a, int b){

	printf("Sum= \n");
}
int sub(int a, int b){

	printf("sub= \n");
}
int mul(int a, int b){

	printf("mul= \n");
}
int divide(int a, int b){

	printf("div= \n");
}
