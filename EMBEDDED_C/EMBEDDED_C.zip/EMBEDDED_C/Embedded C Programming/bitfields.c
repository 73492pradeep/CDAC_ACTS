#include <stdio.h>

struct student {
    unsigned int a : 4; // 4-bit field // can store (0 - 2(raised to 4)-1) = 0 to 15
    unsigned int b : 4; // 4-bit field // 
    unsigned int c : 7;	// 7-bit field // = 0 to 127
    unsigned char ch: 4;
};

int main() {
    struct student stu;
    unsigned int temp;

    stu.a = 7;   // Set a to 111
    stu.b = 5;   // Set b to  (binary 101)
    stu.c = 100; 
   
    printf("a: %u\n", stu.a);
    printf("b: %u\n", stu.b);
    printf("c: %u\n", stu.c);
   

   // scanf cannot work with bit fields
   // scanf("%u", &stu.b); // bitfields do not have addresses
   printf("enter value of a : ");
   scanf("%u", &temp);
   
   // validation the value of temp such that is 0 to <=15
   stu.a=temp;       
   printf("Size of struct Flags: %lu bytes\n", sizeof(struct student)); // 4 bytes
   printf("a: %u\n", stu.a);

    return 0;
}

