#include<stdio.h>
struct Id1{
	struct {
		char name[40];
	   	int age;
		int roll_number;
		char place[40];
	}t;
};
struct Id1 print();
int main(){
	struct Id1 var1;
	printf("Enter the name");
	scanf("%s",var1.t.name);
	printf("Enter the age");
	scanf("%d",&var1.t.age);
	printf("Enter the roll_number");
	scanf("%d",&var1.t.roll_number);
	printf("Enter the place");
	scanf("%s",var1.t.place);
	struct Id1 var1=print();
	return 0;
}
struct Id1 print(){






	printf("name=%s",var1.t.name);
	printf("name=%d",var1.t.age);
	printf("name=%d",var1.t.roll_number);
	printf("name=%s",var1.t.place);
}

