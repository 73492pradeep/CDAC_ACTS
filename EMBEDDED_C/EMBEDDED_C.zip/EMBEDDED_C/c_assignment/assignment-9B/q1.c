#include<stdio.h>
#include<stdlib.h>
	union A
	{
		float x;
		float y;
		double z;
		int arr[2];
	}a1;
int main()
{
	a1.y=6.25f;
	printf("x=%f\n",a1.x);
	a1.z=0.15625;
	printf("a1.arr[1]=%x\na1.arr[0]=%x\n",a1.arr[1],a1.arr[0]);
}




