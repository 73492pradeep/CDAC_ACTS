#include<stdio.h>
#include<stdlib.h>
struct reg{
	int x;
	char y;
	float z;
}var1;
int main(){
	struct reg var1=initial();


	return 0;
}
