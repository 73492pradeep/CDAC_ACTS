
#include<stdio.h>
#include<stdlib.h>
struct create{
	char name[30];
	int age;
	char Gender;
	char city[30];
	 int Pincode;
	char Martial_status[20];
	int  Annual_Salary;
};
struct create scan();
int main()
{
	struct create var1 = scan();
	printf("Name =%s\n",var1.name);
	printf("Age =%d\n",var1.age);
	printf("Gender =%c\n",var1.Gender);
	printf("City =%s\n",var1.city);
	printf("Pincode =%d\n",var1.Pincode);
	printf("Martial_status =%s\n",var1.Martial_status);
	printf("Annual_Salary =%d\n",var1.Annual_Salary);
return 0;
}

struct create scan()
{
	{
		char name[20];
		int age;
		char Gender;
		char city[30];
		int Pincode;
		char Martial_status[30];
		int Annual_Salary;
	};
	struct create var;
	printf("Enter the name\n");
	scanf("%s",var.name);
	printf("Enter the age\n");
	scanf("%d",&var.age);
	printf("Enter the Gender\n");
	scanf(" %c",&var.Gender);
	printf("Enter the City\n");
	scanf("%s",var.city);
	printf("Enter the Pincode\n");
	scanf("%d",&var.Pincode);
	printf("Enter the Martial Status\n");
	scanf("%s",var.Martial_status);
	printf("Enter the Annual Salary\n");
	scanf("%d",&var.Annual_Salary);
return var;
}

