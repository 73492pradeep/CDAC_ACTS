#include<stdio.h> 
#include<stdio_ext.h>
struct emp
{
	unsigned int empid:10;
        char empname[30]; 
        float salary; 
        int year_join;
        char gender; 
        unsigned int age:7; 
        int id_proof;
	int current_y;
};
void find_t_sal(struct emp *);
void find_min_sal(struct emp var[]);
void find_max_sal(struct emp var[]);
int main()
{
	int temp[3];
	int temp1[3];
	struct emp var1[3];
	for(int i=0;i<3;i++){

        printf("Enter the empid : ");
	scanf("%d",&temp[i]);
	var1[i].empid=temp[i];
	printf("Enter the empname : ");
	scanf("%s",var1[i].empname);
	printf("Enter the salary : ");
	scanf("%f",&var1[i].salary);
	printf("Enter the year of jaoining : ");
	scanf("%d",&var1[i].year_join);
	printf("Enter the Gender : ");
	__fpurge(stdin);
	scanf("%c",&var1[i].gender);
	printf("Enter the age : ");
	scanf("%u",&temp1[i]);
	var1[i].age=temp1[i];
	printf("Enter the Id proof : ");
	scanf("%d",&var1[i].id_proof);
	printf("Enter the current_y : ");
	scanf("%d",&var1[i].current_y);
	}
        find_t_sal(var1);
	find_min_sal(var1);
	find_max_sal(var1);
	return 0;
}
void find_t_sal(struct emp var[])
{
	int sum=0;
	for(int i=0;i<3;i++){
		sum+=var[i].salary;
         }
	printf("Total sal = %d\n",sum);
}
void find_min_sal(struct emp var[])
{
	int min=var[0].salary;
	for(int i=1;i<3;i++){
	     if(var[0].salary<var[i].salary)
	     {
		     min = var[0].salary;
	     }
	     else 
		     min = var[i].salary;
	}
	printf("min salary =%d\n",min);
}
void find_max_sal(struct emp var[])
{
	int max=var[0].salary;
	for(int i=1;i<3;i++){
	     if(var[0].salary>var[i].salary)
	     {
		     max = var[0].salary;
	     }
	     else 
		     max = var[i].salary;
	}
	printf("Max salary =%d\n",max);
}


