#include<stdio.h>
int a;
int main()
{
         register int b;
	 int c;
	 printf("Default value of global variable a =%d\n",a);
	 printf("Default value of register variable b =%d\n",b);
	 printf("Default value of local variable c =%d\n",c);
	 printf("Address of gloabl variable a= %p\n",&a);
	 //printf("Address of register variable =%p",&b);
	 printf("Address of local variable =%p",&c);
return 0;
}

