/*
Q7. Try conversions between int*, const int* while passing parameters to
functions
int *p;
const int *q;
test(p); void test(const int* );
test(q); void test2(int *);
*/

#include<stdio.h>

void test(const int *);

void test2(int *);

int main() {
    int x = 20;
    int y = 30;
    int *p = &x;
    int *q = &y;
    
    test(p);
    test2(q);
    // here arithmetic is allowed beacuse p is not pointing any constant 
    (*p)++;
     printf("Value of X in main : %d\n", *p); // 21
     
    // here arithmetic is allowed beacuse q is not pointing any constant 
    (*q)++;
     printf("Value of X in main : %d\n", *q);   // 32
    
    return 0;
    
}
// In this test function *p is read only no arithmetic is Allowed
void test (const int *p) {
    printf("Value of X : %d\n", *p);   // 20
    // Gives an error
    (*p)++;   //  Not Allowed beacuse p is  pointing to constant
    printf("Value of X : %d\n", *p);    // Error
}

// In this test function *q is not read only so arithmetic is Allowed
void test2 (int *q) {
    printf("Value of Y : %d\n", *q);   // 30
    (*q)++; // Allowed beacuse q is not pointing to constant
    printf("Value of Y : %d\n", *q);    // 31
}
