#include<stdio.h>
int *returnarray()
{
	static int arr1[5];
	printf("Enter the element of array:");
	for(int i=0;i<5;i++)
	{
		scanf("%d",&arr1[i]);
	}
return arr1;
}
int main()
{
	int *a=returnarray();
	for(int i=0;i<5;i++)
	{
		printf("%d\t",a[i]);
	}
return 0;
}
