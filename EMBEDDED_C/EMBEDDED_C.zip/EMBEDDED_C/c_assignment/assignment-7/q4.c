#include<stdio.h>
void pass_by_value(int,int);
void pass_by_ref(int *x,int *y);
int main()
{
	int a=10,b=20;
	printf("a = %d b = %d\n",a,b);
	pass_by_value(a,b);
	pass_by_ref(&a,&b);
	return 0;
}
void pass_by_value(int x,int y)
{
	int temp = x;
	x = y;
	y = temp;
	printf("a = %d b = %d\n",x,y);
}
void pass_by_ref(int *x,int *y)
{
	int *temp = x;
	x = y;
	y = temp;
	printf("a = %d b = %d\n",*x,*y);
}


