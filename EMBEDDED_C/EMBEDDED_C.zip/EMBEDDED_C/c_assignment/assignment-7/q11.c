#include<stdio.h>
void func(int x,int y,int(*fp)(int, int));
int sum(int a ,int b);
int main()
{
       printf("Function main is called\n:")`;
       func(10,20,sum);
return 0;
}
void func(int x, int y, int (*fp)(int  ,int ))
{
	printf("Function func is called\n:");
	int z =fp(x,y);
	printf("Sum =%d",z);
}
int sum(int a ,int b)
{
        printf("Function sum is called\n:");	
	return a+b;
}



