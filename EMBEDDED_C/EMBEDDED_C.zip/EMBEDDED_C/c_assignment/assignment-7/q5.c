#include<stdio.h>
int *p;
int *q;
int fun(int a , int b);
int main()
{
	int a;
	int b;
	printf("Enter the two values:");
	scanf("%d%d",&a,&b);
        fun(a,b);
	printf("Sum =%d\nProduct =%d", *p,*q);
return 0;
}
int fun(int a , int b)
{
	int sum;
	int prod;
	sum =a+b;
	prod =a*b;
	p =&sum;
	q =&prod;
}

