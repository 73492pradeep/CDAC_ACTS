#include<stdio.h>
#include<math.h>
#include<ctype.h>
#include<stdlib.h>
int main()
{
	int x;
	printf("Enter the value of x:");
	scanf("%d",&x);
	int y;
	int z;
	y =abs(x);
	printf("Absolute value of x =%d\n",y);
	z =sqrt(pow(abs(x),1));
	printf("Square root of x =%d\n",z);
        int j = 0;
        char str[] = "akhilesh srivastav";
        char ch;
        while (str[j]) {
        ch = str[j];
        putchar(toupper(ch));
        j++;
	}
   return 0;
}

