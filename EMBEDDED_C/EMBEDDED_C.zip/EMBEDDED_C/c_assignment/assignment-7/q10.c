#include<stdio.h>
int add(int , int);
int (*fp)(int , int);
int main()
{
	int akh;
	int result;
	int (*fp)(int , int);
	typedef int(*fp)(int , int);
	fp akh =&add;
	akh =add;
	result =add(5,6);
	printf("Result =%d",result);
return 0;
}
int add(int a , int b)
{

	return a+b;
}

	

