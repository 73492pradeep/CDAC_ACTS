#include<stdio.h>
int *text(int x);
int main()
{
	int x =6;
	int *p;
	*p=text(x);
	printf("%d",*p);
return 0;
}
int *text(int x)
{
	int y=x*x;
	return &y;
}
	

