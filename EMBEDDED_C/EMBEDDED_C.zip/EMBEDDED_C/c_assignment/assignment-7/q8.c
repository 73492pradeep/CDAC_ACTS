#include<stdio.h>
void min1(int arr1[5]);
void min2(int arr2[][4]);
void max1(int arr1[5]);
void max2(int arr2[][4]);
void sum1(int arr1[5]);
void sum2(int arr2[][4]);
int a;
int c;
int main()
{
	int arr1[5];
	int arr2[3][4];
	printf("Enter the element of first 1d array:");
	for(int i=0;i<5;i++)
	{
		scanf("%d",&arr1[i]);
	}
	a = arr1[0];
	c = arr1[0];
	printf("Enter the element of 2d array:");
	for(int i=0;i<3;i++)
	{
		for(int j=0;j<4;j++)
		{
			scanf("%d",&arr2[i][j]);
		}
	}
	
	min1(arr1);
	min2(arr2);
	max1(arr1);
	max2(arr2);
	sum1(arr1);
	sum2(arr2);
return 0;
}
void min1(int arr1[])
{
	for(int i=1;i<5;i++)
	{
		if(a>arr1[i])
			a = arr1[i];
		
	}
	printf("Min value of 1d array =%d\n",a);
}
void min2(int arr2[][4])
{
	int min =arr2[0][0];
	for(int i=0;i<3;i++)
	{
		for(int j=0;j<4;j++)
		{
			if(min>arr2[i][j])
				min = arr2[i][j];
		}
	}
	printf("Min value of 2d array =%d\n",min);
}
void max1(int arr1[])
{
	for(int i=1;i<5;i++)
	{
		if(c<arr1[i])
			c = arr1[i];
	}
	printf("Max value of 1d arrqy =%d\n",c);
}
void max2(int arr2[][4])
{
	int max =arr2[0][0];
	for(int i=0;i<3;i++)
	{
		for(int j=0;j<4;j++)
		{
			if(max<arr2[i][j])
				max = arr2[i][j];
		}
	}	
	printf("Max value of 2d array =%d\n", max);
}
void sum1(int arr1[])
{
	int sum =0;
	for(int i=0;i<5;i++)
	{
		sum+=arr1[i];
	}
	printf("Sum of elements of 1d array =%d\n",sum);
}
void sum2(int arr2[][4])
{
	int sum =0;
	for(int i=0;i<3;i++)
	{
		for(int j=0;j<4;j++)
		{
			sum+=arr2[i][j];
		}
	}
	printf("Sum of elements of 2d array =%d",sum);
}



		
