#include<stdio.h>
int fun()
{
	static int count=0;
	//printf("function is called =%d\n",count);
	count++;
}
int main()
{
	int count;
	fun();
	fun();
	count=fun();
	printf("Function is called = %d",count);
return 0;
}

	
