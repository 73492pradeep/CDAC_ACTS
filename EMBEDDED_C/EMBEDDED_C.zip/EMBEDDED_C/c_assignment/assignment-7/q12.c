#include<stdio.h>
void test(int x,int y,int(*fp)(int,int))
{
	int z = fp(x,y);
	printf("Sum is =%d",z);

}
int sum(int a,int b)

	{
		return a+b;
	}


int main(){

        
	int a=10;
	int b=20;
	test(10,20,sum);
	return 0;
}















