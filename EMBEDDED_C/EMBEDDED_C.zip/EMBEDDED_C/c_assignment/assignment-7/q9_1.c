#include<stdio.h>
int (*returnarray())[5];
int *returnarray1();
int main()
{
	int *a1 =returnarray1();
	for(int i=0;i<5;i++)
	{
		printf("%d\t",a1[i]);
	}
	int (*a)[]=returnarray();
	for(int i=0;i<5;i++)
	{
		printf("%d\ut",*(*(a)+i));
	}
return 0;
}
int (*returnarray())[5]
{
	static int arr1[5];
	printf("Enter the elements of the array:");
        for(int i=0;i<5;i++)
	{
		scanf("%d",&arr1[i]);
	}

        return &arr1;
}
int *returnarray1()
{
        static int arr1[5];
        printf("Enter the element of array:");
        for(int i=0;i<5;i++)
        {
                scanf("%d",&arr1[i]);
        }
return arr1;
}
~                                                                                                     
~                       

	

