/*#include<stdio.h>
#include<stdlib.h>
int add(int a,int b)
{
  return a+b;
}
int sub(int a,int b)
{
return a-b;
}
int mult(int a,int b)
{
return a*b;
}
int divi(int a,int b)
{
return a/b;
}
int main()
    {
      int choice, x,a,b;
    while (1)
    {
      printf ("enter the number\n");
      scanf("%d%d",&a,&b);

      printf("enter thr choice\n");
      scanf("%d",&choice);
    switch(choice)
      {
	case 1:
              x=add(a }*/
#include<stdio.h>
int prime(int n)
{
	int i,prime=1;
	for(i=2;i<n;i++){
		if(n%i==0)
			prime=0;
	}
	if(prime==1)
		printf("%d  ",n);
 }
int main()
{
	int j;
	for(j=2;j<100;j++){
	prime(j);
	}
	return 0;
}
,b);
              printf("%d\n",x);
              break;
	case 2:
              x=sub(a ,b);
              printf("}*/
#include<stdio.h>
int prime(int n)
{
	int i,prime=1;
	for(i=2;i<n;i++){
		if(n%i==0)
			prime=0;
	}
	if(prime==1)
		printf("%d  ",n);
 }
int main()
{
	int j;
	for(j=2;j<100;j++){
	prime(j);
	}
	return 0;
}
%d\n",x);
              break;
	case 3:
              x=mult(a ,b);
              printf("%d\n",x);
              break;
	case 4:
              x=divi(a ,b);
              printf("%d\n",x);
              break;
	case 5:
              exit(1);
     defult:
              printf("enter the choice inthe range of 1to4");

}
}

return 0;
}*/
/*#include<stdio.h>
int main()
{
	double income,tax;
        int choice;
	printf("Enter the income:\n");
	scanf("%lf",&income);

		if(income<=250000){
			printf("tax = 0\n");
		}
		else if(income>250000&&income<=500000){
			tax = (income-250000)*0.05;
			printf("tax = %2.lf\n",tax);
		}
		else if(income>500000&&income<=750000){
			tax = (250000*0.05)+(income-500000)*0.1;
			printf("tax = %2.lf\n",tax);
		}
		else if(income>750000){
			tax = (250000*0.05)+(250000*0.1)+(income-750000)*0.15;
			printf("tax = %2.lf\n",tax);
		}
	printf("Enter the choice 1-for female 2-for senior citizen:\n");
	scanf("%d",&choice);
	        switc}*/
#include<stdio.h>
int prime(int n)
{
	int i,prime=1;
	for(i=2;i<n;i++){
		if(n%i==0)
			prime=0;
	}
	if(prime==1)
		printf("%d  ",n);
 }
int main()
{
	int j;
	for(j=2;j<100;j++){
	prime(j);
	}
	return 0;
}
h(choice)
		{
			case 1:
				tax = tax-tax*0.1;
				printf("tax for female = %2.lf\n",tax);
				break;
			case 2:
				tax = tax-tax*0.15;
				printf("tax for senior citizen = %2.lf\n",tax);
				break;
			default:
				printf("Invalid choice");
		}


		return 0;
}*/
/*#include<stdio.h>
int main()
{
	int math,science,physics,chemistry,english,sum;
	printf("Enter the number for math:\n");
	scanf("%d",&math);
	printf("Enter the number for science:\n");
	scanf("%d",&science);
	printf("Enter}*/
#include<stdio.h>
int prime(int n)
{
	int i,prime=1;
	for(i=2;i<n;i++){
		if(n%i==0)
			prime=0;
	}
	if(prime==1)
		printf("%d  ",n);
 }
int main()
{
	int j;
	for(j=2;j<100;j++){
	prime(j);
	}
	return 0;
}
 the number for physics:\n");
	scanf("%d",&physics);
	printf("Enter the number for chemistry:\n");
	scanf("%d",&chemistry);
	printf("Enter the number for english:\n");
	scanf("%d",&english);

	sum = math+science+physics+chemistry+english;
	//The total marks = 500;
	if(sum>450&&sum<500){
		printf("You have got grade = A:\n");
	}
	else if(sum>300&&sum<=450){
		printf("You have got grade = B:\n");
	}
	else if(sum>150&&sum<=300){
		printf("You have got grade = c:\n");
	}
	else
		printf("You are failed:");
	return 0;
}*/
/*#include<stdio.h>
int gcd(int a, int b)
{
	if(a==b)
	{
		return a;
	}
	else if(a<b)
	{
	      a=a;
	      b=b-a;
	      return gcd(a,b);
	      //return  gcd(a,b-a);
	}}*/
#include<stdio.h>
int prime(int n)
{
	int i,prime=1;
	for(i=2;i<n;i++){
		if(n%i==0)
			prime=0;
	}
	if(prime==1)
		printf("%d  ",n);
 }
int main()
{
	int j;
	for(j=2;j<100;j++){
	prime(j);
	}
	return 0;
}

	else
	{
		a=a-b;
		b=b;
		return gcd(a,b);
		//return gcd(b,a-b);
	}
}

int main()
{
	int a,b,hcf,lcm;

	printf("Enter the two number:\n");
	scanf("%d%d",&a,&b);

	hcf = gcd(a,b);
	printf("%d\n",hcf);
	lcm = (a*b)/hcf;
	printf("%d\n",lcm);

	return 0;
}*/
/*#include<stdio.h>
int main()
{
	int i,n,prime=1;
	printf("Enter the number:\n");
	scanf("%d",&n);

	for(i=2;i<n;i++){
		if(n%i==0){
			prime = 0;}
	}
	if(prime==0)}*/
#include<stdio.h>
int prime(int n)
{
	int i,prime=1;
	for(i=2;i<n;i++){
		if(n%i==0)
			prime=0;
	}
	if(prime==1)
		printf("%d  ",n);
 }
int main()
{
	int j;
	for(j=2;j<100;j++){
	prime(j);
	}
	return 0;
}

		printf("Number is not prime:=%d",prime);
	else
		printf("number is prime:=%d",prime);
	return 0;
}*/
/*#include<stdio.h>
int main()
{
	int a=0,b=1,i,next=a+b,n;
	printf("Enter the number");
	scanf("%d",&n);

	printf("%d %d ",a,b);

	for(i=0;i<=n;i++){
		printf("%d ",next);
		a=b;
		b=next;
		next=a+b;
	}
	return 0;
}*/
/*#include<stdio.h>
#include<math.h>
int main()
{
	int i,j,k,l,count=0,n,sum=0;
	printf("Enter the number:\n");
	scanf("%d",&n);
	k=i=n;
        while(n!=0){
		l=n%10;
5		n=n/10;
		count++;
	}
	while(i!=0){
		l=i%10;
		sum+=pow(l,count);
		i=i/10;
	}
	sum==k?printf("The number = %d is armstrong:\n",sum):printf("The number = %d is not armstrong:\n",sum);
	//printf("%d",count);
	return 0;
}*/
/*#include<stdio.h>
int main()
{
	int a,i,n,j,k,sum=0;

	printf("Enter the number:\n");
	scanf("%d",&n);

	for(i=1;i<=n;i++){
		a=n%i;
		if(a==0)
		sum+=i;
	      }
           k=sum/2;
	if(k==n)
		printf("The number is perfect = %d\n",k);
	else
		printf("The number is not perfect = %d\n",k);
	return 0;

}*/
/*#include<stdio.h>
int sum_of_digit(int n){
	int res=0,j;
    while(n!=0){
          j=n%10;
	  res=res+j;
	  n=n/10;
    }
        return res;
}
int main()
{
        int sum;
        printf("Enter the number:\n");
        scanf("%d",&sum);
	while(sum>9){
	   sum=sum_of_digit(sum);
	}
	printf("%d\n",sum);
        return 0;
}*/
#include<stdio.h>
int prime(int n)
{
	int i,prime=1;
	for(i=2;i<n;i++){
		if(n%i==0)
			prime=0;
	}
	if(prime==1)
		printf("%d  ",n);
 }
int main()
{
	int j;
	for(j=2;j<100;j++){
	prime(j);
	}
	return 0;
}









