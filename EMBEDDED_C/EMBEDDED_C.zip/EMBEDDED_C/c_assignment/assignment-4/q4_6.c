#include<stdio.h>
int fibo(int);
int i=0,n,a=0,b=1;
int main()
{
    int next;
    next=a+b;
    printf("Enter the number = ");
    scanf("%d",&n);
    printf("%d %d ",a,b);
    fibo(next);   
}
int fibo(int next)
{
    if(i<10){
    printf("%d ",next);
    a=b;
    b=next;
    next=a+b;
    i++; 
    fibo(next);
    }
 }
