#include<stdio.h>
int power(int,int);
int main()
{
    int n,p,res;
    printf("Enter the number and power = ");
    scanf("%d%d",&n,&p);
    res = power(n,p);
    printf("The no of power is = %d\n",res);
    return 0;
}
int power(int x,int y)
{
    if(y==0)
       return 1;
    else
       return x*power(x,y-1);
}