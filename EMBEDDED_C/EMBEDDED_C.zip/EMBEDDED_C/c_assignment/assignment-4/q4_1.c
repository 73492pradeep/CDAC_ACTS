#include<stdio.h>
void scanarr(int arr1[]);
void displayarr(int arr2[]);
void revarr(int arr3[]);
 int k=0,j=4;
int main()
{
    int arr[5];
    printf("Enter the element\n");
    scanarr(arr);
    printf("Element of arr:\n");
    displayarr(arr);
    printf("\nReverse of arr:\n");
    revarr(arr);
    return 0;
}
void scanarr(int arr1[])
{
    for(int i=0;i<5;i++)
        scanf("%d",&arr1[i]);
}
void displayarr(int arr2[])
{
        if(k<5){
        printf("%d ",arr2[k]);
        k++;
        displayarr(arr2);
        }
}
void revarr(int arr3[])
{
        if(j>=0){
        printf("%d ",arr3[j]);
        j--;
        revarr(arr3);
        }
}