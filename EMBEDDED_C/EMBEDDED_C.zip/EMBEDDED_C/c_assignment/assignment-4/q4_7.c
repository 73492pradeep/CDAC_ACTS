#include<stdio.h>
#include<math.h>
int decimal(int);
int octal(int x);
int hexa(int x);
int sum=0,oct=0,hex=0,c=0,d=0,e=0;
int main()
{
    int a;
    printf("Enter the number\n");
    scanf("%d",&a);
    decimal(a);
    printf("The decimal number is = %d\n",sum);
    octal(a);
    printf("The octal  number  is = %o\n",oct);
    hexa(a);
    printf("The hexa  number  is  = %x\n",hex);

    return 0;
}
int decimal(int x){
    int r;
    if(x!=0)
    {
        r = x%10;
        sum = sum + r*pow(2,c);
        c++;
        x = x/10;
        decimal(x);
    }   
}
int octal(int x){
    int r;
    if(x!=0)
    {
        r = x%10;
        oct = oct + r*pow(2,d);
        d++;
        x = x/10;
        octal(x);
    }   
}
int hexa(int x){
    int r;
    if(x!=0)
    {
        r = x%10;
        hex = hex + r*pow(2,e);
        e++;
        x = x/10;
        hexa(x);
    }   
}