#include<stdio.h>
void binary(int);
int c=0,d=0;
int main()
{
    int n;
    printf("Enter the binary no = ");
    scanf("%d",&n);
    binary(n);
    printf("No of zero is = %d\n",c);
    printf("NO of one is  = %d\n",d);
    return 0;
}
void binary(int n)
{
    if(n!=0){
        int rem = n%10;
            if(rem==0)
               c++;
            else if(rem==1)
               d++;
        n = n/10;
        binary(n);
    }
}