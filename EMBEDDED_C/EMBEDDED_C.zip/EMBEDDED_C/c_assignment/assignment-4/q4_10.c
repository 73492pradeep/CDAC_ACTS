#include<stdio.h>
void count_digit(int);
int count=0;
int main()
{
    int n;
    printf("Enter the binary no = ");
    scanf("%d",&n);
    count_digit(n);
    printf("NO of one is  = %d\n",count);
    return 0;
}
void count_digit(int n)
{
    if(n!=0){
        int rem = n%10;
            count++;
        n = n/10;
        count_digit(n);
    }
}