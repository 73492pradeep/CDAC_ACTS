#include<stdio.h>
void scanarr(char str[]);
void displayarr(char str1[]);
void revarr(char astr2[]);
int k=0,j=4;
int main()
{
    char str[5];
    printf("Enter the element\n");
    scanarr(str);
    printf("Element of str:\n");
    displayarr(str);
    printf("\nReverse of str:\n");
    revarr(str);
    return 0;
}
void scanarr(char str[])
{
    for(int i=0;i<5;i++)
        scanf("%c",&str[i]);
}
void displayarr(char str1[])
{
        if(k<5){
        printf("%c",str1[k]);
        k++;
        displayarr(str1);
        }
}
void revarr(char str2[])
{
        if(j>=0){
        printf("%c",str2[j]);
        j--;
        revarr(str2);
        }
}