#include<stdio.h>
int fact(int n);
int main(){
	int num;
	printf("Enter the Number");
	scanf("%d",&num);
	if(num<0)
		printf("There is no factorial for negative numebr");
	else
	printf("factorial of %d is %d\n",num,fact(num));

	return 0;
}
int fact(int n){
	if(n==0)
	return 1;
	
	return (n * fact(n-1));
}
