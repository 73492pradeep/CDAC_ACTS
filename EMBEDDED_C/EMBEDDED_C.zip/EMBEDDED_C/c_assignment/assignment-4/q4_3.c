#include<stdio.h>
void add(int n);
int res=0;
int i=1;
int main()
{
    int n;
    printf("Enter the number : ");
    scanf("%d",&n);
    add(n);
    printf("The sum is = %d\n",res);
    return 0;
}
void add(int n)
{
    if(i<=n){
        res = res + i;
        i++;
        add(n);
    }
}