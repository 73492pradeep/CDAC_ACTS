//use of mmcpy in program
#include<stdio.h>
#include<string.h>
int main(){
	char arr[19]="angad";
	char t[10]="aray";
	puts("string 1 before copy");
	puts(arr);
	memcpy(arr,t,4);
	puts("\n string after memcpy");
	puts(arr);
	return 0;
}
