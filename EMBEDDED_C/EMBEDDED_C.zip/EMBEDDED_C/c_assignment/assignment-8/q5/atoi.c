//string to integer
#include<stdio.h>
#include<string.h>
int main(){
	char str[10];
	printf("Enter the string");
	scanf("%s",str);
	int arr[10];
	int i=0;
	while(str[i]!='\0'){
		arr[i]=str[i]-48;
		printf("%d",arr[i]);
		i++;
	}
	return 0;
}

