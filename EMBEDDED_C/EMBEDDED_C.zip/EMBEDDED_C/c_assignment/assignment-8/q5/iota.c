//integer to string;
#include<stdio.h>
void convert(int );
int main(){
	int a;
	printf("Enter the integer");
	scanf("%d",&a);
	convert(a);
	return 0;
}
void convert(int a){
	int i=0;
	char str[99];
	while(a!=0){
		str[i]=a%10;
		a=a/10;
		i++;
	}
	int len=strlen(str)-1;
	for(int j=len;j>=0;j--){
		printf("%d",str[len]);
	}
}
