/*
 *	Q10. Convert the string in a.b.c.d format into 32 bit unsigned integer
 *	(use pointer operations for packing purpose).
 */



#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <inttypes.h>
#include <string.h>

#define SIZE 20

int main()
{
	int n;
	char c[SIZE];
	char *s;
	uint32_t i32;
	uint32_t *pi32;

	s = c;
	pi32 = &i32;

	printf("Enter a string: ");
	scanf("%s", s);
	printf("\n");
	
	n = strlen(s);
	
	int size = (n/4);
	size += n%4 != 0? 1:0;

	pi32 = (uint32_t *)malloc(size);
	
	printf("sizeof(n) = %d\n", n);
	printf("sizeof(size) = %d\n", size);

	for(int i = 0; i < size; i++)
	{
		for(int j = 0; j < 4; j++){
			*(pi32 + i) <<= 8;
			*(pi32 + i) |= s[4*i + j];
		}
			printf("Result %d = %x\n", i, *(pi32 + i));
			*(pi32 + i) <<= 8;
	}



	free(pi32);

  return EXIT_SUCCESS;
}
