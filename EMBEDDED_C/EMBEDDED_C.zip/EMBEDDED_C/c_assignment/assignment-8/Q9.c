/*
 * Q9. Write a c program to find sum & avg of command line arguments
 * */


#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>


int add(int n, char v[])
{
	int r = 0;
	for(int i = 0; i < 2*n; i++){		//2*n because it considers the spaces between aruments
		r += atoi(v + i);
	}
	return r;
}

float avr(int n, char v[])
{
	int r = 0;
	for(int i = 0; i < 2*n; i++)
		r += atoi(v + i);
	return (float)r/(n - 2);
}

//param 0 = ./a.out
//param 1 = option
//param 2 - inf: numbers
int main(int argc, char *argv[])
{
	switch (atoi(argv[1]))
	{
		case 1:
			printf("add = %d\n",add(argc, *(argv + 2)));
			break;
		case 2:	
			printf("avr = %f\n",avr(argc, *(argv + 2)));
			break;
		default:
			printf("err: wrong option.");
			break;
	
	}

  return EXIT_SUCCESS;
}
