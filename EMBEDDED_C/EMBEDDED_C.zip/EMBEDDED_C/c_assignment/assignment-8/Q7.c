/*
 * Q7. Implement generic swap function (which swap variables of any
type,Hint:-memcpy)
*/

#include <stdio.h>
#include <stdio_ext.h>
#include <string.h>
#include <stdlib.h>
#include <inttypes.h>


	

void *swap(void *x, void *y)
{
	//memcpy
	//The C library function void *memcpy(void *dest, const void *src, size_t n)
	//copies n characters from memory area src to memory area dest.
					//  y y+1	 x
	memcpy(y+1, x, sizeof(*x));	// |y||x|	|x|
					// 
	memcpy(x, y ,sizeof(*y));	// |y||x|	|y|
	memcpy(y, y+1, sizeof(*(y+1))); // |x||x|	|y|	
	bzero(y+1, 1);			// |x||\0|	|y|	
}


int main()
{
	int a = 0, b = 1;
	int *pa = &a;
	int *pb = &b;
	
	printf("Before swapping: \n");
	printf("Y location: %d (add. %p)\nX location: %d (add. %p)\n", a, pa, b, pb);
	swap(pa, pb);
	printf("After swapping: \n");
	printf("Y location: %d (add. %p)\nX location: %d (add. %p)\n", a, pa, b, pb);

	return 0;


}
