/*
 * Q6. Explore the following functions used for raw memory operations.
memcpy, memcmp, memset, bzerotrtof, strtod etc
*/

#include <stdio.h>
#include <stdio_ext.h>
#include <string.h>
#include <stdlib.h>
#include <inttypes.h>

int main()
{	char src[20];
	char dest[20];
	char str[20];

	//memcpy
	//The C library function void *memcpy(void *dest, const void *src, size_t n)
	//copies n characters from memory area src to memory area dest.
	printf("*memcpy: \n");
	printf("Enter a string: \n");
	scanf("%[^\n]s", src);

	printf("\nBefore copy: %s\n", dest);
	printf("Copied from %p to %p.\n", src, memcpy(dest, src, strlen(src)+1));
	printf("\nAfter copy: %s\n", dest);
	
	//memcmp
	//The C library function int memcmp(const void *str1, const void *str2, size_t n))
	// compares the first n bytes of memory area str1 and memory area str2.	
	printf("*memcmp: \n");
	printf("Enter a second string: \n");
	__fpurge(stdin);
	scanf("%[^\n]s", str);
	
	int equal = memcmp(dest, str, strlen(str));

	printf("Equal: %d\n", equal);
	if (equal != 0)
		printf("Are different.\n");
	else
		printf("Are equal.\n");

	//The C library function void *memset(void *str, int c, size_t n) copies the character
	//c (an unsigned char) to the first n characters of the string pointed to, by the argument str.		
	printf("*memset: \n");
	memset(str, 'a', 3);	
	printf("Modified memory: %s\n", str);
	
	// The bzero() function erases the data in the n bytes of the memory
        // starting at the location pointed to by s, by writing zeros (bytes
        // containing '\0') to that area.	
	printf("*bzero: \n");
	bzero(str + 1, 1);	
	printf("Modified memory: %s\n", str);

	return 0;


}
