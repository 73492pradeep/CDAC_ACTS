#include<stdio.h>
#include<stdio.h>
int occurrence(char *ptr1);
int main()
{
    char arr[20];
    char *ptr=arr;
    printf("Enter the string: ");
    gets(ptr);
    occurrence(ptr);
    return 0;
}
int occurrence(char *ptr1)
{
    char ch;
    int j;
    printf("Enter the char for occur: ");
    scanf("%c",&ch);
    for(int i=0;ptr1[i]!='\0';i++){
        if(ptr1[i]==ch){
            j = i;
        }
    }
    printf("The last %c occurr is = %d index\n",ch,j);
}
