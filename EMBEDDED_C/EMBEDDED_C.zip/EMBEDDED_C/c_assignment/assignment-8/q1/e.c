#include<stdio.h>
int main()
{	
	int count=0,i=0;
	char str[10]="cdac";
	while(str[i]!='\0')
	{
		count++;
		i++;
	}
	printf("Reversed string:\t");
	for(int i=count;i>=0;i--)
	{
		printf("%c",str[i]);
	}
	return 0;
}
