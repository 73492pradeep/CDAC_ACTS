#include<stdio.h>
int main(){
	int i;
	char a[]="cdac-acts";
	char b[10];
	while(a[i]!='\0'){
		b[i]=a[i];
		printf("%c",b[i]);
		i++;
	}
	b[10]='\0';
}	
