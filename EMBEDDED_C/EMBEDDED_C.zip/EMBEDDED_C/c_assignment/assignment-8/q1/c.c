#include<stdio.h>
int main(){
	int i=0,j=4;
	char str1[20]="cdac";
	char str2[15]="desd";
	while (str1[i]!='\0')
	{
		str2[j]=str1[i];
		i++;
		j++;
	}
	str2[j]='\0';
	puts(str2)];
}




