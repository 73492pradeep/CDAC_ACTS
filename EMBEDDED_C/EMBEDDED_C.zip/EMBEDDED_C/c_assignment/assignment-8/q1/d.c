#include<stdio.h>
#include<string.h>
int main(){
	char str1[20];
	char str2[20];
	gets(str1);
	gets(str2);
	if((strcmp(str1,str2))==0)
		printf("Strings are same");
	else
		printf("strings are not same");
	return 0;

}

