#include<stdio.h>
#include<string.h>
int main () {
	int n;
	printf("Enter Size of String : ");
	//scanf("%d",&n);
	char str[50];
	printf("Enter Main String : ");
	fgets(str, 50, stdin);
	char sub[20];
	printf("Enter Sub String : ");
	scanf("%s",sub);

	int len = strlen(sub);

	char temp[len];
	for(int i =0; i<strlen(str)-1; i++) {
		temp[i] = str[i];
	}
	printf("Temp String : %s\n",temp);

	return 0;
}



