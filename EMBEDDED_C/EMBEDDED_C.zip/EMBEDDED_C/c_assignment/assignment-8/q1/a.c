//finding length
#include<stdio.h>
int main()
{	
	int i=0,count=0,count2=0;
	char a[]="cdac-acts";
	char *s="desd";
	while(a[i]!='\0'){
		count++;
		i++;
	}
	printf("Legth using array approach=%d",count);
	while(*s!='\0'){	
		count2++;
		s++;
	}	
	printf("length using pointer approach=%d",count2);
}
