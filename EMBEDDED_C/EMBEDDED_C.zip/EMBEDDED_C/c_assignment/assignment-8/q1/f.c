//find the first occurance of given charactor by the pointer
#include<stdio.h>
#include<string.h>
int occur(char *);
int main(){
	char *arr="angad chauhan";
	int ans=occur(arr);
	printf("first occrance index number is==%d",ans);
        return 0;
}
int occur(char *arr){
	char ch;
	printf("enter the charactor");
        scanf("%c",&ch);
        for(int i=0;i<strlen(arr);i++){
	if(ch==arr[i]){
		return i;
}
}}
