//conctenation of two string by the sprintf
#include<stdio.h>
int main()
       {
	       char *arr="hey what are you doing here";
	       char *mrr="you should complete your task";
	       char tg[200];
	       sprintf(tg,"%s%s",mrr,arr);
	       printf("%s",tg);
	       return 0;
 }

	
