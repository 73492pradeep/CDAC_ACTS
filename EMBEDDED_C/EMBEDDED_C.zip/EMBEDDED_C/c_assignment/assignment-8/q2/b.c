//copy one string to other by the help of sprintf
#include<stdio.h>
int main(){
	char *a="dont copy its not right ";
	char b[100];
	sprintf(b,"%s",a);
	printf("%s",b);
	return 0;
}

