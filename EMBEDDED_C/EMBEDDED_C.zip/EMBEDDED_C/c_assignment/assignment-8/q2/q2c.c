#include<stdio.h>
#include<string.h>
#include<stdio_ext.h>

int main() {
	char str1[50];

	printf("Enter String 1 : ");
	scanf("%[^\n]s",str1);
	__fpurge(stdin);

	printf("Length of string : %ld\n", strlen(str1));
	int i = 0, count = 0;
	while (str1[i] != '\0') {
		count++;
		i++;
	}



	char buff[10];
	sprintf(buff, "%d", count);

	printf("String Length : %s\n",buff);

	return 0;
}



