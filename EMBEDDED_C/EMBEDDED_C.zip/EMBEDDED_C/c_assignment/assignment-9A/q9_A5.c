#include<stdio.h>
#include<string.h>
#include<stdio_ext.h>

  struct user
            {
		    char name[20];
		    char gender;
		    char city[10];
		    char m_status[10];
		    int age;
		    int pin_code;
		    float salary;
	    };
int main()
{
	struct user ur;
	printf("Enter the name     = ");
	scanf("%[^\n]s",ur.name);
	//fgets(ur.name,20,stdin);
	printf("Enter the gender   = ");
	__fpurge(stdin);
	//scanf("%c",&ur.gender);
	ur.gender=getchar();
	printf("Enter the city     = ");
	scanf("%s",ur.city);
	printf("Enter the m_status = ");
	scanf("%s",ur.m_status);
	printf("Enter the age      = ");
	scanf("%d",&ur.age);
	printf("Enter the pin_code = ");
	scanf("%d",&ur.pin_code);
	printf("Enter the salary   = ");
	scanf("%f",&ur.salary);
	
	printf("Name     = %s\n",ur.name);
	printf("Gender   = %c\n",ur.gender);
	printf("City     = %s\n",ur.city);
	printf("M_status = %s\n",ur.m_status);
	printf("Age      = %d\n",ur.age);
	printf("Pin_code = %d\n",ur.pin_code);
	printf("Salary   = %.2f\n",ur.salary);

        return 0;

}

