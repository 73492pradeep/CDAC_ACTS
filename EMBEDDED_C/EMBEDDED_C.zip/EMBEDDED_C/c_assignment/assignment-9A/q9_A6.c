#include<stdio.h>
#include<string.h>
struct user
            {
		    char name[36];
		    char gender;
		    char city[36];
		    char m_status[36];
		    int age;
		    int pin_code;
		    float salary;
	    };
int main()
{
	struct user ur;
	printf("Enter the name     = ");
	scanf("%[^\n]s",ur.name);
	printf("Enter the gender   = ");
	scanf("%c",&ur.gender);
	printf("Enter the city     = ");
	scanf("%s",ur.city);
	printf("Enter the m_status = ");
	scanf("%s",ur.m_status);
	printf("Enter the age      = ");
	scanf("%d",&ur.age);
	printf("Enter the pin_code = ");
	scanf("%d",&ur.pin_code);
	printf("Enter the salary   = ");
	scanf("%f",&ur.salary);
	printf("Name     = %s\n",ur.name);
	printf("Gender   = %c\n",ur.gender);
	printf("City     = %s\n",ur.city);
	printf("M_status = %s\n",ur.m_status);
	printf("Age      = %d\n",ur.age);
	printf("Pin_code = %d\n",ur.pin_code);
	printf("Salary   = %.2f\n",ur.salary);
	char choice;
	printf("Enter the choice for modify:");
	scanf(" %c",&choice);
	if(choice=='m'||choice=='M')
	{
	   printf("Enter the name     = ");
	   scanf("%[^\n]s",ur.name);
	   printf("Enter the gender   = ");
	   scanf("%c",&ur.gender);
	   printf("Enter the age      = ");
	   scanf("%d",&ur.age);
	
	   printf("After modification:\n");
	   printf("New name = %s\n",ur.name);
	   printf("Gender   = %c\n",ur.gender);
	   printf("Age      = %d\n",ur.age);
	}

        return 0;

}

