#include<stdio.h>
#include<stdlib.h>
#include<stdio_ext.h>
struct reg{
	char *name;
	int age;
	char gender;
	char *city;
	 int Pincode;
	char Martial_status[20];
	int  annual_salary;
} ;
int main(){
	struct reg v1;
	v1.name=(char*)malloc(50*(sizeof(char)));
	v1.city=(char*)malloc(50*(sizeof(char)));
	printf("Enter the name\n");
	__fpurge(stdin);
	scanf("%[^\n]s",v1.name);
	printf("Enter the age\n");
	scanf("%d",&v1.age);
	printf("Enter the gender\n");
	scanf(" %c",&v1.gender);
	printf("Enter the city\n");
	__fpurge(stdin);
	scanf("%[^\n]s",v1.city);
	printf("Enter the pincode\n");
	scanf("%d",&v1.Pincode);
	printf("Enter the Martial status\n");
	scanf("%s",v1.Martial_status);
	printf("Enter the annual salary\n");
	scanf("%d",&v1.annual_salary);
	printf("name=%s\n",v1.name);
	printf("age=%d\n",v1.age);
	printf("gender=%c\n",v1.gender);
	printf("city=%s\n",v1.city);
	printf("Pincode=%d\n",v1.Pincode);
	printf("Martial Status=%s\n",v1.Martial_status);
	printf("Annual salary =%d\n",v1.annual_salary);

	return 0;
}

