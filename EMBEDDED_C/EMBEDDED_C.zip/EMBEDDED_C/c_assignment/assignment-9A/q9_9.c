#include<stdio.h>
struct student
{
	char name[30];
	int age;
	int rollno;
	char gender;
};
void display(struct student var1[]);
int main()
{
	struct student v1[2];
	printf("Enter the data of 1st student:\n");
	printf("Enter the name of 1st student:\n");
	scanf("%s",v1[0].name);
	printf("Enter age of the 1st student:\n");
	scanf("%d",&v1[0].age);
	printf("Enter rollno of the 1st student:\n");
	scanf("%d",&v1[0].rollno);
	printf("Enter gender of the 1st stuent:\n");
	scanf(" %c",&v1[0].gender);

	printf("Enter the data of 2nd stuent:\n");
	printf("Enter the name of 2nd student:\n");
	scanf("%s",v1[1].name);
	printf("Enter age of the 2nd student:\n");
	scanf("%d",&v1[1].age);
	printf("Enter the rollno. of 2nd student:\n");
	scanf("%d",&v1[1].rollno);
	printf("Enter the gender of student:\n");
	scanf(" %c",&v1[1].gender);

        display(v1);
        
	
        
return 0;
}
void display(struct student var1[]){
 {
		char name[30];
		int age;
		int rollno;
		char gender;
	};
	printf("Name=%s\n",var1[0].name);
	printf("age=%d\n",var1[0].age);
	printf("rollno.=%d\n",var1[0].rollno);
	printf("gender=%c\n",var1[0].gender);
	printf("Name=%s\n",var1[1].name);
	printf("age=%d\n",var1[1].age);
	printf("rollno.=%d\n",var1[1].rollno);
	printf("gender=%c\n",var1[1].gender);
}




