#include<stdio.h>

  struct rectangle 
                {
			int length;
			int breadth;
			int area;
		};
int main()
{
	struct rectangle ar;
	printf("Enter the length = ");
	scanf("%d",&ar.length);
	printf("Enter the breadth = ");
	scanf("%d",&ar.breadth);
	ar.area=(ar.length*ar.breadth);
	printf("The area of rectangle is = %d\n",ar.area);
	return 0;
}

