#include<stdio.h>
struct data{
	   char name[10];
	   char branch[10];
	   int pnr;
};
struct data fun();
int main()
{
	struct data var=fun();
	printf("Name   = %s\n",var.name);
	printf("Branch = %s\n",var.branch);
	printf("Pnr no.= %d\n",var.pnr);
	return 0;
}
struct data fun()
{
	struct data var1;

               printf("Enter the name   : ");
	       scanf("%s",var1.name);
               printf("Enter the branch : ");
	       scanf("%s",var1.branch);
               printf("Enter the pnr    : ");
	       scanf("%d",&var1.pnr);
               printf("\n\n");

	return var1;

}



