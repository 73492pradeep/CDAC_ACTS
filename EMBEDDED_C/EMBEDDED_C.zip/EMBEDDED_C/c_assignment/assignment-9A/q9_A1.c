pri#include<stdio.h>
 
  struct named
            {
		    int num1;
		    int num2;
		    int sum;
	    };
int main()
{
  struct named ad;
       printf("Enter the num1 for addition:\n");
       scanf("%d",&ad.num1);
       printf("Enter the num2 for addition:\n");
       scanf("%d",&ad.num2);
       ad.sum=ad.num1+ad.num2;
       printf("The sum is = %d\n",ad.sum);
       return 0;
}

