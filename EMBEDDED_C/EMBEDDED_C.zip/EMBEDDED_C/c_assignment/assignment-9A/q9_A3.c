#include<stdio.h>
  
    struct rectangle
                   {
			   int length;
			   int breadth;
			   int area;
		   };
int main()
{
	struct rectangle a[3];
	printf("Enter the number for length and breadth: = ");
	/*for(int i=0;i<3;i++){
		scanf("%d %d",&a[i].length,&a[i].breadth);
	}
	for(int j=0;j<3;j++){
		a[j].area=a[j].length*a[j].breadth;
		printf("The area of %d rect is = %d\n",j,a[j].area);
	}*/
	scanf("%d %d",&a[0].length,&a[0].breadth);
	a[0].area=a[0].length*a[0].breadth;
	scanf("%d %d",&a[1].length,&a[1].breadth);
	a[1].area=a[1].length*a[1].breadth;
	scanf("%d %d",&a[2].length,&a[2].breadth);
	a[2].area=a[2].length*a[2].breadth;
	printf("The area of first rect is = %d\n",a[0].area);
	printf("The area of second rect is = %d\n",a[1].area);
	printf("The area of third rect is = %d\n",a[2].area);

	return 0;
}
