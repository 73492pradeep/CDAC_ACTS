#include<stdio.h>
 
  struct area
            {
               int length;
	       int breadth;
	       int area;
	    };
void fun(struct area v);
int main()
{
	struct area ar;

	printf("Enter the length breadth = ");
	scanf("%d %d", &ar.length ,&ar.breadth);
        ar.area=ar.length*ar.breadth;
	printf("Area is inside the structure= %d", ar.area);

	fun(ar);
	return 0;
}
void fun(struct area v)
{
	v.area=v.length*v.breadth;
	printf("\nArea is inside function = %d\n", v.area);
}
