#include<stdio.h>
#include<assert.h>
int main()
{
    int a=10;
    int *ptr=&a;
    assert(*ptr>9);
    printf("%d\n",*ptr);
    
    return 0;
}