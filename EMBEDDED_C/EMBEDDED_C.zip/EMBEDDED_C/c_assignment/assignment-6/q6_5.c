#include<stdio.h>
int main()
{
    int a = 2233;
    char ch = 'A';
    float f = 21.44f;
    double d = 22.11;
    // void *p=(char*)&ch;
    // printf("%c\n",*(char*)p);
    // p=(float*)&f;
    // printf("%.2f\n",*(float*)p);
    // p=(double*)&d;
    // printf("%.2lf\n",*(double*)p);
    // p=(int*)&a;
    // printf("%d\n",*(int*)p);

    int *p1=(int*)&ch;
    printf("%c\n",*(int*)p1);
    p1=(float*)&f;//we cannot chang of priovious declearation of pointer
    printf("%.2f\n",*(float*)p1);
    return 0;
}