#include<stdio.h>
int main()
{
    unsigned short int a = 0x1122;
    char *ptr=(char*) &a;
    
    for(int i=0;i<2;i++)
        printf("%x",ptr[i]);
    printf("\nlittle endian to big endian\n");
    for(int i=1;i>=0;i--)
        printf("%x",ptr[i]);
    return 0;
}
