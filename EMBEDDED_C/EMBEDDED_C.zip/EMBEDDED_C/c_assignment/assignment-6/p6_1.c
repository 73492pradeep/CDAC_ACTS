#include<stdio.h>
int main()
{
	char *pradeep;
	int var=11223344;
	pradeep=&var;
	if (*pradeep==0x11223344)
		printf("little endian");
	else 
		printf("big endian");

	return 0;
}

