#include<stdio.h>
int main()
{
    int arr[3][4]={{1,2,3,4},{5,6,7,8},{9,10,11,12}};
    //int arr[4]={2,3,4,5};
    int (*p)[4];
    p=(int*)(&arr+1);
    printf("%d\n",*(*(p-1)+3));
    //printf("%d\n",*(*p-1));
    return 0;
}