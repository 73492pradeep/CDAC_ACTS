#include<stdio.h>
int main()
{
	int x =10;
	const int *p=&x;
	//int const *p;
	//int *const p;
	//const int *const p;
	printf("x = %d\n",x);
	printf("*p = %d\n",*p);
	//printf("x = %d\n",x);
	//printf("x = %d\n",x);
return 0;
}
