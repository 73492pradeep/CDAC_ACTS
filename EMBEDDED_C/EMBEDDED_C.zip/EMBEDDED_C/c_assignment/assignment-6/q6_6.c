#include<stdio.h>
int main()
{
    int x;
    double y,z;
    int a = 20;
    int b = 10;
    float f = 25.44f;
    double d = 22.11;
    void *p=(int*)&a;
    void *p1=(int*)&b;
    void *res;
    x = *(int*)p + *(int*)p1;
    res=(int*)&x;
    printf("%d\n",*(int*)res);
    p=(float*)&f;
    p1=(double*)&d;
    y=*(float*)p-*(double*)p1;
    res=(double*)&y;
    printf("%.2f\n",*(double*)res);
    p=(int*)&a;
    p1=(double*)&d;
    z=*(double*)p1-*(int*)p;
    res=(double*)&z;
    printf("%.2f\n",*(double*)res);
    return 0;
}