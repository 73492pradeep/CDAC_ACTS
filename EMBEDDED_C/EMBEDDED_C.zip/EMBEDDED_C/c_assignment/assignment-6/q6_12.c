#include<stdio.h>
int main()
{
    int arr[3][4]={1,2,3,4,5,6,7,8,9,10,11,12};
    int (*q)[3][4];
    q=&arr;
    // printf("%d\t",sizeof(q));
    // printf("%d\t",sizeof(*q));
    // printf("%d\t",sizeof(**q));
    // printf("%d\t",sizeof(***q));

    printf("%d\t",*(*(*(q+0)+0)+1));
    printf("%d\t",*(q[0][1]+1));
    printf("%d\t",*(*(q[0]+2)+3));
    printf("%d\t",q[0][2][1]);

    // for(int i=0;i<3;i++){
    //     for(int j=0;j<4;j++){
    //         printf("%d\t",q[0][i][j]);
    //     }
    //     printf("\n");
    // }
       return 0;
}