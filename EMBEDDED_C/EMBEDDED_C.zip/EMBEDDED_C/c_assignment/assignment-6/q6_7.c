#include<stdio.h>
int main()
{
    int arr[5]={2,3,4,5,6};
    int (*par)[5]=&arr;
    printf("%d\t",sizeof(arr));   //20 b
    printf("%d\t",sizeof(par));   //8 b
    printf("%d\t",sizeof(*par));  //20 b
    printf("%d\t",sizeof(**par)); //4 b

    printf("%d\t",*(par[0]+0));   
    printf("%d\t",*(par[0]+1));   
    printf("%d\t",*(par[0]+2));  
    printf("%d\t",*(par[0]+3)); 
    return 0;
}