#include<stdio.h>
int main()
{
	int a[5]={10,20,30,40,50,};
	int *q=a;
	//int *p=*(&a+1)-1;
	printf("*q++  =%d\n",*q++);      //10 1004
	printf("*++q  =%d\n",*++q);      //30 1008
	printf("(*q)++=%d\n",(*q)++);    //30 1008
	printf("++(*q)=%d\n",++(*q));    //32 1008
	printf("++*q  =%d\n",++*q);      //33 1008
	printf("*(q++)=%d\n",*(q++));    //33 1012
	printf("*(++q)=%d\n",*(++q));    //50   1016

	/*printf("*p--  =%d\n",*p--);   //50  1012
	printf("*--p  =%d\n",*--p);     //30  1008
	printf("--(*p)=%d\n",--(*p));   //29  1008
	printf("--*p  =%d\n",--*p);     //28  1008
	printf("(*p)--=%d\n",(*p)--);   //28  1008
	printf("*(p--)=%d\n",*(p--));   //27  1004
	printf("*(--p)=%d\n",*(--p));   //10  1000*/
	return 0;
}

