#include<stdio.h>
int main()
{
    unsigned int a = 0x11223344;
    char *ptr=(char*) &a;
    
    for(int i=0;i<4;i++)
        printf("%x",ptr[i]);
    printf("\nlittle endian to big endian\n");
    for(int i=3;i>=0;i--)
        printf("%x",ptr[i]);
    return 0;
}
