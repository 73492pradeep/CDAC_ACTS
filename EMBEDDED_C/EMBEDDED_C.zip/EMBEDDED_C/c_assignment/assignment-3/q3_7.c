#include<stdio.h>
int main()
{
	int d,a = 10,b = 20,c = 30;

	d = ++a,++b,++c,a+5;
	printf("%d\n",d);  //11

	d = (++a,++b,++c,a+5);
	printf("%d\n",d);  //17

	printf("a=%d b=%d c=%d\n",a,b,c);//12,22,32
	return 0;
}

