#include<stdio.h>
int main()
{
    int a,b,temp;
    printf("Enter the number of a=");
    scanf("%d",&a);
    printf("Enter the number of b=");
    scanf("%d",&b);
    //swapping without temp using Ex-or operator

    printf("a=%d b=%d\n",a=a^b,b=a^b,a=a^b);

    //swapping with temp using Ex-or operator

     temp=a;
     a=b;
     b=temp;
    //  printf("after swapping a=%d\n",a);
    //  printf("after swapping b=%d\n",b);

    return 0;
}