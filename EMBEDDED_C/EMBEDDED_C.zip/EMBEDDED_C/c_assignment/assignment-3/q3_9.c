#include<stdio.h>
#include<math.h>
int decimal(int);
int octal(int);
int hexa(int);
int main()
{
    int a;
    printf("Enter the number\n");
    scanf("%d",&a);
    decimal(a);
    octal(a);
    hexa(a);
    return 0;
}
    //for(int i=0;a!=0;i++)
int decimal(int x){
    int sum=0,c=0,r;
    while(x!=0)
    {
        r = x%10;
        sum = sum + r*pow(2,c);
        c++;
        x = x/10;
    }
    printf("The decimal number is = %d\n",sum);
}
int octal(int y){
    int r,sum=0,c=0;
    while(y!=0)
    {
        r = y%10;
        sum = sum + r*pow(2,c);
        c++;
        y = y/10;
    }
    printf("The octal number is   = %o\n",sum);
}
int hexa(int z){
     int r,sum=0,c=0;
     while(z!=0)
    {
        r = z%10;
        sum = sum + r*pow(2,c);
        c++;
        z = z/10;
    }
    printf("The hexa number is    = %x\n",sum);
}