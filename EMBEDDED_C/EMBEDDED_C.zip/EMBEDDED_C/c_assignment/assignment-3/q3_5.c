#include<stdio.h>
void hr_to_sec();
void sec_to_hr(); 
int main()
{
    hr_to_sec();
    sec_to_hr();  

    return 0;
}
void hr_to_sec()
{
    int hr,min,sec,sum;
    printf("Enter tne value of Hr-Min-sec:\n");
    scanf("%d%d%d",&hr,&min,&sec);
    sum=hr*3600+min*60+sec;
    printf("sec = %d\n",sum);
}
void sec_to_hr()
{
    int second;
    printf("Enter tne value of sec:\n");
    scanf("%d",&second);
    int a,b,c,d;
    a=second/3600;
    b=second%3600;
    c=b/60;
    d=b%60;
    printf("Hr:Mn:Sc = %d:%d:%d\n",a,c,d);
}