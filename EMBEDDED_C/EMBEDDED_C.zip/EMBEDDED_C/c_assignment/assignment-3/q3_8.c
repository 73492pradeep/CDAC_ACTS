#include<stdio.h>
#define SIZE 5
int main()
{
	int n,sum=0;
	int arr[SIZE]={1,2,3,4,5};
	   for(int i=0;i<SIZE;i++)
	   {
		     sum+=arr[i];
	   }
	             printf("sum = %d\n",sum);
	             printf("avg = %d\n",sum/SIZE);

	   for(int i=0;i<SIZE;i++){
	         if(i==0)
		     printf("Min = %d\n",arr[i]);
	         else if(i==(SIZE-1))
		     printf("Max = %d\n",arr[i]);
           }
	   return 0;
}
