#include<stdio.h>
int printPascal(int n);
int call(int,int);
int fectorial(int x);
int main()
{
    int n;
    printf("Enter the number\n");
    scanf("%d",&n);
    printf("The pascal's triangle is:\n");
    printPascal(n);
    return 0;
}
int printPascal(int n)
{
    for(int i=0;i<n;i++){
              for(int j=i;j<n;j++){
                printf(" ");
              }
              for(int j=0;j<=i;j++){
                  printf("%d ",call(i,j));
              }
        
        printf("\n");
    }
}
int call(int n,int r)
{
    return fectorial(n)/(fectorial(r)*fectorial(n-r));
}
int fectorial(int n)
{
    if(n==0||n==1){
        return 1;
    }
    else
       return n*fectorial(n-1);
}