#include<stdio.h>
int main( void)
{
	int a,b,c;
	printf("enter three digits\n");
	scanf("%d%d%d",&a,&b,&c);
	(a>b&&a>c)?printf("a is greatest = %d\n",a):b>c?printf("b is greatest = %d\n",b):printf("c is greatest = %d\n",c);
	return 0;
}
