#include<stdio.h>
int main()
{
	int i,x,p,k,y,q;
	printf("Enter the number for i x e\n");
	scanf("%d%d%d",&i,&x,&p);

	k = i++;
	printf("%d\n",k);
	k = ++i;
	printf("%d\n",k);

	y = x++*10;
	printf("%d\n",y);
	y = ++x*10;
	printf("%d\n",y);
	 
	q = p--/3;
	printf("%d\n",q);
	q = --p/3;
	printf("%d\n",q);

	return 0;
}
