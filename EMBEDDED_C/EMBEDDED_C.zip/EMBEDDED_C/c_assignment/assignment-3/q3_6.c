#include<stdio.h>
int main()
{
	int a=23,b=13,c=12;
	float d=34.6546f,e=87.56746f;

        printf("%5d\n",a);  //_ _ _ 2 3
        printf("%05d\n",b); //0 0 0 1 3
        printf("%-5d\n",c); //1 2 _ _ _

        printf("%8.2f\n",d);//_ _ _ 3 4 . 6 5
        printf("%.2f\n",e); //8 5 . 5 6

	return 0;
}
       
        
