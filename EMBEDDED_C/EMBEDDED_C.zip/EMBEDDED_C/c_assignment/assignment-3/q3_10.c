#include<stdio.h>
int main()
{
    int date,month,year;
    printf("Enter the date month year\n");
    scanf("%d%d%d",&date,&month,&year); 
    if(year>=1900&&year<=1999)
    {
        int res,b,num,n;
            num=year%100;
            b=num/4;
            res=num+b+date;
                if(year%4==0&&month==1)
                     n=(res%7)-1;
                else if(year%4==0&&month==2)
                     n=((res+3)%7)-1;
                else if(month==1||month==10)
                     n=res%7;
                else if(month==2||month==3||month==11)
                     n=(res+3)%7;
                else if(month==4||month==7)
                     n=(res+6)%7;
                else if(month==5)
                     n=(res+1)%7;
                else if(month==6)
                     n=(res+4)%7;
                else if(month==8)
                     n=(res+2)%7;
                else if(month==9||month==12)
                     n=(res+5)%7;

         switch(n)  
              {  
                case 1: printf("Monday.\n");  
                     break;  
                case 2: printf("Tuesday.\n");  
                     break;  
                case 3: printf("Wednesday.\n");  
                     break;  
                case 4: printf("Thursday.\n");  
                     break;  
                case 5: printf("Friday.\n");  
                     break;  
                case 6: printf("Saturday.\n");  
                     break;  
                case 0: printf("Sunday.\n");  
                     break;  
              } 
    }
    return 0;
}