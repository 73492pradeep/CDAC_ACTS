/*1.#include<stdio.h>
int main()
{
	printf("Hellow world");
	return 0;
}*/
/*2.#include<stdio.h>
int main()
{
int a= 10;
int b= 4;
a = a+b;
b = a-b;
a = a-b;
printf("a = %d\nb = %d",a,b);
return 0;
}*/
/*3.#include<stdio.h>
int main()
{
	int i,j,k;
	for(i=1;i<=5;i++){
		for(j=i;j<5;j++){
			printf(" ");}
		for(k=1;k<=i;k++){
			printf("%d",i);}
		printf("\n");
	}

return 0;

}*/
/*4.#include<stdio.h>
int main()
{
	int a,b,c,d,e;
	a = 123;
	b = a%10;//3
	c = a/10;//12
        d = c%10;//2
        e = c/10;//1
   printf("%d%d%d",b,d,e);
	   return 0;
}*/
/*5.#include<stdio.h>
int main()
{
	int a,b,c;
	printf("Enter the number:");
	scanf("%d%d%d",&a,&b,&c);
        if(a>b&&a>c){
		printf("the greatest number is= %d",a);
	}
	else{
		if(b>c)
		{
			printf("The greatest number is = %d",b);
		}
		else{
			printf("the greatest number is = %d",c);
		}
	}
		return 0;
}*/
/*6.#include<stdio.h>
int main()
{
    char ch;
    printf("enter the char:");
    scanf("%c",&ch);
    if('A'||'E'||'I'||'O'||'U'||'a'||'e'||'i'||'o'||'u')
	    printf("char is vowel");
	   else
	     printf("char is consonant");
 
    return 0;
}*/
/*7.#include<stdio.h>
int main ()
{
  int year;
  printf("Enter the year\n");
  scanf("%d",&year);
  if(year%4==0)
  {
    printf("The year %d is leep year\n",year);
  }
  else{
   printf("The year %d is not a leep year\n",year);
  }
return 0;
}*/
/*8.#include<stdio.h>
int main ()
{
int n,sum,avg;
	printf("Enter the number:");
	scanf("%d",&n);
	sum = (n*(n+1)/2);
	printf("The sum is=%d\n",sum);
	avg = (n+1)/2;
	printf("The avg is=%d",avg);
	return 0;

}*/
/*9.#include<stdio.h>
int factorial(int n)
{
     if(n==0)
     {

           return 1;
     }
     else{
	   return n*factorial(n-1);
     }
}
int main()
{
	int num,ans;
	printf("Enter the num:\n");
	scanf("%d",&num);
	ans = factorial(num);
	printf("%d\n",ans);
	return 0;
}*/
/*10.#include<stdio.h>
int main()
{
	int i,j;
	for(i=1;i<=5;i++)
	{
		for(j=1;j<=i;j++ )
			printf("%d",i);
			printf("\n");
	}
	return 0;
}*/
/*11.#include<stdio.h>
int main()
{
	int i,j;
	for(i=1;i<=5;i++)
	{
		for(j=4;j>i-1;j--)
		{
			printf(" ");
		}
		for(j=1;j<=i;j++)
		{
			printf("%d",i);
		}
		printf("\n");
	}
	return 0;
}*/
/*12.#include<stdio.h>
int main()
{
        int i,j;
        for(i=1;i<=5;i++)
        {
                for(j=4;j>i-1;j--)
                {
                        printf(" ");
                }
                for(j=1;j<i*2;j++)
                {
                        printf("%d",i);
                }
                printf("\n");
        }
        return 0;
}*/



	
	
