#include<stdio.h>
#define MAX 10
int main()
{
	int temp,x;
	x=MAX-1;
	int arr[MAX] = {1,2,3,4,5,6,7,8,9,10};
	for(int i=0;i<MAX/2;i++){
		temp=arr[i];
		arr[i]=arr[x];
		arr[x]=temp;
		x--;
	}
	for(int i=0;i<MAX;i++){
		printf("%d ",arr[i]);
	}
	printf("\n");
	return 0;
}
	


