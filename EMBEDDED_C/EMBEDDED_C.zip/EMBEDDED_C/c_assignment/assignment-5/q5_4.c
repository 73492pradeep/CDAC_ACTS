#include<stdio.h>
#define SIZE 5
void add_Arr(int arr[],int arr1[],int arr2[]);
void print_Add_arr2(int arr2[]);
int main()
{
        int arr[SIZE]={2,4,6,8,1};
        int arr1[SIZE]={8,6,3,5,9};
        int arr2[SIZE];
        add_Arr(arr,arr1,arr2);
        print_Add_arr2(arr2);
	printf("\n");

        return 0;
}
void add_Arr(int arr[],int arr1[],int arr2[])
{
        for(int i=0;i<SIZE;i++)
                arr2[i]=arr[i]+arr1[i];
}
void print_Add_arr2(int arr2[])
{
        for(int i=0;i<SIZE;i++)
                printf("%d ",arr2[i]);
}

