#include<stdio.h>
int *findElement(int arr[]);
int main()
{
    int *a;
    int arr[5];
    a=findElement(arr);
        if(a==NULL)
       	        printf("NULL\n");
        else
                printf("Address of the element is %p\n",a);

  return 0;
}
int *findElement(int arr[])
{
	int n;
	for(int i=0;i<5;i++){
		scanf("%d",&arr[i]);
	        } 
	for(int k=0;k<5;k++){
		printf("%p ",&arr[k]);
		}
	printf("\nEnter thr number\n");
	scanf("%d",&n);

	for(int j=0;j<5;j++){
		if(arr[j]==n){
			return &arr[j];
		}
	}
	return NULL;
}



