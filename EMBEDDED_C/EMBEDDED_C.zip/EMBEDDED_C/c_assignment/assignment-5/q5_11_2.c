#include<stdio.h>
void scanarr(int arr[][3]);
void printarr(int arr[][3]);
void null_arr1(int arr[][3],int arr1[][3]);
void print_null_arr1(int arr1[][3]);
int main()
{
	int arr[3][3];
	int arr1[3][3];
	printf("Enter the arr ele = ");
	scanarr(arr);
	printarr(arr);
	null_arr1(arr,arr1);
	print_null_arr1(arr1);
	return 0;
}
void scanarr(int arr[][3])
{
	for(int i=0;i<3;i++)
		for(int j=0;j<3;j++)
			scanf("%d",&arr[i][j]);
}
void printarr(int arr[][3])
{
	for(int i=0;i<3;i++){
		for(int j=0;j<3;j++){
			printf("%d  ",arr[i][j]);
		}
	printf("\n");
	}
}
void null_arr1(int arr[][3],int arr1[][3])
{
	for(int i=0;i<3;i++){
		for(int j=0;j<3;j++){
				arr1[i][j]=(arr[i][j]*0);
			}
	printf("\n");
	}
}
void print_null_arr1(int arr1[][3])
{
	for(int i=0;i<3;i++){
		for(int j=0;j<3;j++){
			printf("%d  ",arr1[i][j]);
		}
	printf("\n");
	}
}



