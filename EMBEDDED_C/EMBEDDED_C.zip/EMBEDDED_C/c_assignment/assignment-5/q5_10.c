//For solving linear equations:
#include<stdio.h>
int main()
{

