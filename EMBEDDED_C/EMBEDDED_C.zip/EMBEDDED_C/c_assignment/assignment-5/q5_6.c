#include<stdio.h>
#define SIZE 3
void add_arr(int arr[][3],int arr1[][3],int arr2[][3]);
void sub_arr(int arr[][3],int arr1[][3],int arr3[][3]);
void mult_arr(int arr[][SIZE],int arr1[][SIZE],int arr4[][SIZE]);
void print_add_arr(int arr2[][3]);
void print_sub_arr(int arr3[][3]);
void print_mult_arr(int arr4[][SIZE]);
int main()
 {
	 int arr[3][3]={{1,2,3},{4,3,2},{7,6,5}};
	 int arr1[3][3]={{3,2,1},{1,0,1},{2,1,2}};
	 int arr2[3][3];
	 int arr3[3][3];
	 int arr4[SIZE][SIZE];
	 add_arr(arr,arr1,arr2);
	 print_add_arr(arr2);
	 printf("\n");
	 sub_arr(arr,arr1,arr3);
	 print_sub_arr(arr3);
	 printf("\n");
	 mult_arr(arr,arr1,arr4);
	 print_mult_arr(arr4);

	 return 0;
 }
void add_arr(int arr[][3],int arr1[][3],int arr2[][3])
{
	int i,j;
	for(i=0;i<=2;i++)
		for(j=0;j<=2;j++)
			arr2[i][j]=arr[i][j]+arr1[i][j];
}
void print_add_arr(int arr2[][3])
{
	int i,j;
	for(i=0;i<=2;i++){
	        for(j=0;j<=2;j++){
		      printf("%d\t",arr2[i][j]);
		}
		printf("\n");
	}
	
}
void sub_arr(int arr[][3],int arr1[][3],int arr3[][3])
{
	int i,j;
	for(i=0;i<=2;i++)
		for(j=0;j<=2;j++)
			arr3[i][j]=arr[i][j]-arr1[i][j];
}
void print_sub_arr(int arr3[][3])
{
	int i,j;
	for(i=0;i<=2;i++){
	        for(j=0;j<=2;j++){
		      printf("%d\t",arr3[i][j]);
		}
		printf("\n");
	}
}
void mult_arr(int arr[][SIZE],int arr1[][SIZE],int arr4[][SIZE])
{
	int i,j,k;
	for(i=0;i<SIZE;i++){
		for(j=0;j<SIZE;j++){
			arr4[i][j]=0;
			for(k=0;k<SIZE;k++){
		          arr4[i][j]+=arr[i][k]*arr1[k][j];
			}
		}
	}
}
void print_mult_arr(int arr4[][SIZE])
{
	int i,j;
	for(i=0;i<=2;i++){
	        for(j=0;j<=2;j++){
		      printf("%d\t",arr4[i][j]);
		}
		printf("\n");
	}
}
	





