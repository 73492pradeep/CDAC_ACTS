#include<stdio.h>
#include<math.h>
#define ROW 5
void scanarr(int arr[]);
void polynomial(int arr[],int,int);
int main()
{
    int n,x;
    int arr[ROW];
    printf("Enter the arr element = ");
    scanarr(arr);
    printf("Enter the degree of n = ");
    scanf("%d",&n);
    printf("Enter the number of x = ");
    scanf("%d",&x);
    polynomial(arr,n,x);
}
void scanarr(int arr[])
{
    for(int i=0;i<ROW;i++)
        scanf("%d",&arr[i]);
}
void polynomial(int arr[],int n,int x)
{
    int res=0;
    for(int i=0;i<ROW;i++){
        res = res + arr[i] * pow(x,n);
        n--;
    }
     printf("Polynomial evaluation = %d\n",res);
}