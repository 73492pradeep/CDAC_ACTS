#include<stdio.h>
void scanarr(int arr[]);
int checkarr(int arr[]);
int main()
{
	int x;
	int arr[10];
	printf("Enter the ten element for arr\n");
        scanarr(arr);
	x=checkarr(arr);
	if(x==-1)
            printf("The element is not found\n");
	else
	    printf("The element is found at location %d\n",x);
     return 0;
}
int checkarr(int arr[])
{
        int n;
	printf("Enter the one ele to find\n");
	scanf("%d",&n);
	for(int j=0;j<10;j++){
	        if(arr[j]==n)	
		    return j; 
	}
	return -1;
}
void scanarr(int arr[])
{
	for(int i=0;i<10;i++){
		scanf("%d",&arr[i]);
	}
}

