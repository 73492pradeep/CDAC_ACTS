#include<stdio.h>
void scanarr(int arr[][3]);
int identity(int arr[][3]);
int main()
{
    int result;
    int arr[3][3];
    printf("Enter the ele ");
    scanarr(arr);
    result=identity(arr);
    if(result)
    printf("given matrix is null");
    else
    printf("given matrix isn't null");
    return 0;
}
void scanarr(int arr[][3])
{
    for(int i=0;i<3;i++)
        for(int j=0;j<3;j++)
            scanf("%d",&arr[i][j]);
}
int identity(int arr[][3])
{
    for(int i=0;i<3;i++){
        for(int j=0;j<3;j++){
            if((i==j&&arr[i][j]!=0)||(i!=j&&arr[i][j]!=0)){
                return 0;
            }
        }
    }
    return 1;
}
