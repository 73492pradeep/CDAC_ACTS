#include <stdio.h>
void scanarr(int arr[][2]);
void scanarr_1(int arr1[][3]);
void determinant(int arr[][2]);
void determinant_1(int arr1[][3]);
int main()
{
    int arr[2][2];
    int arr1[3][3];
    printf("Enter the arr ele for 2 x 2 = ");
    scanarr(arr);
    determinant(arr);
    printf("Enter the arr ele for 3 x 3 = ");
    scanarr_1(arr1);
    determinant_1(arr1);
    return 0;
}
void scanarr(int arr[][2])
{
    for(int i=0;i<2;i++)
        for(int j=0;j<2;j++)
            scanf("%d",&arr[i][j]);
}
void scanarr_1(int arr1[][3])
{
     for(int i=0;i<3;i++)
        for(int j=0;j<3;j++)
            scanf("%d",&arr1[i][j]);
}
void determinant(int arr[][2])
{
    int res;
    res = (arr[0][0]*arr[1][1])-(arr[0][1]*arr[1][0]);
    printf("determinant of 2x2 = %d\n",res);
}
void determinant_1(int arr1[][3])
{
    int det;
    det = (arr1[0][0]*((arr1[1][1]*arr1[2][2])-(arr1[1][2]*arr1[2][1]))-arr1[0][1]*((arr1[1][0]*arr1[2][2])-(arr1[1][2]*arr1[2][0]))+arr1[0][2]*((arr1[1][0]*arr1[2][1])-(arr1[1][1]*arr1[2][0])));
    printf("determinant of 3x3 = %d\n",det);
}
