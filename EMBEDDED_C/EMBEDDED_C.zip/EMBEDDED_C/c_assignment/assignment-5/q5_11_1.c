#include<stdio.h>
void scanarr(int arr[][3]);
void printarr(int arr[][3]);
void identity(int arr[][3],int arr1[][3]);
void print_ident(int arr1[][3]);
int main()
{
	int arr[3][3];
	int arr1[3][3];
	printf("Enter the arr ele = ");
	scanarr(arr);
	printarr(arr);
	identity(arr,arr1);
	print_ident(arr1);
	return 0;
}
void scanarr(int arr[][3])
{
	for(int i=0;i<3;i++)
		for(int j=0;j<3;j++)
			scanf("%d",&arr[i][j]);
}
void printarr(int arr[][3])
{
	for(int i=0;i<3;i++){
		for(int j=0;j<3;j++){
			printf("%d  ",arr[i][j]);
		}
	printf("\n");
	}
}
void identity(int arr[][3],int arr1[][3])
{
	for(int i=0;i<3;i++){
		for(int j=0;j<3;j++){
			if(i==j){
				arr1[i][j]=(arr[i][j]/arr[i][j]);
			}
			else if(i!=j){
				arr1[i][j]=(arr[i][j]*0);
			}
		}
	printf("\n");
	}
}
void print_ident(int arr1[][3])
{
	for(int i=0;i<3;i++){
		for(int j=0;j<3;j++){
			printf("%d  ",arr1[i][j]);
		}
	printf("\n");
	}
}



