#include<stdio.h>
void rev_arr(int arr[][2]);
int main()
{
	int a,b;
	int arr[2][2]={{5,2},{6,1}};
        rev_arr(arr);
	return 0;
}
void rev_arr(int arr[][2])
{
	for(int i=0;i<2;i++){
		for(int j=0;j<2;j++){
		       printf("%d\t",arr[j][i]);
	        }
		printf("\n");
       }
 }

        
