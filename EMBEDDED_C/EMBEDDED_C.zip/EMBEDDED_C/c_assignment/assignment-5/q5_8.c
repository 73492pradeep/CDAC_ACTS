#include<stdio.h>
#define ROW 3
#define COL 4
void trace(int arr1[3][4]);
int main()
{
	int arr1[ROW][COL];
	printf("Enter the element array:");
	for(int i=0;i<ROW;i++)
	{
		for(int j=0;j<COL;j++)
		{
			scanf("%d",&arr1[i][j]);
		}
	}

	trace(arr1);
return 0;
}

void trace(int arr1[ROW][COL])
{
	int temp =0;
	for(int i=0;i<ROW;i++)
	{
		for(int j=0;j<COL;j++)
		{
			if(i==j)
				temp += arr1[i][j];
		}
	}
	printf("Trace of matrix =%d",temp);
}


