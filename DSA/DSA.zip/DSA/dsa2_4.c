/*Q4. Count Duplicate Elements
Given an integer array, numbers, count the number of elements that occur more than once.
Example numbers = [1, 3, 3, 4, 4, 4]There are two non-unique elements: 3 and 4.*/

#include<stdio.h>
#define MAX 10
// function decleration
void non_unique(int a[]);
//main function
int main()
{
	int a[MAX];       //aray size defined by header
	printf("Enter the ele : ");
	for(int i=0;i<MAX;i++){         //for loop will run till max value
		scanf("%d",&a[i]);      //scan function scan the element
	}
	non_unique(a);                  //call function
	return 0;
}
// function definition
// it will find non unique number
void non_unique(int a[])
{
	int count=0;
	for(int i=0;i<MAX-1;i++){                  //this for loop will run till max-1
		for(int j=i+1;j<MAX;j++){          //this for loop will run till max
			if(a[i]==a[j]){            //here it will find same element then it will go to next element
	                        printf("The non-unique ele is = %d\n",a[i]);
				count++;	   //it will count the number of non unique
				for(int k=i;k<MAX-1;k++){   //this loop will run till max-1
					if(a[i]==a[k+1]){    
						i++;
					}
				}
			}i++;
		}
	}
	printf("The duplicate ele is = %d\n",count);   //ti will prinf number of non unique element
}

