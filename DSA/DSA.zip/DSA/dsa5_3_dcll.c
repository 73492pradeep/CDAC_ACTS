//doubly circular linklist
#include<stdio.h>
#include<stdlib.h>
struct node{
           struct node *prev;
           int data;
           struct node *next;
           };
void insertAtBeg();
void insertAtEnd();
void insertAtPos();
void displaylist();
void deleteFromBeg();
void deleteFromEnd();
void deleteFromPos();
void nodeCount();
struct node *head=NULL;
int main()
{
    int choice;
    while(1){
        printf("\nEnter the choice :\n1->insertAtBeg\n2->insertAtEnd\n3->insertAtPos\n4->displaylist\n5->deleteFromBeg\n6->deleteFromEnd\n7->deleteFromPos\n8->nodeCount\n0->exit : ");
        scanf("%d",&choice);
        switch(choice){
            case 1:
                   insertAtBeg();
                   break;
            case 2:
                   insertAtEnd();
                   break;
            case 3:
                   insertAtPos();
                   break;
            case 4:
                   displaylist();
                   break;
	    case 5:
		   deleteFromBeg();
		   break;
	    case 6:
		   deleteFromEnd();
		   break;
	    case 7:
		   deleteFromPos();
		   break;
	    case 8:
		   nodeCount();
		   break;
            case 0:
                   exit(0);
        }
    }
    return 0;
}
void insertAtBeg()
{
    int ele;
    printf("\nEnter the ele for insertAtBeg : ");
    scanf("%d",&ele);
    struct node *temp=NULL,*t1=head;
    temp=(struct node*)malloc(sizeof(struct node));
    if(temp==NULL){
        printf("No allocated memory");
    }
    temp->prev=NULL;
    temp->data=ele;
    temp->next=NULL;
    if(head==NULL){
        head=temp;
        temp->next=head;
    }else{
        while(t1->next!=head){
              t1=t1->next;
        }
        temp->next=head;
        head->prev=temp;
        head=temp;
        t1->next=temp;
        head->prev=t1;
    }
}
void insertAtEnd()
{
    int ele;
    printf("Enter the ele for insertAtEnd : ");
    scanf("%d",&ele);
    struct node *trav,*temp=NULL;
    trav=head;
    temp=(struct node*)malloc(sizeof(struct node));
    if(temp==NULL){
        printf("NO memory allocated");
    }
    temp->prev=NULL;
    temp->data=ele;
    temp->next=NULL;
    if(head==NULL){
        head=temp;
        temp->next=head;
    }else{
        while(trav->next!=head){
            trav=trav->next;
        }
        trav->next=temp;
        temp->prev=trav;
        temp->next=head;
    }
}
void insertAtPos()
{
    int ele,pos=0,count=1;
    printf("Enter the pos for insertAtPos : ");
    scanf("%d",&pos);
    if(pos==1){
        insertAtBeg();
    }else{
    printf("Enter the ele for insertAtPos : ");
    scanf("%d",&ele);
    struct node *temp=NULL;
    struct node *t1,*t2=NULL;
    t1=head;
    temp=(struct node*)malloc(sizeof(struct node));
    if(temp==NULL){
        printf("NO memory allocated");
    }
    temp->prev=NULL;
    temp->data=ele;
    temp->next=NULL;
    if(head==NULL){
        head=temp;
        temp->next=head;
    }else{
        t2=t1->next;
        while(count<pos-1){
            t1=t2;
            t2=t2->next;
            count++;
        }
        temp->prev=t1;
        temp->next=t1->next;
        t1->next=temp;
        t2->prev=temp;
    }
    }
}
void displaylist()
{
    struct node *trav=head;
    if(head==NULL){
        return;
    }
    while(trav->next!=head){
        printf("-->|%d|",trav->data);
        trav=trav->next;
    }
    printf("-->|%d|",trav->data);
}
void deleteFromBeg()
{
	struct node *t1=head;
	if(head==NULL){
		return;
	}
	head=t1->next;
	head->prev=t1->prev;
	t1->prev->next=head;
	free(t1);
}
void deleteFromEnd()
{
	struct node *t1=head;
	if(head==NULL){
		return;
	}else{
            t1=t1->prev;
            head->prev->prev->next=head;
            head->prev=head->prev->prev;
            free(t1);
	}
}
void deleteFromPos()
{
	int count=1,pos=0;
        struct node *t1=head,*t2=NULL;
	if(head==NULL){
		return;
	}
        printf("enter the pos for deleteFromPos\n");
	scanf("%d",&pos);
	if(pos==1){
		deleteFromBeg();
	}else{
		t2=t1->next;
		while(count<pos-1){
			t1=t2;
			t2=t2->next;
			count++;
		}
		t2->next->prev=t1;
		t1->next=t2->next;
		free(t2);
	}
}
void nodeCount()
{
	int count=1;
	struct node *t1=head;
	if(head==NULL){
		return;
	}else{
		while(t1->next!=head){
		t1=t1->next;
	        count++;
	}
	}
	printf("the number of node is = %d\n",count);
}


