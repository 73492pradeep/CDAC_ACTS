/*Q3. Write a C/C++ program to implement queue data structure using
array. Implement below metioned functions.
a) add
b) delete c) peep d) displayQueue
e)isQueueFull
f) isQueueEmpty*/

// queue
#include<stdio.h>
#include<stdlib.h>
#define MAX 5
// function decleration 
void enQueueEle(int arr[],int *f,int *r,int ele);
void deQueueEle(int arr[],int *f,int *r);
void display(int arr[]);
void isQueueFull(int *r,int *f);
void isQueueEmpty(int *f);
void peepEle(int arr[],int *f);
// main function
int main()
{
	int choice,ele;
	int arr[MAX];                      // array define
	int front=-1,rear=-1;
	for(int i=0;i<MAX;i++){            //it will fill garbage value(-99) in array 
		arr[i]=-99;
	}
	while(1){                          //while loop will run till infinit
		printf("\nEnter the choice :\n1->enQueueEle\n2->deQueueEle\n3->Display\n4->isQueueFull\n5->isQueueEmpty\n6->peepEle\n0->exit : ");
                scanf("%d",&choice);
		switch(choice){            //switch case will help to select the function call
			case 1:
				printf("\nEnter the element for push : ");
				scanf("%d",&ele);
				enQueueEle(arr,&front,&rear,ele);   //call enqueue function
				break;
			case 2:
				deQueueEle(arr,&front,&rear);       //call dequeue function
				break;
			case 3:
				display(arr);                       //call display function
				break;
			case 4:
				isQueueFull(&rear,&front);          //call is queue full function
				break;
			case 5:
				isQueueEmpty(&front);               //call is queue empty function
				break;
			case 6:
				peepEle(arr,&front);                //call peep element function
				break;
			case 0:
				exit(0);                            //ti will exit from while loop
		}
	}
	return 0;
}
// function definition
// it will enqueue the element in queue
void enQueueEle(int arr[],int *f,int *r,int ele)
{
	if(*r==MAX-1){           //it will check queue full status
		printf("Queue is full\n");
		return;
	}
	(*r)++;
	arr[*r]=ele;             //insert ele in queue
	if(*f==-1){
	     *f=0;
	}
}
// function definition
// it will dequeue the element from queue
void deQueueEle(int arr[],int *f,int *r)
{
	if(*r==-1){              //it will check queue empty status
		printf("Queue is empty\n");
		return;
	}
	printf("The deQueue ele is = %d\n",arr[*f]);
	arr[*f]=-99;
	if(*f==*r){              //if *f==*r then queue cantain only one element
		*f=-1;
		*r=-1;
	}else{
		(*f)++;
	}
}
// function definition
// it will display queue
void display(int arr[])
{
	for(int i=0;i<MAX;i++){    //this for loop will run till max
		printf("%d ",arr[i]);
	}
}
// function definition
// it will check queue full condition
void isQueueFull(int *r,int *f)
{
	if(*r==MAX-1){
		printf("Queue is full\n");
		return;
	}
	return;
}
// function definition
// it will check queue empty condition
void isQueueEmpty(int *f)
{
	if(*f==-1){
		printf("Queue is empty\n");
		return;
	}
	return;
}
// function definition
// it will peak the value from queue
void peepEle(int arr[],int *f)
{
	if(*f!=-1){
		printf("The peep ele is :%d\n",arr[0]);
		return;
	}
	return;
}





