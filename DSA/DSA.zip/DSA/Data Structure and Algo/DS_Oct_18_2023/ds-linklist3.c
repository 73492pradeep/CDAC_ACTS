#include<stdio.h>
#include<stdlib.h>

struct node {
	int data;
	struct node *next;
};

struct node *head;

void insertAtBeg(int);
void insertAtEnd(int);
void insertAtPos(int, int);
void display();
void deleteFromBeg();
void deleteFromEnd();
void deleteFromPos(int);

int main(){
	head=NULL;
	
	int choice, ele, pos;
	while(1){ // while1
	printf("1->insertAtBeg 2->insertAtEnd 3->insertAtPos 4->display 5->deleteFromBeg 6->deleteFromEnd 7->deleteFromPos 8->exit\n");
	scanf("%d", &choice);

	switch(choice){
		case 1:
			printf("enter a ele\n");
			scanf("%d",&ele);
			insertAtBeg(ele);
			break;	
		case 2:
			printf("enter a ele\n");
			scanf("%d",&ele);
			insertAtEnd(ele);
			break;	
		case 3:
			printf("enter a ele and pos \n");
			scanf("%d %d",&ele, &pos);
			insertAtPos(ele, pos);
			break;
		case 4:
			printf("--------linklist--------\n");
			display();
			break;
		case 5:	
			deleteFromBeg();
			break;
		case 6:
			deleteFromEnd();
			break;
		case 7:
			printf("enter the pos\n");
			scanf("%d", &pos);
			deleteFromPos(pos);
			break;
		case 8:
			exit(0);

	}} // while1
	return 0;
}// end of main();

void insertAtBeg(int ele){
	struct node *temp;

	temp=(struct node*)malloc(sizeof(struct node));
	temp->data=ele;
	temp->next=NULL;
	
	if(head==NULL){
		head=temp;
	}else {
		temp->next=head;
		head=temp;
	}
}

void insertAtEnd(int ele){
	struct node *temp;
	struct node *t1=head;

	temp=(struct node *)malloc(sizeof(struct node));
	temp->data=ele;
	temp->next=NULL;
	
	if(head==NULL){
		head=temp;
	}else {
		while(t1->next!=NULL){
			t1=t1->next;
		}
		t1->next=temp;
	}
}
void insertAtPos(int ele, int pos){
	if(pos==1){
		insertAtBeg(ele);
		return;
	}

	struct node *temp;
	struct node *t1=head;

	temp=(struct node *)malloc(sizeof(struct node));
	temp->data=ele;
	temp->next=NULL;

	int count=1;

	while(count<pos-1){
		t1=t1->next;
		count++;
	}

	temp->next=t1->next;
	t1->next=temp;
}

void display(){
	struct node *temp;
	temp=head;
	printf("head");

	while(temp!=NULL){
		printf("-->[%d]", temp->data);
		temp=temp->next;
	}
	printf("\n");
}

void deleteFromBeg(){
	struct node *t1=head;
	
	if(head==NULL){
		return;
	}else{
		head=t1->next;
		free(t1);
	}
}

void deleteFromEnd(){
	struct node *t1, *t2;
	t1=head;
	t2=NULL;
	if(head==NULL){
		return;
	}
	
	while(t1->next!=NULL){
		t2=t1;
		t1=t1->next;
	}	

	free(t1);
	if(t2!=NULL){
		t2->next=NULL;
	}
}


void deleteFromPos(int pos){
	if(pos==1){
		deleteFromBeg();
		return;
	}
	
	struct node *t1=head;
	struct node *t2=NULL;

	int count=1;
	if(head==NULL){
		return;
	}

	while(count<pos){
		t2=t1;
		t1=t1->next;
		count++;
	}
	
	t2->next=t1->next;
	free(t1);
}


