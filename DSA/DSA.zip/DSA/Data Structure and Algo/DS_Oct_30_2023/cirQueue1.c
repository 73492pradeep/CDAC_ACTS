#include<stdio.h>
#include<stdlib.h>

#define MAX 5
void enqueue(int *, int *, int *, int);
int dequeue(int *, int *, int *);
void display(int *);
void init(int *);

int main(){
	int arr[MAX]={-99};
	init(arr);
	int front=-1, rear=-1;
	int choice, ele;
	int ret;
	while(1){
	printf("enter 1-> enqueue, 2-> dequeue, 3-> display 4-> exit\n");
	scanf("%d", &choice);
	switch(choice){
		case 1:
			printf("enter ele\n");
			scanf("%d", &ele);
			enqueue(arr, &front, &rear, ele);
			break;
		case 2:
			ret=dequeue(arr, &front, &rear);
			if(ret!=-2) {
			printf("dequeue item=%d\n", ret);
			}
			break;
		case 3:
			display(arr);
			break;
		case 4:
			exit(1);
	}
	}
	return 0;
}

void init(int *a){
	for(int i=0; i<MAX; i++){
		a[i]=-99;
	}	
}
void display(int *a){
	for(int i=0; i<MAX; i++){
		printf("%d ", a[i]);
	}	
	printf("\n");
}

void enqueue(int *a, int *f, int *r, int ele){
	if(((*f==0) &&(*r==MAX-1))|| (*r+1 == *f)){
		printf("queue is full\n");
		return;
	}

	if(*r==MAX-1){
		*r=0;
	}else {
		(*r)++;
	}
	a[(*r)]=ele;
	
	if(*f==-1){
		*f=0;
	}
}

int dequeue(int *a, int *f, int *r){
	if(*f==-1){
		printf("queue is empty\n");
		return -2;
	}
	int item=a[*f];
	a[*f]=-99;
	if(*f==MAX-1 && *r!=MAX-1){
		*f=0;
	} else {
		if(*f==*r){
			*f=-1;
			*r=-1;
		}else {
			(*f)++;
	}
	return item;
}



