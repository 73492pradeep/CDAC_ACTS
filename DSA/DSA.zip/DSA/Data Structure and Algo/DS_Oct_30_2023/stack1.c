#include<stdio.h>
#include<stdlib.h>

#define MAX 5
void push(int *, int *, int);
int pop(int *, int *);
void display(int *);
void init(int *);

int main(){
	int arr[MAX]={-99};
	init(arr);
	int top=-1;
	int choice, ele;
	int ret;
	while(1){
	printf("enter 1-> push, 2-> pop, 3-> display 4-> exit\n");
	scanf("%d", &choice);
	switch(choice){
		case 1:
			printf("enter ele\n");
			scanf("%d", &ele);
			push(arr, &top, ele);
			break;
		case 2:
			ret=pop(arr, &top);
			if(ret!=-2) {
			printf("popped item=%d\n", ret);
			}
			break;
		case 3:
			display(arr);
			break;
		case 4:
			exit(1);
	}
	}
	return 0;
}

void init(int *a){
	for(int i=0; i<MAX; i++){
		a[i]=-99;
	}	
}
void display(int *a){
	for(int i=0; i<MAX; i++){
		printf("%d ", a[i]);
	}	
	printf("\n");
}

void push(int *a, int *t, int ele){
	if(*t==MAX-1){
		printf("stack is full\n");
		return;
	}
	(*t)++;
	a[(*t)]=ele;
}

int pop(int *a, int *t){
	if(*t==-1){
		printf("stack is empty\n");
		return -2;
	}
	int item=a[*t];
	a[*t]=-99;
	(*t)--;
	return item;
}



