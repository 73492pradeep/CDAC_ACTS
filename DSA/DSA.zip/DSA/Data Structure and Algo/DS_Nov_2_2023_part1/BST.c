#include<stdio.h>
#include<stdlib.h>

struct node{
	struct node *left;
	int data;
	struct node *right;
};
void insert(struct node **, int);
void inorderT(struct node * );
void preorderT(struct node * );
void postorderT(struct node * );

int main(){
	struct node *root=NULL;
	int choice, ele;
	while(1){
	printf("enter 1->insert 2-inorderT 3->preorderT 4->postorderT 5->exit\n");
	scanf("%d", &choice);
	switch(choice){
		case 1:
			printf("enter ele\n");
			scanf("%d", &ele);
			insert(&root, ele);
			break;
		case 2:
			printf("tree inorder traversal\n");
			inorderT(root);
			break;
		case 3:
			printf("tree preorder traversal\n");
			preorderT(root);
			break;
		case 4:
			printf("tree postorder traversal\n");
			postorderT(root);
			break;
		case 5:
			exit(0);
		
	}
	}
	return 0;
}

void inorderT(struct node *p){
	if(p!=NULL){
		inorderT(p->left);
		printf("%d ", p->data);
		inorderT(p->right);
	}
}

void preorderT(struct node *p){
	if(p!=NULL){
		printf("%d ", p->data);
		preorderT(p->left);
		preorderT(p->right);
	}

}

void postorderT(struct node *p){
	if(p!=NULL){
		postorderT(p->left);
		postorderT(p->right);
		printf("%d ", p->data);
	}

}
void insert(struct node **p, int ele){
	if((*p)==NULL){
		*p=(struct node *)malloc(sizeof(struct node));
		(*p)->data=ele;
		(*p)->left=NULL;
		(*p)->right=NULL;
	}else {
		if(ele < (*p)->data){
			insert(&((*p)->left), ele);
		}else {
			insert(&((*p)->right), ele);
		}
	}
}






