#include<stdio.h>
#include<stdlib.h>

#define TRUE 1
#define FALSE 0


struct node{
	struct node *left;
	int data;
	struct node *right;
};
void insert(struct node **, int);
void inorderT(struct node * );
void preorderT(struct node * );
void postorderT(struct node * );
void delete ( struct node **, int ) ;
void search ( struct node **, int, struct node **, struct node **, int * ) ;

int main(){
	struct node *root=NULL;
	int choice, ele;
	while(1){
	printf("enter 1->insert 2-inorderT 3->preorderT 4->postorderT 6->delete 5->exit\n");
	scanf("%d", &choice);
	switch(choice){
		case 1:
			printf("enter ele\n");
			scanf("%d", &ele);
			insert(&root, ele);
			break;
		case 2:
			printf("tree inorder traversal\n");
			inorderT(root);
			break;
		case 3:
			printf("tree preorder traversal\n");
			preorderT(root);
			break;
		case 4:
			printf("tree postorder traversal\n");
			postorderT(root);
			break;
		
		case 6: 
			printf("enter ele to be delete\n");
			scanf("%d", &ele);
			delete(&root, ele);
			break;
			
		case 5:
			exit(0);
		
	}
	}
	return 0;
}

void inorderT(struct node *p){
	if(p!=NULL){
		inorderT(p->left);
		printf("%d ", p->data);
		inorderT(p->right);
	}
}

void preorderT(struct node *p){
	if(p!=NULL){
		printf("%d ", p->data);
		preorderT(p->left);
		preorderT(p->right);
	}

}

void postorderT(struct node *p){
	if(p!=NULL){
		postorderT(p->left);
		postorderT(p->right);
		printf("%d ", p->data);
	}

}
void insert(struct node **p, int ele){
	if((*p)==NULL){
		*p=(struct node *)malloc(sizeof(struct node));
		(*p)->data=ele;
		(*p)->left=NULL;
		(*p)->right=NULL;
	}else {
		if(ele < (*p)->data){
			insert(&((*p)->left), ele);
		}else {
			insert(&((*p)->right), ele);
		}
	}
}

/* deletes a node from the binary search tree */
void delete ( struct node **root, int num )
{
	int found ;
	struct node *parent, *x, *xsucc ;

	/* if tree is empty */
	if ( *root == NULL )
	{
		printf ( "\nTree is empty" ) ;
		return ;
	}

	parent = x = NULL ;

	/* call to search function to find the node to be deleted */
	search ( root, num, &parent, &x, &found ) ;

	/* if the node to deleted is not found */
	if ( found == FALSE )
	{
		printf ( "\nData to be deleted, not found" ) ;
		return ;
	}

	/* if the node to be deleted has two children */
	if ( x -> left != NULL && x -> right != NULL )
	{
		parent = x ;
		xsucc = x -> right ;

		while ( xsucc -> left != NULL )
		{
			parent = xsucc ;
			xsucc = xsucc -> left ;
		}

		x -> data = xsucc -> data ;
		x = xsucc ;

	}

	/* if the node to be deleted has no child */
	if ( x -> left == NULL && x -> right == NULL )
	{
		if ( parent -> right == x )
			parent -> right = NULL ;
		else
			parent -> left = NULL ;

		free ( x ) ;
		return ;
	}

	/* if the node to be deleted has only rightchild */
	if ( x -> left == NULL && x -> right != NULL )
	{
		if ( parent -> left == x )
			parent -> left = x -> right ;
		else
			parent -> right = x -> right ;

		free ( x ) ;
		return ;
	}

	/* if the node to be deleted has only left child */
	if ( x -> left != NULL && x -> right == NULL )
	{
		if ( parent -> left == x )
			parent -> left = x -> left ;
		else
			parent -> right = x -> left ;

		free ( x ) ;
		return ;
	}
}

/*returns the address of the node to be deleted, address of its parent and
   whether the node is found or not */
void search ( struct node **root, int num, struct node **par, struct
		node **x, int *found )
{
	struct node *q ;

	q = *root ;
	*found = FALSE ;
	*par = NULL ;

	while ( q != NULL )
	{
		/* if the node to be deleted is found */
		if ( q -> data == num )
		{
			*found = TRUE ;
			*x = q ;
			return ;
		}

		*par = q ;

		if ( q -> data > num )
			q = q -> left ;
		else
			q = q -> right ;
	}
}





