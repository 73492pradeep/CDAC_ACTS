#include<stdio.h>
#include<stdlib.h>

struct node{
	int data;
	struct node *next;
};

void insertAtEnd(int);
void insertAtBeg(int);
void insertAtPos(int);
void display();

struct node *head;

int main(){

	head=NULL;
	int choice, ele;
	while(1){
	printf("1-> insertAtEnd 2->display 3->exit 4->insertAtBeg\n");
	scanf("%d", &choice);
	switch(choice){
		case 1:
			printf("enter ele\n");
			scanf("%d", &ele);
			insertAtEnd(ele);
			break;
		case 2:
			display();
			break;
		case 3:
			exit(0);
		case 4:
			printf("enter ele\n");
			scanf("%d", &ele);
			insertAtBeg(ele);
			break;
	}}
	return 0;
}

void insertAtBeg(int ele){
	struct node *temp;
	temp=(struct node *)malloc(sizeof(struct node));
	temp->data=ele;
	temp->next=NULL;
	
	if(head!=NULL){
		temp->next=head;
		head=temp;
	}else {
		head=temp;
	}
}

void insertAtEnd(int ele){	
	struct node *temp, *t1;
	t1=head;
	
	temp=(struct node *)malloc(sizeof(struct node));
	temp->data=ele;
	temp->next=NULL;

	if(head==NULL){
		head=temp;
	} else {
		//while(t1->next->next!=NULL){
		while(t1->next!=NULL){
			t1=t1->next;
		}
		t1->next=temp;
	}
}

void display(){
	struct node *temp=head;
	printf("head");
	while(temp!=NULL){
		printf("--->|%d|", temp->data);
		temp=temp->next;
	}	
	printf("\n");
}




