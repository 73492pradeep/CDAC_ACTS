#include<stdio.h>
#include<stdlib.h>

struct node {
	struct node *prev;
	int data;
	struct node *next;
};


void insertAtBeg(struct node **, int);
void insertAtEnd(struct node **,int);
void insertAtPos(struct node **, int, int);
void display(struct node *);
void deleteFromBeg(struct node **);
void deleteFromEnd(struct node **);
void deleteFromPos(struct node **,int);

int main(){
	struct node *head;
	head=NULL;
	
	int choice, ele, pos;
	while(1){ // while1
	printf("1->insertAtBeg 2->insertAtEnd 3->insertAtPos 4->display 5->deleteFromBeg 6->deleteFromEnd 7->deleteFromPos 8->exit\n");
	scanf("%d", &choice);

	switch(choice){
		case 1:
			printf("enter a ele\n");
			scanf("%d",&ele);
			insertAtBeg(&head,ele);
			break;	
		case 2:
			printf("enter a ele\n");
			scanf("%d",&ele);
			insertAtEnd(&head, ele);
			break;	
		case 3:
			printf("enter a ele and pos \n");
			scanf("%d %d",&ele, &pos);
			insertAtPos(&head, ele, pos);
			break;
		case 4:
			printf("--------linklist--------\n");
			display(head);
			break;
		case 5:	
			deleteFromBeg(&head);
			break;
		case 6:
			deleteFromEnd(&head);
			break;
		case 7:
			printf("enter the pos\n");
			scanf("%d", &pos);
			deleteFromPos(&head, pos);
			break;
		case 8:
			exit(0);

	}} // while1
	return 0;
}// end of main();

void insertAtBeg(struct node **p, int ele){
	struct node *temp;

	temp=(struct node*)malloc(sizeof(struct node));
	temp->data=ele;
	temp->next=NULL;
	temp->prev=NULL;

	if(*p==NULL){
		*p=temp;
	}else {
		temp->next=*p;
		*p=temp;

	}
}

void insertAtEnd(struct node **p, int ele){
	struct node *temp;
	struct node *t1=*p;

	temp=(struct node *)malloc(sizeof(struct node));
	temp->data=ele;
	temp->next=NULL;
	temp->prev=NULL;
	
	if(*p==NULL){
		*p=temp;
	}else {
		while(t1->next!=NULL){
			t1=t1->next;
		}
		t1->next=temp;
		temp->prev=t1;
	}
}
void insertAtPos(struct node **p,int ele, int pos){
	if(pos==1){
		insertAtBeg(p, ele);
		return;
	}

	struct node *temp;
	struct node *t1=*p;

	temp=(struct node *)malloc(sizeof(struct node));
	temp->data=ele;
	temp->next=NULL;
	temp->prev=NULL;

	int count=1;

	while(count<pos-1){
		t1=t1->next;
		count++;
	}
	temp->prev=t1;
	temp->next=t1->next;
	t1->next->prev=temp;
	t1->next=temp;
}

void display(struct node *q){
	printf("head[%d]", q);

	while(q!=NULL){
		printf("-->[%u|%d|%u]", q->prev,q->data, q->next);
		q=q->next;
	}
	printf("\n");
}

void deleteFromBeg(struct node **p){
	struct node *t1=*p;
	
	if(*p==NULL){
		return;
	}else{
		*p=t1->next;
		free(t1);
	}
}

void deleteFromEnd(struct node **p){
	struct node *t1, *t2;
	t1=*p;
	t2=NULL;
	if(*p==NULL){
		return;
	}
	while(t1->next!=NULL){
		t2=t1;
		t1=t1->next;
	}	
	free(t1);
	if(t2!=NULL){
		t2->next=NULL;
	}
}


void deleteFromPos(struct node **p, int pos){
	if(pos==1){
		deleteFromBeg(p);
		return;
	}
	
	struct node *t1=*p;
	struct node *t2=NULL;

	int count=1;
	if(*p==NULL){
		return;
	}

	while(count<pos){
		t2=t1;
		t1=t1->next;
		count++;
	}
	
	t2->next=t1->next;
	free(t1);
}


