#include<stdio.h>
#include<limits.h>
#include<stdlib.h>
#include<stdio_ext.h>

#define MAX 100

int idx = -1;

int pqVal[MAX];
int pqPriority[MAX];

int isEmpty();
int isFull();
void enqueue(int,int);
int peek();
void dequeue();
void display();


int main()
{
	char choice,ch;
	int data,priority,count = 0;
	do
	{
		printf("\n1. Enter in the queue\n2.Delete from the queue\n3. Display\n4. Exit\n");
		printf("Enter the choice : ");
		scanf("%hhd",&choice);

		switch(choice)
		{
			case 1: printf("Enter the number and priority to be enqueued : ");
				scanf("%d",&data);
				scanf("%d",&priority);
				enqueue(data,priority);
				break;
			case 2: dequeue();
				break;
			case 3: display();
				break;
			case 4: exit(0);
				break;
				
			default:printf("Enter the valid choice : ");		
		
		}
		
	count++;
	__fpurge(stdin);
	printf("Do you want to continue .. press Y/N  ");
	scanf("%c",&ch);
	
	}while((ch == 'Y' || ch == 'y') && (count < MAX) );
	
   return 0;
}

int isEmpty(){
    return idx == -1;
}

int isFull(){
    return idx == MAX - 1;
}

void enqueue(int data, int priority)
{
    if(!isFull()){
        
        idx++;
 
        pqVal[idx] = data;
        pqPriority[idx] = priority;
    }
}

int peek()
{
    int maxPriority = INT_MIN;
    int indexPos = -1;
 
    for (int i = 0; i <= idx; i++) { 
        if (maxPriority == pqPriority[i] && indexPos > -1 && pqVal[indexPos] < pqVal[i]) 
        {
            maxPriority = pqPriority[i];
            indexPos = i;
        }
        
        else if (maxPriority < pqPriority[i]) {
            maxPriority = pqPriority[i];
            indexPos = i;
        }
    }
    
    return indexPos;
}

void dequeue()
{
    if(!isEmpty())
    {
        int indexPos = peek();

        for (int i = indexPos; i < idx; i++) {
            pqVal[i] = pqVal[i + 1];
            pqPriority[i] = pqPriority[i + 1];
        }
 
        idx--;
    }
}

void display(){
    for (int i = 0; i <= idx; i++) {
        printf("(%d, %d)\n",pqVal[i], pqPriority[i]);
    } 
}

