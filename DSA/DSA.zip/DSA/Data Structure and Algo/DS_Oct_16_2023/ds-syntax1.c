#include<stdio.h>
// global variable approach
void incA();

int var1=100;
int main(){
	printf("var1=%d\n", var1); // 100
	incA();
	incA();
	printf("var1=%d\n", var1); // 102
	return 0;
}
void incA(){
	var1++;
}
