#include<stdio.h>
#include<stdlib.h>

struct node{
	int data;
	struct node *next;
};

void insert();
void display();

struct node *head;

int main(){

	head=NULL;
	int choice, ele;
	while(1){
	printf("1-> insert 2->display 3->exit\n");
	scanf("%d", &choice);
	switch(choice){
		case 1:
			insert();
			break;
		case 2:
			display();
			break;
		case 3:
			exit(0);
	}}
	return 0;
}

void insert(){	
	int ele;
	printf("enter ele\n");
	scanf("%d", &ele);

	struct node *temp, *t1;
	t1=head;
	temp=(struct node *)malloc(sizeof(struct node));
	
	temp->data=ele;
	temp->next=NULL;

	if(head==NULL){
		head=temp;
	} else {
		while(t1->next!=NULL){
			t1=t1->next;
		}
		t1->next=temp;
	}
}

void display(){
	struct node *temp=head;
	while(temp!=NULL){
		printf("--->%d", temp->data);
		temp=temp->next;
	}	
	printf("\n");
}




