#include<stdio.h>
// pass by val
int incB(int);

int main(){
	int var1=100;
	printf("var1=%d\n", var1); // 100
	var1=incB(var1);
	var1=incB(var1);
	printf("var1=%d\n", var1); // 102
	return 0;
}
int incB(int x){
	x++;
	return x;
}
