#include<stdio.h>
// pass by address
void incC(int *);

int main(){
	int var1=100;
	printf("var1=%d\n", var1); // 100
	incC(&var1);
	incC(&var1);
	printf("var1=%d\n", var1); // 102
	return 0;
}
void incC(int *p){
	(*p)++; // *p=*p+1;
}
