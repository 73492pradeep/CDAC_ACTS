/*Q4. Write a C/C++ program to implement circular queue data
structure using array. Implement below metioned functions.
a) add
b) delete c) peep d) displayQueue
e)isQueueFull
f) isQueueEmpty*/

// circular queue
#include<stdio.h>
#include<stdlib.h>
#define MAX 5
// function decleration 
void c_enQueueEle(int arr[],int *f,int *r,int ele);
void c_deQueueEle(int arr[],int *f,int *r);
void display(int arr[]);
void is_c_QueueFull(int *r,int *f);
void is_c_QueueEmpty(int *f);
void peepEle(int arr[],int *f);
// main function
int main()
{
	int choice,ele;
	int arr[MAX];         //array define
	int front=-1,rear=-1;
	for(int i=0;i<MAX;i++){  //it will fill grabage value(-99) in circular queue
		arr[i]=-99;
	}
	while(1){                //while loop will run till infinit time
		printf("\nEnter the choice :\n1->c_enQueueEle\n2->c_deQueueEle\n3->Display\n4->isQueueFull\n5->isQueueEmpty\n6->peepEle\n0->exit : ");
                scanf("%d",&choice);
		switch(choice){        //switch case will help to select the call function
			case 1:
				printf("\nEnter the element for push : ");
				scanf("%d",&ele);
				c_enQueueEle(arr,&front,&rear,ele);    //call circular enqueue function
				break;
			case 2:
				c_deQueueEle(arr,&front,&rear);        //call circular dequeue function
				break;
			case 3:
				display(arr);                          //call dispolay function
				break;
			case 4:
				is_c_QueueFull(&rear,&front);          //call is circular queue full function
				break;
			case 5:
				is_c_QueueEmpty(&front);               //call is circular queue empty function
				break;
			case 6:
				peepEle(arr,&front);                   //call peep function
				break;
			case 0:
				exit(0);                               //it will exit the while function
		}
	}
	return 0;
}
// function definition 
// this function will enqueue the element in queue
void c_enQueueEle(int arr[],int *f,int *r,int ele)
{
	if((*r==MAX-1&&*f==0)||(*r+1==*f)){       //it will check circular queue full condition
		printf("Queue is full\n");
		return;
	}else{
		if(*r==MAX-1){                   //if *r==0 than it will reset the r=0
			*r=0;
		}else{
			(*r)++;
	
		}
		arr[*r]=ele;
	}
	if(*f==-1){
		*f=0;
	}
}
// function definition 
// this function will dequeue the element from circular queue
void c_deQueueEle(int arr[],int *f,int *r)
{
	if(*r==-1){                   //it will check circular queue empty condition
		printf("c_Queue is empty\n");
		return;
	}else{
                printf("The deQueue ele is = %d\n",arr[*f]);
		arr[*f]=-99;
		if(*f==MAX-1&&*r!=MAX-1){      //if *f==max condition it will reset the front
			*f=0;
		}else{
		       if(*f==*r){
			*r=-1;
			*f=-1;
		       }else{
			       (*f)++;
		       }
		}
	}
	
}
// function definition
// it will display the element of queue
void display(int arr[])
{
	for(int i=0;i<MAX;i++){      //the loop will run till max condition
		printf("%d ",arr[i]);
	}
}
// function definition
// it will check circular queue full condition
void is_c_QueueFull(int *r,int *f)
{
	if((*r==MAX-1&&*f==0)||(*r+1==*f)){
		printf("Queue is full\n");
		return;
	}
}
// function definition
// it will check circular queue empty condition
void is_c_QueueEmpty(int *f)
{
	if(*f==-1){
		printf("Queue is empty\n");
		return;
	}
	return;
}
// function definition
// it will peep element 
void peepEle(int arr[],int *f)
{
	if(*f!=-1){
		printf("The peep ele is :%d\n",arr[0]);
		return;
	}
	return;
}





