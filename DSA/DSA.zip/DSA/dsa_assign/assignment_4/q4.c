#include<stdio.h>
#include<stdlib.h>
#define MAX 5
void init(int arr[]);
void enqueue(int arr[],int *,int *);
void dequeue(int arr[],int *,int *);
void display(int arr[]);
int main()
{
	int arr[MAX]={-99};
	int f=-1,r=-1;
	init(arr);
	int choice;
	while(1)
	{
	printf("Enter the choice:\n");
	printf("--->1 for enqueue:\n");
	printf("--->2 for dequeue:\n");
	printf("--->3 for display:\n");
	printf("--->4 for exit:");
	scanf("%d",&choice);
	switch(choice)
	{
		case 1:
			enqueue(arr,&f,&r);
			break;
		case 2:
			dequeue(arr,&f,&r);
			break;
		case 3:
			display(arr);
			break;
		case 4:
			exit(0);
	}
	}
return 0;
}
void init(int arr[])
{
	for(int i=0;i<MAX;i++)
	{
		arr[i]=-99;
	}
}
void enqueue(int arr[],int *f,int *r)
{
	int ele;
	printf("Enter the element:");
	scanf("%d",&ele);
	if(*r==MAX-1)
	{
		printf("Queue is full:");
		return ;
	}
	else 
	{
		if(*f==-1)
		{
			*f=0;
		}
	}

	     (*r)++;
	     arr[(*r)]=ele;
	    // (*f)++;
	
}
void dequeue(int arr[],int *f,int *r)
{
	int item;
	if(*f==-1)
	{
		printf("Queue is empty:");
		return ;
	}
	item=arr[*f];
	printf("Popped element =%d\n",item);
	arr[*f]=-99;
	if(*f==*r)
	{
		*f=-1;
		*r=-1;
	}
	else
	{
		(*f)++;
	}
}
void display(int arr[])
{
	for(int i=0;i<MAX;i++)
	{
		printf("%d\t",arr[i]);
	}
}






