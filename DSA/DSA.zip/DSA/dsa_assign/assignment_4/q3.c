#include<stdio.h>
#include<stdlib.h>
void arrinit(int [],int);
void enqueue(int [],int *,int *,int,int);
void dequeue(int [],int *,int *,int);
void display(int [],int);
int main()
{
	int n;
	printf("Enrte the size of the array\t");						//User Input
	scanf("%d",&n);
	int arr[n];
	int front=-1,rear=-1;
	arrinit(arr,n);										//Calling to arrinit function
	while(1)
	{
		printf("Enter the choice\n");
		printf("1--->enqueue\n");
		printf("2--->dequeue\n");
		printf("3--->display\n");
		printf("4--->exit\n");
		int choice,ele;
		scanf("%d",&choice);								//User Input
		switch(choice)
		{
			case 1:
				printf("Enter the element\t");					//User Input
				scanf("%d",&ele);
				enqueue(arr,&front,&rear,n,ele);				//Calling to enqueue function
				break;
			case 2:
				dequeue(arr,&front,&rear,n);					//Calling to dequeue function
				break;
			case 3:
				display(arr,n);							//calling to display function
				break;
			case 4:
				exit(1);
		}
	}
	return 0;
}
//function defition of the arrinit
void arrinit(int arr[],int n)									//Function to intialtize the array
{
	for(char i=0;i<n;i++)
	{
		arr[i]=-99;
	}
}
//function defition of the enqeueue
void enqueue(int arr[],int *f,int *r,int n, int ele)					
{
	if(*r==n-1)//Checking the queue is full
	{
		printf("Queue is full\n");
		return;
	}
	(*r)++;
	arr[(*r)]=ele;
	if(*f==-1)
	{
		*f=0;
	}
}
//function defition of the dequeue
void dequeue(int arr[],int *f, int *r, int n)
{
	int temp;
	if(*f==-1)//Checking the queue is Empty
	{
		printf("Queue is Empty\n");
		return;
	}
	temp=arr[(*f)];
	arr[(*f)]=-99;
	printf("dequeued element=%d\n",temp);
	if(*f==*r)
	{
		*f=-1;
		*r=-1;
	}else{
		(*f)++;
	}
}
//function defition of the display
void display(int arr[],int n)//Display function to display the elements
{
	printf("arrr---->");
	for(char i=0;i<n;i++)
	{
		printf("%d\t",arr[i]);}
		
	}
}
	}
	printf("\n");
}
