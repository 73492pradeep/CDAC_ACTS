#include<stdio.h>
#include<stdlib.h>
void arrayinit(int arr[],int n);
void push(int arr[],int *,int n);
void pop(int arr[],int *,int n);
void display(int arr[],int n);
void isstackfull(int arr[],int *,int n);
void isstackempty(int arr[],int *,int n);
int main()
{
	int n;
	printf("Enter the size of array:\n");
	scanf("%d",&n);
	int arr[n];
	arrayinit(arr,n);
	int choice;
	int top=-1;
	while(1)
	{
		printf("Enter the choice:\n");
		printf("--->1 for push:\n");
		printf("--->2 for pull:\n");
		printf("--->3 for display:\n");
		printf("--->4 for checking stack is full or not:\n");
		printf("--->5 for checking stack is empty or not:\n");
		printf("--->6 for exit:\n");
		scanf("%d",&choice);
		switch(choice)
		{
			case 1:
				push(arr,&top,n);
				break;
			case 2:
				pop(arr,&top,n);
				break;
			case 3:
				display(arr,n);
				break;
			case 4:
				isstackfull(arr,&top,n);
				break;
			case 5:
				isstackempty(arr,&top,n);
				break;
			case 6:
				exit(0);
		}
	}
return 0;
}
void arrayinit(int arr[],int n)
{
	for(int i=0;i<n;i++)
	{
		arr[i]=-99;
	}
}
void push(int arr[],int *top,int n)
{
	int ele;
	printf("Enter the element:\n");
	scanf("%d",&ele);
	if(*top==n-1)
	{
		printf("Stack is full:\n");
	}
	(*top)++;
	arr[(*top)]=ele;
}
void pop(int arr[],int *top,int n)
{
	if(*top==-1)
	{
		printf("Stack is empty:");
	}
	int item=arr[(*top)];
	(*top)--;
}
void isstackfull(int arr[],int *top,int n)
{
	if(*top==n-1)
	{
		printf("Stack is full:\n");
	}
}
void isstackempty(int arr[],int *top,int n)
{
	if(*top==-1)
	{
		printf("Stack is empty:\n");
	}
}
void display(int arr[],int n)
{
	printf("Stack element are:\n");
	for(int i=0;i<n;i++)
	{
		printf("%d\t",arr[i]);
	}
	printf("\n");
}

