#include <stdio.h>  
  
// Function to swap two elements  
void swap(int* a, int* b) {  
    int t = *a;  
    *a = *b;  
    *b = t;  
}  
//Function to divide the elements in the two part
int partition(int arr[], int low, int high) {  
    int pivot = arr[high];  
    int i = (low - 1);  
  
    for (int j = low; j <= high - 1; j++) {  
        if (arr[j] < pivot) {  
            i++;  
            swap(&arr[i], &arr[j]);  			//calling to swap function
        }  
    }  
    swap(&arr[i + 1], &arr[high]);  			//calling to swap function
    return (i + 1);  
}
//Function to short the elemets
void quickSort(int arr[], int low, int high) {  
    if (low < high) {  
        int pi = partition(arr, low, high);  
        quickSort(arr, low, pi - 1);  
        quickSort(arr, pi + 1, high);  
    }  
}  
  
// Function to print the array  
void printArray(int arr[], int size) {  
    int i;  
    for (i = 0; i < size; i++)  
        printf("%d ", arr[i]);  
    printf("\n");  
}  
  
int main() {  
    int arr[] = { 12, 17, 6, 25, 1, 5 };  
    int n = sizeof(arr) / sizeof(arr[0]);  
    quickSort(arr, 0, n - 1);  				//calling to quicksort function
    printf("Sorted array: \n");  
    printArray(arr, n);  				//calling to printArray function
    return 0;  
} 
