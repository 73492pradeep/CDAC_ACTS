/*implement single circular linked list */
#include<stdio.h>
#include<stdlib.h>
struct node{
	int data;
	struct node *next;
};
//Function Decleration
void insertatend(struct node **);
void display(struct node **);
void insertatbeg(struct node **);
void insertatpos(struct node **);
void insertatpos(struct node **);
void deletefromend(struct node **);
void deletefrombeg(struct node **);
void deletefrompos(struct node **);
void sorting(struct node **);
void reverselist(struct node **);
int main()
{
	struct node *head;
	head=NULL;
	int choice;
	while(1)
	{
		printf("Enter the choice:\n");
		printf("1------>insert at end\n");
		printf("2------>insert at beg\n");
		printf("3------>display\n");
		printf("4------>insert at pos\n");
		printf("5------>delete from end\n");
		printf("6------>delete from beg\n");
		printf("7------>delete from pos\n");
		printf("8------>sort list\n");
		printf("9------>reverse list\n");
		printf("10------>exit\n");
		scanf("%d",&choice);							//User Input
		switch(choice)
		{
			case 1:
				insertatend(&head);					//Calling to function insertatend	
				break;
			case 2:
				insertatbeg(&head);					//Calling to function insertatbeg
				break;
			case 3:
				display(&head);						//Calling to function display
				break;
			case 4:
				insertatpos(&head);					//Calling to function insertatpos
				break;
			case 5:
				deletefromend(&head);					//Calling to function deletefromend
				break;
			case 6:
				deletefrombeg(&head);					//Calling to function deletefrombeg
				break;
			case 7:						
				deletefrompos(&head);					//Calling to function deletefrompos
				break;
			case 8
			
				sorting(&head);						//Calling to function ssorting
				break;
			case 9:
				reverselist(&head);					//Calling to function revreslist
				break;
			case 10:
				exit(0);
			}
	}
	return 0;
}
//End of the main function
//Function definiton......
//function definition of insertatend in which node is attched from the end of the linked list
void insertatend(struct node **p)
{
	struct node *t1,*temp;
	t1=NULL;
	t1=*p;
	temp=(struct node*)malloc(sizeof(struct node));
	if(temp==NULL)
	{
		printf("Memory is not allocated\n");
	}
	int ele;
	printf("Entere the elemenet\t");
	scanf("%d",&ele);
	temp->data=ele;
	temp->next=NULL;
	if(*p==NULL)
	{
		*p=temp;
		temp->next=*p;
	}
	else
	{
		while(t1->next!=*p)
		{
			t1=t1->next;
		}
		t1->next=temp;
		temp->next=*p;
	}
}
//function definition of of display to display the elements of the all nodess
void display(struct node **p)
{
	struct node *t1;
	t1=*p;
	if(*p==NULL)
	{
		printf("\n========Insert the elements to display=======\n");
	}
	else{
	printf("head----->[%p]",*p);
	while(t1->next!=*p)
	{
		printf("----->[%d][%p]",t1->data,t1->next);
		t1=t1->next;
	}
	printf("----->[%d][%p]\n",t1->data,t1->next);
	}
}
//function definition of insertatend in which node is attched from the begining of the linked list
void insertatbeg(struct node **p)
{
	struct node *t1,*temp;
	t1=NULL;
	temp=NULL;
	t1=*p;
	temp=(struct node*)malloc(sizeof(struct node*));
	if(temp==NULL)
	{
		printf("Memory is not allocated\n");
	}
	int ele;
	printf("Enter the element:\t");
	scanf("%d",&ele);
	temp->data=ele;
	temp->next=NULL;
	if(*p==NULL)
	{
		*p=temp;
		temp->next=*p;
	}
	else{
		while(t1->next!=*p)
		{
			t1=t1->next;
		}
		t1->next=temp;
		temp->next=*p;
		*p=temp;
	}
}
//function definition of insertatend in which node is attched from the position of the linked list
void insertatpos(struct node **p)
{
	int count=1,pos;
	struct node *t1,*temp;
	t1,temp=NULL;
	printf("Enter the position:\t");
	scanf("%d",&pos);
	if(pos==1)
	{
		insertatbeg(p);
	}
	temp=(struct node*)malloc(sizeof(struct node));
	if(temp==NULL)
	{
		printf("Memory is not allocated\n");
	}
	int ele;
	printf("Enter the elemenet\t");
	scanf("%d",&ele);
	temp->data=ele;
	temp->next=NULL;
	if(*p==NULL)
	{
		*p=temp;
		temp->next=*p;
	}
	else{
		t1=*p;
		while(count<pos-1)
		{
			t1=t1->next;
			count++;
		
		}
		temp->next=t1->next;
		t1->next=temp;
	}
}
//function definition of deletefromend in which node is removed from the end of the linked list
void deletefromend(struct node **p)
{
	struct node *t1=*p;
	if(*p==NULL)
	{
		printf("\n=====No data to delete=====\n");
	}else{
	if(*p==t1->next)
	{
		*p=NULL;
		printf("\n====Empty\n====");
	}
	else{
	while(t1->next->next!=*p)
	{
		t1=t1->next;
	}
	t1->next=*p;
	}
	}
}
//function definition of deletefrombeg in which node is removed from the begining of the linked list
void deletefrombeg(struct node **p)
{
	struct node *t1=*p,*t2=*p;
	if(*p==NULL)
	{
		printf("\n=====No data to delete=====\n");
	}else{
	if(*p==t1->next)
	{
		*p=NULL;
		printf("\n====Empty=====\n");
	}
	else{
		while(t1->next!=*p)
		{
			t1=t1->next;
		}
		t1->next=t2->next;
		*p=t2->next;
		free(t2);
	}
	}
}
//function definition of deletefrompos in which node is removed from the posstion of the linked list
void deletefrompos(struct node **p)
{
	int count=1,pos;
	printf("Enter the position\t");
	scanf("%d",&pos);
	if(pos==1)
	{
		deletefrombeg(p);
	}
	else{
	struct node *t1=*p;
		while(count<pos-1)
		{
			t1=t1->next;
			count++;

		}
		t1->next=t1->next->next;
	}
}
//function definition of sorting in which we arrange the nodes in sorted manner
void sorting(struct node **p)
{
	struct node *t1,*t2;
	t1=*p;
	t2=NULL;
	if(*p==NULL)
	{
		printf("\n===========No data to be sorted===========\n");
	}
	else{
	while(t1->next!=*p)
	{
		t2=t1->next;
		while(t2!=*p)
		{
			if(t1->data > t2->data)
			{
				t2->data = t2->data + t1->data;
				t1->data = t2->data - t1->data;
				t2->data = t2->data - t1->data;
			}
			t2 = t2->next;
		}
		t1 = t1->next;
	}
	printf("\n==========sorted=========\n");
	}
}
//function definition of reverselist in which we reverse the list 
void reverselist(struct node **p)
{
	struct node *prev,*current;
	if(*p!=NULL)
	{
		prev=*p;
		current=prev->next;
		*p=prev->next;
		prev->next=NULL;
		while(prev->next!=*p)
		{
			*p=current->next;
			current->next=prev;
			prev=current;
			current=*p;
		}
		current->next=prev;
	}
}
