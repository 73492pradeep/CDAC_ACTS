#include <stdio.h>
#include <stdlib.h>

#define MAX_SIZE 100

struct Deque {
    int data[MAX_SIZE];
    int front;
    int rear;
};

//Function declerations
void initDeque(struct Deque* deque);
int isFull(struct Deque* deque);
int isEmpty(struct Deque* deque);
void insertFront(struct Deque* deque, int data);
void insertRear(struct Deque* deque, int data);
int removeFront(struct Deque* deque);
int removeRear(struct Deque* deque);
void displayDeque(struct Deque* deque);

int main() {
    struct Deque deque;
    initDeque(&deque);
    int choice, data;

    do {
        printf("\nDeque Menu:\n");
        printf("1. Insert at Front\n");
        printf("2. Insert at Rear\n");
        printf("3. Remove from Front\n");
        printf("4. Remove from Rear\n");
        printf("5. Display Deque\n");
        printf("6. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);							//User Input

        switch (choice) {
            case 1:
                printf("Enter data to insert at front: ");
                scanf("%d", &data);						//User Input
                insertFront(&deque, data);
                break;
            case 2:
                printf("Enter data to insert at rear: ");
                scanf("%d", &data);						//User Input
                insertRear(&deque, data);
                break;
            case 3:
                data = removeFront(&deque);
                if (data != -1) {
                    printf("Removed from front: %d\n", data);			//display the removed from the queue
                }
                break;
            case 4:
                data = removeRear(&deque);
                if (data != -1) {
                    printf("Removed from rear: %d\n", data);			//dissplay the data removed from the deque
                }
                break;
            case 5:
                displayDeque(&deque);						//calling the fucntion displayDeque
                break;
            case 6:
                printf("Exiting the program.\n");
                break;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    } while (choice != 6);

    return 0;
}
//End of the main function
//Function definiton......
//Function definition of initDeque to intialize the fornt and rear
void initDeque(struct Deque* deque) {
    deque->front = -1;
    deque->rear = -1;
}

//Function definition of isFull to check the Check the deque is full
int isFull(struct Deque* deque) {
    return (deque->front == 0 && deque->rear == MAX_SIZE - 1) || (deque->front == deque->rear + 1);
}

//Function definition of isEmpty to check the Check the deque is empty
int isEmpty(struct Deque* deque) {
    return deque->front == -1;
}

//Function definition of inertRear to inssert from front
void insertFront(struct Deque* deque, int data) {
    if (isFull(deque)) {
        printf("Deque is full. Cannot insert at front.\n");
        return;
    }

    if (deque->front == -1) {
        deque->front = deque->rear = 0;
    } else if (deque->front == 0) {
        deque->front = MAX_SIZE - 1;
    } else {
        deque->front--;
    }

    deque->data[deque->front] = data;
}

//Function definition of inertRear to inssert from rear
void insertRear(struct Deque* deque, int data) {
    if (isFull(deque)) {
        printf("Deque is full. Cannot insert at rear.\n");
        return;
    }

    if (deque->front == -1) {
        deque->front = deque->rear = 0;
    } else if (deque->rear == MAX_SIZE - 1) {
        deque->rear = 0;
    } else {
        deque->rear++;
    }

    deque->data[deque->rear] = data;
}
//Function definition of removefront to remove front
int removeFront(struct Deque* deque) {
    if (isEmpty(deque)) {
        printf("Deque is empty. Cannot remove from front.\n");
        return -1;
    }

    int data = deque->data[deque->front];
    if (deque->front == deque->rear) {
        deque->front = deque->rear = -1;
    } else if (deque->front == MAX_SIZE - 1) {
        deque->front = 0;
    } else {
        deque->front++;
    }
    return data;
}

//Function definition of removerear to remove rear
int removeRear(struct Deque* deque) {
    if (isEmpty(deque)) {
        printf("Deque is empty. Cannot remove from rear.\n");
        return -1;
    }

    int data = deque->data[deque->rear];
    if (deque->front == deque->rear) {
        deque->front = deque->rear = -1;
    } else if (deque->rear == 0) {
        deque->rear = MAX_SIZE - 1;
    } else {
        deque->rear--;
    }
    return data;
}

//Function definition of displayDeque to dissplay all the elements of the deque
void displayDeque(struct Deque* deque) {
    if (isEmpty(deque)) {
        printf("Deque is empty.\n");
        return;
    }

    int i = deque->front;
    do {
        printf("%d ", deque->data[i]);
        if (i == deque->rear) {
            break;
        }
        if (i == MAX_SIZE - 1) {
            i = 0;
        } else {
            i++;
        }
    } while (1);

    printf("\n");
}
