//implement the doubly linked list
#include<stdio.h>
#include<stdlib.h>//header file for structure//
//structure definition and declaration //
struct node
{
	int data;
	struct node *prev;
	struct node *next;
};
struct node *head;//decalaration of head//
//decalaration of all functions//
void insertatBeg();
void insertatend();
void insertatpos();
void display();
void deleteatBeg();
void deleteatEnd();
void deleteatpos();
void reversedisplay();
void reverselist();
void freeallnode();
int main()
{
	int choice;
	while(1)
	{
	printf("Enter the choice:\n");
	printf("--->1 for insertatBeg:\n");
	printf("--->2 for insertatend:\n");
	printf("--->3 for insertatpos:\n");
	printf("--->4 for display:\n");
	printf("--->5 for deleteatBeg:\n");
	printf("--->6 for deleteatEnd:\n");
        printf("--->7 for deleteatpos:\n");
	printf("--->8 for reversedisplay:\n");
	printf("--->9 for reverselist:\n");
	printf("-->10 for freeallnode:\n");
	printf("-->11 for exit:\n");
	scanf("%d",&choice);
	//menu driven program for all fuctions using switch case//
	switch(choice)
	{
		case 1:
			insertatBeg();
			break;
		case 2:
			insertatend();
			break;
		case 3:
			insertatpos();
			break;
		case 4:
			display();
			break;
		case 5:
			deleteatBeg();
			break;
		case 6:
			deleteatEnd();
			break;
		case 7:
			deleteatpos();
			break;
		case 8:
			reversedisplay();
			break;
		case 9:
			reverselist();
			break;
		case 10:
			freeallnode();
			break;
		case 11:
			exit(0);
	}
	}
	freeallnode();
	return 0;
}
//defintion of all fuctions starts here//
void insertatBeg()
{
	int ele;
	printf("Enter the element:");
	scanf("%d",&ele);
	struct node *temp,*t1;
	t1=head;
	temp=(struct node *)malloc(sizeof(struct node));
	temp->data=ele;
	temp->next=NULL;
	temp->prev=NULL;
	if(head==NULL)
	{
		head=temp;
	}
	else
	{
		t1->prev=temp;
		temp->next=head;
		head=temp;
	}
}
//function definiton of insertatend in which we add the node from end of the linked list
void insertatend()
{
	int ele;
	printf("Enter the element:");
	scanf("%d",&ele);
	struct node *temp,*t1;
	t1=head;
	temp=(struct node *)malloc(sizeof(struct node));
	temp->data=ele;
	temp->next=NULL;
	temp->prev=NULL;
	if(head==NULL)
	{
		head=temp;
	}
	else
	{
		while(t1->next!=NULL)
		{
			t1=t1->next;
		}
		t1->next=temp;
		temp->prev=t1;
	}
}
//function definiton of insertatposs in which we add the node from given position from the linked list
void insertatpos()
{
	int ele,pos,count=1;
	printf("Enter the element:");
	scanf("%d",&ele);
	printf("Enter the pos:");
	scanf("%d",&pos);
	struct node *temp,*t1;
	t1=head;
	temp=(struct node *)malloc(sizeof(struct node));
	if(temp==NULL)
	{
		printf("Memory is not allocated:");
	}
	temp->data=ele;
	temp->next=NULL;
	temp->prev=NULL;
	if(pos==1)
	{
		insertatBeg();
	}
	if(head==NULL)
	{
		head=temp;
	}
	else
	{
		while(count<pos-1)
		{
			t1=t1->next;
			count++;
		}
	}
		temp->next=t1->next;
		t1->next=temp;
		temp->prev=t1;
}
//function definition of display in which we display the elements of the linked list
void display()
{
	struct node *t1;
	t1=head;
	printf("head---->");
	while(t1!=NULL)
	{
		printf("[%p][%d][%p]---->",t1->prev,t1->data,t1->next);
		t1=t1->next;
	}
	printf("\n");
}
//function definiton of deletefromposs in which we remove the node from begining of the linked list
void deleteatBeg()
{
	struct node *t1;
	t1=head;
	if(head==NULL)
	{
		return ;
	}
	else
	{
		head=t1->next;
	}
}
//function definiton of deletefromposs in which we remove the node from end of the linked list
void deleteatEnd()
{
	struct node *t1,*t2;
	t1=head;
	while(t1->next!=NULL)
	{
		t2=t1;
		t1=t1->next;
	}
	t2->next=NULL;
}
//function definiton of deletefromposs in which we remove the node from given position from the linked list
void deleteatpos()
{
	int pos,count=1;
	int node_count=0;
	struct node *t1,*nd,*t2=NULL;
	t1=head;
	nd=head;
	if(head==NULL)
	{
		return ;
	}
	while(nd!=NULL)
	{
		nd=nd->next;
		node_count++;
	}
	printf("Node count=%d\n",node_count);
	printf("Enter the pos:");
	scanf("%d",&pos);
	if(pos==1)
	{
		deleteatBeg();//If user enters position equal to 1 then delete at beg fuction is called//
	}
	else if(pos == node_count)
	{
		deleteatEnd();//If user enters position equal to no of node then delete at end fuction is called//
	}
	else
	{
		while(count<pos-1)
		{
			t1=t1->next;
			count++;
		}
		        t2=t1->next;
		
	t2->next->prev=t1;
	t1->next=t2->next;
	t2->prev=NULL;
	free(t2);
	}
}
//functuin definiton of the revrsedisplay in which we dissplay the elemenst in the in revere manner
void reversedisplay()
{
	struct node *t1,*t2;
	t2=head;
	t1=head;
	int j,count=0;
	while(t2!=NULL)
	{
		count++;
		t2=t2->next;
	}
	printf("total count=%d\n",count);
	for(int i=0;i<count;i++)//for reverse displaying linked list element took a for loop that runs at equal to position and then print data one by one in reverese order//
	{
		j=i;//intializes the i value in j and then increment j//
		while(j<count-1)
		{
			t1=t1->next;
			j++;
		}
		printf("---->%d",t1->data);
		t1=head;
	}	                        
	printf("\n");	
}
//function definiton of the reverselist in ehish we reversse the nodes of the linked list
void reverselist()
{
	struct node *next,*prev;
	next=NULL;
	prev=NULL;
	while(head!=NULL)
	{
		next=head->next;
		head->next=head->prev;
		prev=head;
		head->prev=prev;
		head=next;
	}
	head=prev;
	head->prev=NULL;
}
//function definiton of the freeeallnode to free all the nodes of the linked list
void freeallnode()
{
	struct node *temp;
        temp=head;
        if(head==NULL)
        {
                printf("There is no linked list:\n");
        }
        while(temp!=NULL)
        {
                temp=temp->next;
                free(head);
                head=temp;
        }
}




	





	





		


 
