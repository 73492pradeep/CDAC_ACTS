//implement a program on priority queue//
#include<stdio.h>
#include<limits.h>
#include<stdlib.h>
#include<stdio_ext.h>

#define MAX 100

int idx = -1;

int pqVal[MAX];
int pqPriority[MAX];
//function declerations......
int isEmpty();
int isFull();
void enqueue(int,int);
int peek();
void dequeue();
void display();


int main()
{
	char choice,ch;
	int data,priority,count = 0;
	do
	{
		printf("\n1. Enter in the queue\n2.Delete from the queue\n3. Display\n4. Exit\n");
		printf("Enter the choice : ");
		scanf("%hhd",&choice);										//User Input

		switch(choice)
		{
			case 1: printf("Enter the number and priority to be enqueued : ");
				scanf("%d",&data);								//user Input
				scanf("%d",&priority);								//user Input
				enqueue(data,priority);								//Calling to enqueue function
				break;
			case 2: dequeue();									//Calling to dequeue function
				break;
			case 3: display();									//calling to display function
				break;
			case 4: exit(0);
				break;
				
			default:printf("Enter the valid choice : ");		
		
		}
		
	count++;
	__fpurge(stdin);
	printf("Do you want to continue .. press Y/N  ");
	scanf("%c",&ch);
	
	}while((ch == 'Y' || ch == 'y') && (count < MAX) );
	
   return 0;
}
//function defintion of isEmpty
int isEmpty(){
    return idx == -1;
}
//function defintion of isfull
int isFull(){
    return idx == MAX - 1;
}
//function defintion of enqueue
void enqueue(int data, int priority)
{
    if(!isFull()){
        
        idx++;
 
        pqVal[idx] = data;
        pqPriority[idx] = priority;
    }
}
//function defintion of peek
int peek()
{
    int maxPriority = INT_MIN;
    int indexPos = -1;
 
    for (int i = 0; i <= idx; i++) { 
        if (maxPriority == pqPriority[i] && indexPos > -1 && pqVal[indexPos] < pqVal[i]) 
        {
            maxPriority = pqPriority[i];
            indexPos = i;
        }
        
        else if (maxPriority < pqPriority[i]) {
            maxPriority = pqPriority[i];
            indexPos = i;
        }
    }
    
    return indexPos;
}
//function defintion of dequeue
void dequeue()
{
    if(!isEmpty())
    {
        int indexPos = peek();//calling to function peek

        for (int i = indexPos; i < idx; i++) {
            pqVal[i] = pqVal[i + 1];
            pqPriority[i] = pqPriority[i + 1];
        }
 
        idx--;
    }
}
//function defintion of display
void display(){
    for (int i = 0; i <= idx; i++) {
        printf("(%d, %d)\n",pqVal[i], pqPriority[i]);
    } 
}

