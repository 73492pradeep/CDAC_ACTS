//Implementation of code of the doubly circula linked list
#include<stdio.h>
#include<stdlib.h>
struct node{
	struct node *prev;
	int data;
	struct node *next;
};
//Function decleration
void InsertAtBeg(struct node **,int );
void InsertAtEnd(struct node **,int );
void InsertAtPos(struct node **,int );
void display(struct node **);
void deleteFromBeg(struct node **);
void deleteFromEnd(struct node **);
void deleteFromPos(struct node **);
void reverseDisplay(struct node **);
void revrselist(struct node **);
void freeallnode(struct node **p);
//main function starts
int main()
{
	struct node *head;
	head=NULL;
	int choice,ele;
	while(1)
	{
	printf("\n==========Enter the choice========\n");
	printf("1----->InsertAtBeg\n");
	printf("2----->InsertAtEnd\n");
	printf("3----->InsertAtPos\n");
	printf("4----->Display\n");
	printf("5----->delete form begining\n");
	printf("6----->delete form End\n");
	printf("7----->delete form Position\n");
	printf("8----->reversedisplay\n");
	printf("9----->reverse linked list\n");
	printf("10---->free all node\n");
	printf("11---->exit\n");
	scanf("%d",&choice);						//User Input
	switch(choice)
	{
		case 1:
			printf("Enter the element:\t");
			scanf("%d",&ele);				//User input
			InsertAtBeg(&head,ele);				//Calling to Function InsertAtBeg
			break;
		case 2:
			printf("Enter the element:\t");
			scanf("%d",&ele);				//User Input
			InsertAtEnd(&head,ele);				//Calling to Function InsertAtEle
			break;
		case 3:
			printf("Enter the element:\t");
			scanf("%d",&ele);				//User Input
			InsertAtPos(&head,ele);				//Calling to function InsertAtPos
			break;
		case 4:
			display(&head);					//Calling to function display
			break;
		case 5:
			deleteFromBeg(&head);				//Calling to deleteFromBeg
			break;
		case 6:
			deleteFromEnd(&head);				//Calling to deleteFromEnd
			break;
		case 7:
			deleteFromPos(&head);				//Calling to deleteFromPos
			break;
		case 8:
			reverseDisplay(&head);				//Calling to reverseDisplay
			break;
		case 9:
			revrselist(&head);				//Calling to reverlist
			break;
		case 10:
			freeallnode(&head);
			break;
		case 11:
			exit(0);
	}
	}
	freeallnode(&head);						//Calling to function freeallnode
	return 0;
}
//End of the main function
//Function defintion to insert an element from begining of the linked list
void InsertAtBeg(struct node **p,int ele)
{
	struct node *temp,*t1=*p;
	temp=(struct node*)malloc(sizeof(struct node));				//allocating memory to temp through malloc
	if(temp==NULL)
	{
		printf("\n======Memory is not allocated======\n");
		return;
	}
	temp->prev=NULL;
	temp->data=ele;
	temp->next=NULL;
	if(*p==NULL)
	{
		*p=temp;
		temp->next=*p;
	}else{
		while(t1->next!=*p)
		{
			t1=t1->next;
		}
		temp->next=*p;
		(*p)->prev=temp;
		temp->prev=t1;
		*p=temp;
		t1->next=*p;
		printf("\n======Data is succesfully added=======\n");
	}
}
//Function defintion to insert an element from Ending of the linked list
void InsertAtEnd(struct node **p,int ele)
{
	struct node *temp,*t1=*p;
	temp=(struct node*)malloc(sizeof(struct node));			//allocating memory to the temp through malloc
	if(temp==NULL)
	{
		printf("\n=====Memory is not allocated======\n");
		return;
	}
	temp->prev=NULL;
	temp->data=ele;
	temp->next=NULL;
	if(*p==NULL)
	{
		*p=temp;
		temp->next=*p;
	}else{
		while(t1->next!=*p)
		{
			t1=t1->next;
		}
		t1->next=temp;
		temp->prev=t1;
		temp->next=*p;
		(*p)->prev=temp;
	}
}
//Function defintion to insert an element from taking position form user of the linked list
void InsertAtPos(struct node **p,int ele)
{
	int count=1,pos;
	printf("Enter the position:\t");
	scanf("%d",&pos);						//User Input
	struct node *temp,*t1=*p,*t2=NULL;
	temp=(struct node*)malloc(sizeof(struct node));
	if(temp==NULL)
	{
		printf("\n======Memory is not allocated======\n");
		return;
	}
	temp->prev=NULL;
	temp->data=ele;
	temp->next=NULL;
	if(*p==NULL)
	{
		InsertAtBeg(p,ele);
		return;
	}else{
		while(count<pos)
		{
			t2=t1;
			t1=t1->next;
			count++;
		}
		temp->next=t1;
		t1->prev=temp;
		temp->prev=t2;
		t2->next=temp;
	}
}	
//Function defintion to display the elements of the linked list
void display(struct node **p)
{
	struct node *t1=*p;
	if(*p==NULL)
	{
		printf("======No linked list present=====\n");
		return;
	}else{
		printf("head---->[%p]",*p);
		while(t1->next!=*p)
		{
			printf("---->[%p][%d][%p]",t1->prev,t1->data,t1->next);
			t1=t1->next;
		}
			printf("---->[%p][%d][%p]\n",t1->prev,t1->data,t1->next);
	}
	printf("\n");
}
//Function defintion to delete an element from begining of the linked list
void deleteFromBeg(struct node **p)
{
	struct node *t1=*p,*t2=*p;
	if(*p==NULL)
	{
		printf("\n======No linked list present=======\n");
	}else{
		while(t1->next!=*p)
		{
			t1=t1->next;
		}
		*p=t2->next;
		t1->next=t2->next;
		(*p)->prev=t1;
		free(t2);
	}
}
//Function defintion to delete an element from End of the linked list
void deleteFromEnd(struct node **p)
{
	struct node *t1=*p;
	if(*p==NULL)
	{
		printf("\n=====No linked list present=====\n");
	}else{
		while(t1->next->next!=*p)
		{
			t1=t1->next;
		}
		(*p)->prev=t1;
		t1->next=*p;
	}
}
//Function defintion to delete an element from Position of the linked list
void deleteFromPos(struct node **p)
{
	int count=1,pos;
	struct node *t1=*p,*t2=NULL;
	printf("Enter the position\t");
	scanf("%d",&pos);						//User Input
	if(*p==NULL)
	{
	   	 printf("\n======No linked list present=====\n");
		 return;
	}else if(pos==1)
	{
		deleteFromBeg(p);
		return;
	}else{
		while(count<pos)
		{
			t2=t1;
			t1=t1->next;
			count++;
		}
		t2->next=t1->next;
		t1->next->prev=t2;
		free(t1);
	}
}
//Function defintion to display the elements of the linked list in reverese order
void reverseDisplay(struct node **p)
{
	struct node *t1=*p,*t2=*p;
	int j=0,count=1;
	if(*p==NULL)
	{
		printf("\n=====No linked list present====\n");
	}else{
		while(t1->next!=*p)
		{	
			count++;
			t1=t1->next;
		}
			for(int i=0;i<count;i++)
			{
				j=i;
				while(j<count-1)
				{
					t2=t2->next;
					j++;
				}
				printf("---->[%d]",t2->data);
				t2=*p;
			}
		}
	printf("\n");
}
//Function definiton to reverse the list of the linked list
void revrselist(struct node **p)
{
	struct node *next,*prev,*t1=*p;
	prev=NULL;
	next=NULL;
	while(next!=t1)
	{
		next=(*p)->next;
		(*p)->next=(*p)->prev;
		prev=*p;
		(*p)->prev=prev;
		*p=next;
	}
	*p=prev;
	(*p)->prev=t1;
	t1->next=*p;
	printf("\n=======linked list is successfully reversed====\n");
}
//Funcion definition of freeallnode in which this function free all nodes//
void freeallnode(struct node **p)
{
	struct node *t1=*p,*t2=*p;
	int j=0,count=1;
	if(*p==NULL)
	{
		printf("\n=====No linked list present====\n");
	}else{
		while(t1->next!=*p)
		{	
			count++;
			t1=t1->next;
		}
			for(int i=0;i<count;i++)
			{
				j=i;
				while(j<count-1)
				{
					t2=t2->next;
					j++;
				}
				free(t2);
				t2=*p;
			}
	}
}
