#include<stdio.h>
int findingelement(int [],int);//Declaration of finding element function//
int main()
{
	int ele,n=1,count,i=0,x;
	int arr[40];
	printf("Enter the element :\n");
	scanf("%d",&ele);
	//Here we are finding factor of given number//
	while(n<=ele)
	{
		if((ele%n)==0)//we are comparing remainder of division of given no with the number less than or equal to given no//
		{
		    arr[i]=n;//here we are storing the factor of given no in array//
		    count++;
		    i++;
		    n++;
		}
		else
		{
		    n++;
		}
	}
	for(int k=0;k<count;k++)//here we are printing the factor of given no//
	{
		printf("%d\t",arr[k]);
	}
	printf("\n No of factor =%d\n",count);

	x=findingelement(arr,count);//calling the finding element function//

	if(x)
	{
		printf("Value at the given position =%d",x);
	}

	else
	{
		printf("You have entered a invalid position:\n");
	}
return 0;
}
int findingelement(int arr[],int count)
{
	int p;
	printf("Enter the position from where you want to fetch value:\n");//here we are taking position as input from user//
	scanf("%d",&p);
	for(int i=0;i<count;i++)
	{
		if(i==p-1)
		{
			return arr[i];//if entered position is within the array size range then we are returning the factor value at that given position//
		}	
                else if(p>count)
		{
			return 0;//if entered position is greater than the size of array then we are returning zero//
		}
	}
}
		
	}
}

