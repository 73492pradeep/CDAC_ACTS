//Implement a linear searching method using iterative approach//
#include<stdio.h>
#include<stdlib.h>
//Decalaration of all fuctions//
void search(int arr[],int size);
void print(int arr[],int size);
void reverseprint(int arr[],int size);
int main()
{
	int choice,n;
	printf("Enter the no of element of array:\n");
	scanf("%d",&n);
	int arr[n];
	while(1)
	{
	printf("Enter the choice:\n");
	printf("--->1 for searching array:\n");
	printf("--->2 for printing array:\n");
	printf("--->3 for reversearray:\n");
	printf("--->4 for exit:\n");
	scanf("%d",&choice);
	switch(choice)//implement a menu driven program using switch case//
	{
		case 1:
			search(arr,n);
			break;
		case 2:
			print(arr,n);
			break;
		case 3:
			reverseprint(arr,n);
			break;
		case 4:
			exit(0);
	}
	}
return 0;
}
//definition of all fuction starts from here//
void search(int arr[],int size)
{
	int ele,i;
	printf("Enter the element that you want to search:\n");
	scanf("%d",&ele);
	for(i=0;i<size;i++)
	{
		if(ele==arr[i])
		{
			printf("Element is present at %d position\n",i+1);
		}
	}
}
void print(int arr[],int size)
{
	printf("Enter the element of array:\n");
	for(int i=0;i<size;i++)
	{
		scanf("%d",&arr[i]);
	}
	printf("Element of array:\n");
	for(int i=0;i<size;i++)
	{
		printf("%d\t",arr[i]);
	}
	printf("\n");
}
void reverseprint(int arr[],int size)
{
	for(int i=size-1;i>=0;i--)

	{
		printf("%d\t",arr[i]);
	}
	printf("\n");
}



