//Implement a c program for linear search using recursion approach//
#include<stdio.h>
#include<stdlib.h>
//Definiton of all function starts here//
int search(int [],int,int);
void print(int [],int);
void reverseprint(int [],int);
int main()
{
	int choice,n,ele,x;
	printf("Enter the size of array:\n");
	scanf("%d",&n);
	int arr[n];
	printf("Enter the element of array:");
	for(int i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
	}
	while(1)
	{
		printf("\nEnter the choice:\n");
		printf("1---> for searching element in the array:\n");
		printf("2---> for printing the element of the array:\n");
		printf("3---> for printing the array in reverse order:\n");
		printf("4---> for exit:\n");
		scanf("%d",&choice);
		switch(choice)//Implement a menu driven program using switch case//
		{
			case 1:
				printf("Enter the element that you want to search:\n");
				scanf("%d",&ele);
				x=search(arr,n,ele);
				printf("Element is present at position %d\n",x+1);
				break;
			case 2:
				print(arr,n);
				break;
			case 3:
				reverseprint(arr,n);
				break;
			case 4:
				exit(0);
		}
	}
return 0;
}
//Definitions of all function starts here//
void print(int arr[],int size)
{
	static int i;
	if(i==size)
	{
		return ;
	}
	printf("%d\t",arr[i]);
	i++;
	print(arr,size);//recursive calling of print fuction//
}
int  search(int arr[],int size,int ele)
{
	static int j;
	if(ele==arr[j])
	{
		return j;
	}
	j++;
	search(arr,size,ele);//recursive calling of search function
}
void reverseprint(int arr[],int size)
{
	int k=size-1;
	if(k<0)
	{
		return ;
	}
	size--;
	printf("%d\t",arr[k]);
	reverseprint(arr,size);//recursive calling of reverseprint function//
}



























