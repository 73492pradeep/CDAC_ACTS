//Implemented a program for binary search by using both iterative as well as recursion//
#include<stdio.h>
#include<stdlib.h>
//Decalaration of all fuctions//
int binarySearch(int *,int ,int ,int);
int binaryrecur(int *,int ,int ,int);
int main()
{
	int start=0,n,ele,x;
	printf("Enter the size of array:\n");
	scanf("%d",&n);
	int arr[n];
	printf("Enter the element of array:\n");
	for(int i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
	}
	printf("Enter the element that you want to search:\n");
	scanf("%d",&ele);
	x=binarySearch(arr,start,n,ele);//calling the binary search fuction//
	printf("Element present at position =%d",x+1);
return 0;
}
//Definition of binary search function//
int binarySearch(int *p, int start, int end, int x)
{
while (start <= end)
{
int mid = start + (end-start)/2;//calcualting the mid position element of array/

if (p[mid] == x)//if element matches with mid element then returning the value at mid position//
return mid;
if (p[mid] < x)//if element is greater than mid element then we assigining the start with the value at mid+1 position//
start = mid + 1;
else
end = mid - 1;//if element is less than mid element then we assiginig the end with the value at mid-1 position//
}
return -1;
}//Definition of binarysearch fuction with use recursion//
int binaryrecur(int *p, int start, int end, int x)
{
while (start <= end)
{
int mid = start + (end-start)/2;

if (p[mid] == x)
return mid;
if (p[mid] < x)
start = mid + 1;
else
end = mid - 1;
}
return binaryrecur(p,start,end,x);
}














