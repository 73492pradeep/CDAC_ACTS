#include<stdio.h>
void finddup(int [],int);//declaration of finding duplicate function//
int main()
{
	int n;
	printf("Enter the no of element of array:\n");
	scanf("%d",&n);
	int arr[n];
	printf("Enter the array element:\n");//Intialization of array//
	for(int i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
	}
	finddup(arr,n);//calling finding duplicate function//
return 0;
}
void finddup(int arr[],int n)//definition of finding duplicate function//
{
	int temp;
	int i=0,j=0,count=0;
	//first we are sorting array element//
	while(i<n)
	{
		j=i+1;
		while(j<n)
		{
			if(arr[i]<arr[j])
			{
				temp=arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
			}
			j++;
		}
		i++;
	}
	i=0;
	//here we are finding duplicate element using while loop while our array has been sorted//
	while(i<n)
	{
		if(arr[i]==arr[i+1])
		{
			count++;//here we took a count variable that works as indication that element occurs more than one//
			while(arr[i]==arr[i+1])
			{
				i++;
			}
		}
		i++;
	}
	printf("total count=%d",count);//Now we are printing the value of count variable//
}
	

