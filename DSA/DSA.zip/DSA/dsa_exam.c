/*phone directory application*/
// header files
#include<stdio.h>
#include<stdio_ext.h>
#include<stdlib.h>
#define SWAP(a,b) {int t=a;a=b;b=t;}
// define structure
struct node{
	char *name;
	short int house_no;
        unsigned long int phone_no;
        char *address;	
	struct node *next;
};
// function declerations
void add_contact(struct node **);
void display(struct node *);
void search_contact(struct node *);
void bubble_sort(struct node *);
void freeAllNode(struct node **);
int count=0;
// main function
int main()
{
        struct node *head=NULL;    //structure variabal (head)it is head of list       
	int choice;
	while(1){          // while loop will run till infinite until press 0
		printf("Enter the choice :\n1->add_concat\n2->search_contact\n3->bubble_sort\n4->display\n5->freeAllNode\n0->exit : ");
		scanf("%d",&choice);
		switch(choice){      //switch case will help to chose call function
			case 1:
				add_contact(&head);       //call add contact function
				break;
			case 2:
				search_contact(head);     //call search function
				break;
			case 3:
				bubble_sort(head);        //call for sorting function
				break;
			case 4:
				display(head);            //call for desplay
				break;
			case 5:
				freeAllNode(&head);       //call allfree function for free all node
			        break;
			case 0:
				exit(1);
		}
	}
	return 0;
}
// function definition
// it will add the list of user
void add_contact(struct node **p)
{
	struct node *temp=NULL;
	char *name1;         //memory allocat in heap section
	name1=(char*)malloc(sizeof(char));
	if(name1==NULL){
		printf("Malloc is failed\n");
		return;
	}
	short int house_no;
	unsigned long int ph_no;
	char *addr;
	addr=(char*)malloc(sizeof(char));   //memory allocation in heap section
	if(addr==NULL){
		printf("Malloc is failed\n");
		return;
	}
	printf("Enter the name         : ");
	__fpurge(stdin);
	scanf("%[^\n]s",name1);
	printf("Enter the house no     : ");
	scanf("%hd",&house_no);
	printf("Enter the phone number : ");
        scanf("%ld",&ph_no);	
	printf("Enter the address      : ");
	__fpurge(stdin);
	scanf("%[^\n]s",addr);
	temp=(struct node *)malloc(sizeof(struct node));   //memory allocation in heap section for user list
	if(temp==NULL){
		printf("Malloc is failed\n");
		return;
	}
	temp->name=name1;               //temp will creat new list
	temp->house_no=house_no;
	temp->phone_no=ph_no;
	temp->address=addr;
	temp->next=NULL;
	if(*p==NULL){
		*p=temp;
	}else{
		temp->next=*p;
		*p=temp;
	}
	//free(name1);
	//free(addr);
	count++;
}
// function definition
// it will display the list
void display(struct node *p)
{
	struct node *trav=p;
	if(trav==NULL){
		return;
	}
	while(trav!=NULL){         //while loop will run till NULL char and it will print all list
		printf("Name            : %s\n",trav->name);
		printf("House number    : %hd\n",trav->house_no);
		printf("Phone number    : %ld\n",trav->phone_no);
		printf("Address         : %s\n",trav->address);
		trav=trav->next;
	}
}
// function definition
// it will search the list given by the house number
void search_contact(struct node *p)
{
	short int h_no;
	printf("Enter the house number for search : ");
	scanf("%hd",&h_no);
	struct node *t1=p;
	while(t1!=NULL){
		if(t1->house_no==h_no){        //if house number match so it will print the list
		       printf("Name            : %s\n",t1->name);
		       printf("House number    : %hd\n",t1->house_no);
		       printf("Phone number    : %ld\n",t1->phone_no);
		       printf("Address         : %s\n",t1->address);
		}
		t1=t1->next;
	}


}
// function definition 
// it will sort the list
void bubble_sort(struct node *p)
{
	int temp;
	struct node *t1=p;
	struct node *t2=NULL;
	while(t1!=NULL){             //while loop run till NULL char
		t2=t1->next;
		while(t2!=NULL){     //while loop run till NULL char
			if(t1->house_no>t2->house_no){
				SWAP(t1->house_no,t2->house_no);
			}
			t2=t2->next;
		}
		t1=t1->next;
	}
}
// function definition
// it will free all node
void freeAllNode(struct node **p)
{
	struct node *t1=*p;
	while(t1->next!=NULL){    //it will free all node one by one
		*p=t1->next;
		free(t1);         //free node only one
		t1=*p;            //pass the head(*p) into t1
	}
}

