/*Q2. Write a C/C++ program to implement single linked list.
Implement below metioned functions. Apply all required condition
check & validation like list empty or not, while inserting/deleting by
position validate the position.
a)insertAtEnd b) insertAtBeg c) insertAtPos d) displayList
e)listNodeCount f) deleteFromEnd g) deleteFromBeg
h)deleteFromPos i) deleteByElement j) reverseDisplay
k)freeAllNode l) reverseList m)sortedList*/

#include<stdio.h>
#include<stdlib.h>
// structure member
struct node{
	       int data;
	       struct node *next;
           };
//function decleration
void insert();
void display_list();
void insertAtBeg();
void insertAtPos();
void insertAtEnd();
void deletFromBeg();
void deletFromEnd();
void deletFromPos();
void node_count();
void deletByElement();
void rev_display();
void sortedList();
void freeAllNode();
void rev_list();
struct node *head=NULL;
int main()
{
	int choice;
	while(1){          //loop will run infinite times until press 0
	printf("\nEnter the choice :\n1->insert\n2->display\n3->ainsertAtBeg\n4->insertAtPos\n5->ainsertAtEnd\n6->deletFromBeg\n7->deleatFromEnd\n8->deletFromPos\n9->node_count\n10->deletByElement\n11->rev_Display\n12->sortedList\n13->rev_list\n14->freeAllNode\n0->exit : ");
	scanf("%d",&choice);
	switch(choice){    // switch case will help to chose oprration
		    case 1:
			    insert();             //function call
			    break;
	        case 2:
			    display_list();      //function call
			    break;
	        case 3:
			    insertAtBeg();        //function call
			    break;
		    case 4:
			    insertAtPos();         //function call
			    break;
		    case 5:
			    insertAtEnd();          //function call
			    break;
		    case 6:
			    deletFromBeg();          //function call
			    break;
		    case 7:
			    deletFromEnd();           //function call
			    break;
		    case 8:
			    deletFromPos();            //function call
			    break;
		    case 9:
			    node_count();              //function call
			    break;
		    case 10:
			    deletByElement();          //function call
			    break;
			case 11:
			    rev_display();              //function call
			    break;
			case 12:
				sortedList();                //function call
				break;
			case 13:
				rev_list();                  //function call
				break;
			case 14:
				freeAllNode();                //function call
				break;
		    case 0:
			    exit(0);
	}
	}
	freeAllNode();                  //it will free all the node
	free(head);                      //it will free head
	return 0;
}
// function definition
// user can insert info
void insert()
{
	int ele;
	printf("Enter the element : ");
	scanf("%d",&ele);
	struct node *temp,*trav;
	trav=head;
	temp=(struct node*)malloc(sizeof(struct node));
	temp->data=ele;
	temp->next=NULL;
	if(head==NULL){
		head=temp;
	}
	else{
		while(trav->next!=NULL){
			trav=trav->next;
		}
		trav->next=temp;
	}

}
// function definition
// it will print all linklist
void display_list()
{
	struct node *trav;
	trav=head;
	while(trav!=NULL){
		printf("-->|%d|",trav->data);
		trav=trav->next;
	}
}
// function definition
// user can insert info at beg
void insertAtBeg()
{
	int ele;
	printf("Enter the ele addAtBeg : ");
	scanf("%d",&ele);
	struct node *temp;
	temp=(struct node*)malloc(sizeof(struct node));   //allocated memory in  heap section for struct member
	temp->data=ele;
	temp->next=NULL;
	if(head!=NULL)
	{
		temp->next=head;
		head=temp;
	}
	else {
		head=temp;
	}
}
//function definition
//user can insert info at end pos
void insertAtEnd()
{
	int ele;
	printf("Enter the ele addAtEnd : ");
	scanf("%d",&ele);
	struct node *temp,*trav;
	trav=head;
	temp=(struct node*)malloc(sizeof(struct node));    //allocated memory in heap section for now list
	temp->data=ele;
	temp->next=NULL;
	if(head==NULL){
		head=temp;
	}
	else{
		while(trav->next!=NULL){
			trav=trav->next;
		}
		trav->next=temp;
	}
}
//function defition 
//user can insert at pos in linklist
void insertAtPos()
{
	int ele,pos,count=1;
	printf("Enter the pos : ");
	scanf("%d",&pos);
	if(pos==1){
		insertAtBeg();
	}else{
	printf("Enter the ele addAtPos : ");
	scanf("%d",&ele);
	struct node *temp,*trav;
	trav=head;
	temp=(struct node*)malloc(sizeof(struct node));    // memory allocated in heap section for name
	temp->data=ele;
	temp->next=NULL;
	while(count<pos-1){
		trav=trav->next;
		count++;
	}
		temp->next=trav->next;
		trav->next=temp;
}
}
//function definition
//user can delet linklist from Beg
void deletFromBeg()
{
	struct node *temp=head;
	if(head==NULL){
            return;
	}else{
	head=temp->next;
	free(temp);
	}
}
//function definition
//user can delet linklist from end
void deletFromEnd()
{
	struct node *trav=head;
	struct node *trav1=NULL;
	if(head==NULL){
		return;
	}else{
		while(trav->next!=NULL){
			trav1=trav;
			trav=trav->next;
		
		}
		trav1->next=trav->next;
		free(trav);
	}
	if(trav1->next!=NULL){
		trav1->next=NULL;
	}
}
//function definition 
//user can delet linklist from pos
void deletFromPos()
{
	int pos,count=1;
	printf("Enter the pos for deletFromPos : ");
	scanf("%d",&pos);
	struct node *trav=head;
	struct node *trav1=NULL;
	if(pos==1){
		deletFromBeg();
	}else{
		while(count<pos-1){
			trav1=trav;
			trav=trav->next;
			count++;
		}
		trav1->next=trav->next;
		free(trav);
	}
}
//function definition
//It will count the linklist
void node_count()
{
	int count=0;
	struct node *trav=head;
	while(trav!=NULL){
		count++;
		trav=trav->next;
	}
	printf("The number of node is = %d\n",count);
}
//function definition
//it will delet by entering the ele
void deletByElement()
{
	int ele;
	printf("Entter the ele for deletByElement : ");
	scanf("%d",&ele);
	struct node *temp=head;
	struct node *temp1=NULL;
	if(head==NULL){
		return;
	}
	if(head->data==ele){
		head=temp->next;
        free(temp);
	}
	else{

          while(temp->data!=ele){
		        temp1=temp;     
		        temp=temp->next;
		  } 
		    temp1->next=temp->next;
		    free(temp);
		  }
}
//function definition
//it will reverse the linklist
void rev_display()
{
	int arr[10];
	int k=0;
	struct node *trav=head;
	if(head==NULL){
		return;
	}
	while(trav!=NULL){
		arr[k]=trav->data;
		trav=trav->next;
		k++;
	}
	for(int i=k-1;i>=0;i--){
		printf("-->|%d|",arr[i]);
	}
}
//function definition
//function for sort list the element
void sortedList()
{
	int temp;
	struct node *t1,*t2;
	if(head==NULL){
		return;
	}
	t1=head;
    while(t1!=NULL){
		t2=t1->next;
	       while(t2!=NULL){
		         if(t1->data>t2->data){
			        temp=t1->data;
			        t1->data=t2->data;
                    t2->data=temp;
		         }
				 t2=t2->next;
	        }
			t1=t1->next;
	}
}
//function definition
//it will revers the list
void rev_list()
{
	struct node *prev,*trav=head;
	prev=NULL;
	if(head==NULL){
		return;
	}else{
		while(trav!=NULL){
			trav=trav->next;
			head->next=prev;
			prev=head;
			head=trav;
		}
		head=prev;
	}
}
//function definition
//it will free all linklist
void freeAllNode()
{
	struct node *trav=head;
	if(head==NULL){
		return;
	}
	while(trav!=NULL){
		head=trav->next;
		free(trav);
		trav=head;
	}
}


	



