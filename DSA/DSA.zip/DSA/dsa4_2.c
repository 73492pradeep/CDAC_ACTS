// stack
/*Q2. Write a C/C++ program to implement stack data structure using
array. Implement below metioned functions.
a) push
b) pop
c) peep d) displayStack
e)isStackFull
f) isStackEmpty*/

// header file
#include<stdio.h>
#include<stdlib.h>
#define MAX 5
//function decleration
void pushEle(int arr[],int *top,int ele);
void popEle(int *,int *);
void display(int arr[]);
void isStackEmpty(int *top);
void isStackFull(int *top);
void peepEle(int arr[],int *);
//main function
int main()
{
	int choice,ele;
	int arr[MAX];        // array define 
	int top=-1;
	for(int i=0;i<MAX;i++){   //it will fill tha garbage value as -99
		arr[i]=-99;
	}
	while(1){            //while loop will run till infinit time
		printf("\nEntter the choice :\n1->PushEle\n2->PopEle\n3->Display\n4->isStackFull\n5->IsStackEmpty\n6->peepEle\n0->exit : ");
                scanf("%d",&choice);
		switch(choice){     //switch case will help to select the function call
			case 1:
				printf("\nEnter the element for push : ");
				scanf("%d",&ele);
				pushEle(arr,&top,ele);   //call push element function
				break;
			case 2:
				popEle(arr,&top);        //call pop element function
				break;
			case 3:
				display(arr);            //call display function
				break;
			case 4:
				isStackFull(&top);       //call is stack full function
				break;
			case 5:
				isStackEmpty(&top);      //call is stack empty function
				break;
			case 6:
				peepEle(arr,&top);       //call peep function
				break;
			case 0:
				exit(0);                 //it will exit the while loop
		}
	}
	return 0;
}
// function definition
// it will push the element in stack
void pushEle(int arr[],int *top,int ele)
{
	if(*top==MAX-1){             //it will check stack full status
		printf("Stack is full\n");
		return;
	}else{
		(*top)++;
		arr[*top]=ele;
	}
}
// function definition
// it will pop the element from stack
void popEle(int arr[],int *top)
{
	if(*top==-1){            //it will check stack empty status
		printf("Stack is empty\n");
		return;
	}else{
	printf("The pop ele is = %d\n",arr[*top]);
	arr[*top]=-99;
	(*top)--;
	}
}
// function definition
// it will display the element of stack
void display(int arr[])
{
	for(int i=0;i<MAX;i++){      //this for loop will run till max value
		printf("%d ",arr[i]);
	}
}
// function definition
// it will check the stack full condition
void isStackFull(int *top)
{
	if(*top==MAX-1){
		printf("stack is full\n");
		return;
	}
	return;
}
// function definition
// it will check the stack empty condition
void isStackEmpty(int *top)
{
	if(*top==-1){
		printf("stack is empty\n");
		return;
	}
	return;
}
// function definition
// it will peep the element
void peepEle(int arr[],int *top)
{
	if(*top!=-1){
		printf("The peep ele is :%d\n",arr[0]);
		return;
	}
	return;
}





