//Doubly linear link list
#include<stdio.h>
#include<stdlib.h>
struct node{
           struct node *prev;
           int data;
           struct node *next;
           };
void insertAtBeg();
void insertAtEnd();
void insertAtPos();
void displaylist();
void deletFromBeg();
void deletFromEnd();
void deletFromPos();
void nodeCount();
struct node *head=NULL;
int main()
{
    int choice;
    while(1){
        printf("\nEnter the choice :\n1->insertAtBeg\n2->insertAtEnd\n3->insertAtPos\n4->displaylist\n5->deletFromBeg\n6->deletFromEnd\n7->deletFromPos\n8->nodeCount\n0->exit : ");
        scanf("%d",&choice);
        switch(choice){
            case 1:
                   insertAtBeg();
                   break;
            case 2:
                   insertAtEnd();
                   break;
            case 3:
                   insertAtPos();
                   break;
            case 4:
                   displaylist();
                   break;
            case 5:
                   deletFromBeg();
                   break;
            case 6:
                   deletFromEnd();
                   break;
            case 7:
                   deletFromPos();
                   break;
	    case 8:
		   nodeCount();
		   break;
            case 0:
                   exit(0);
        }
    }
}
void insertAtBeg()
{
    int ele;
    printf("\nEnter the ele for insertAtBeg : ");
    scanf("%d",&ele);
    struct node *temp=NULL;
    temp=(struct node*)malloc(sizeof(struct node));
    if(temp==NULL){
        printf("No allocated memory");
    }
    temp->prev=NULL;
    temp->data=ele;
    temp->next=NULL;
    if(head==NULL){
        head=temp;
    }else{
        temp->next=head;
        head->prev=temp;
        head=temp;
    }
}
void insertAtEnd()
{
    int ele;
    printf("Enter the ele for insertAtEnd : ");
    scanf("%d",&ele);
    struct node *trav,*temp=NULL;
    trav=head;
    temp=(struct node*)malloc(sizeof(struct node));
    if(temp==NULL){
        printf("No memory allocated");
    }
    temp->prev=NULL;
    temp->data=ele;
    temp->next=NULL;
    if(head==NULL){
        head=temp;
    }else{
        while(trav->next!=NULL){
            trav=trav->next;
        }
        trav->next=temp;
        temp->prev=trav;
    }
}
void insertAtPos()
{
    int ele,pos=0,count=1;
    printf("Enter the pos for insertAtPos : ");
    scanf("%d",&pos);
    if(pos==1){
        insertAtBeg();
	return;
    }
    printf("Enter the ele for insertAtPos : ");
    scanf("%d",&ele);
    struct node *temp=NULL;
    struct node *t1,*t2=NULL;
    t1=head;
    temp=(struct node*)malloc(sizeof(struct node));
    if(temp==NULL){
        printf("No memory allocated");
    }
    temp->prev=NULL;
    temp->data=ele;
    temp->next=NULL;
    if(head==NULL){
        head=temp;
    }else{
        t2=t1->next;
        while(count<pos-1){
            t1=t2;
            t2=t2->next;
	    count++;
        }
        temp->prev=t1;
        temp->next=t1->next;
        t1->next=temp;
        t2->prev=temp;
    }
}
void displaylist()
{
    struct node *trav=head;
    if(head==NULL){
        return;
    }
    while(trav!=NULL){
        printf("-->|%d|",trav->data);
        trav=trav->next;
    }
}
void deletFromBeg()
{
	struct node *t1=head;
	if(head==NULL){
		return;
	}else{
		head=t1->next;
		free(t1);
	}
}
void deletFromEnd()
{
	struct node *t1=NULL,*t2=head;
	if(head==NULL){
		return;
	}else{
		while(t2->next!=NULL){
			t1=t2;
			t2=t2->next;
		}
		t1->next=t2->next;
		free(t2);
	}
}
void deletFromPos()
{
	int pos,count=1;
	printf("Enter the pos for deletfromPos : ");
	scanf("%d",&pos);
	if(pos==1){
		deletFromBeg();
		return;
	}
	struct node *t1=head,*t2=NULL;
	t2=t1->next;
	if(head==NULL){
		return;
	}else{
		while(count<pos-1){
			t1=t2;
			t2=t2->next;
			count++;
		}
		t1->next=t2->next;
		t2->next->prev=t1;
		free(t2);
	}
}
void nodeCount()
{
	int count=0;
	struct node *t1=head;
	if(head==NULL){
		return;
	}
	while(t1!=NULL){
		t1=t1->next;
		count++;
	}
	printf("the number of node is = %d\n",count);
}
