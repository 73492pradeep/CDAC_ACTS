#include<stdio.h>
#include<stdlib.h>
struct node{
	int data;
	struct node *next;
};
void push(int max);
void pop();
void display(int max);
struct node *head;
int count=0;
int main()
{
	int choice,max=6;
	while(1){
		printf("\nEnter the choice :\n1->pushInStack\n2->popInStack\n3->display\n0->exit : ");
		scanf("%d",&choice);
		switch(choice){
			case 1:
				push(max);
				break;
			case 2:
				pop();
				break;
			case 3:
				display(max);
				break;
			case 0:
				exit(0);
		}
	}
	return 0;
}
void push(int max)
{
	int ele;
	struct node *temp;
	if(count>=6){
		printf("stack is full\n");
		return;
	}
	printf("Enter the ele : ");
	scanf("%d",&ele);
	temp=(struct node*)malloc(sizeof(struct node));
	if(temp==NULL){
		printf("malloc is failed\n");
		return;
	}
	temp->data=ele;
	temp->next=NULL;
	if(head==NULL){
		head=temp;
		count++;
	}else{
		temp->next=head;
		head=temp;
		count++;
	}
}
void pop()
{
	struct node *t1=head;
	if(head==NULL){
		printf("stack is empty\n");
		return;
	}else{
		head=t1->next;
		printf("The pop ele is = %d\n",t1->data);
		free(t1);
		count--;
	}
}
void display(int max)
{
	int count2=0;
	if(count==0){
		printf("There is no element in stack\n");
		return;
	}
	struct node *t1=head;
	while(count2<count){
		printf("--|%d|",t1->data);
		t1=t1->next;
		count2++;
	}
}

				    

