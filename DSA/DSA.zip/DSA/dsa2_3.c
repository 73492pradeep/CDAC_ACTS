/*Determine the factors of a number (i.e., all positive integer values that evenly divide into a number) and then
return the pth element of the list, sorted ascending. If there is no pth element*/

#include<stdio.h>
//function decleration
void search_num(int arr[],int j);
int factor(int arr[],int n);
//main function
int main()
{
	int n,a;
	printf("enter  the number the for factor : \n");
	scanf("%d",&n);
	int arr[10];
	a=factor(arr,n);                    //call factor function
	search_num(arr,a);                  //call search function for searching the factor
	return 0;
}
// function definition
// it will collect the factor of number
int factor(int arr[],int n)
{
	int j=0;
	for(int i=1;i<=n;i++){              //for loop will run till number
		if(n%i==0){
			arr[j]=i;           //array will the factor
			j++;
		}
	}
	printf("the factors are = %d\n",j);   
	for(int i=0;i<j;i++){
		printf("%d ",arr[i]);       //it will print all factor
	}
	return j;
}
// function definition
// it will search the user input in factor
void search_num(int arr[],int j)
{
	int b;
	printf("\nEnter the number for search : ");
	scanf("%d",&b);
	int i;
	for(i=0;i<j;i++){                    //loop will run till last factor
		if(arr[i]==b){
			break;
		}
	}
	printf("the number %d is at the index of %d\n",arr[i],i);   //it will print index and element
}
