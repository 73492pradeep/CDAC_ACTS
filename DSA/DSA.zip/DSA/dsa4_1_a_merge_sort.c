// merge sort
// header files
#include<stdio.h>
#include<stdlib.h>
//function decleration
void display(int *,int, int);
void merge_sort(int *, int, int);
void mearg(int *, int ,int, int, int);
// main function
int main()
{
	int num;
	printf("\nEnter the num for range of arr : ");
	scanf("%d",&num);
	printf("\nEnter the array ele ...");
	int arr[num];
	for(int i=0;i<num;i++){                         // scan array
	        scanf("%d",&arr[i]);
	}
	printf("-------Before sorting-------\n");
	display(arr,0,num);                             //call display function
	printf("-------In merge sort----\n");
	merge_sort(arr,0,(num-1));                      //call sorting function
	printf("-------After merging-------\n");
	for(int i=0;i<num;i++){                         //print final merge array
	        printf("%d ",arr[i]);
	}
	printf("\n");
	return 0;
}
// function definition
// it will print display in range
void display(int arr[],int left,int right)
{
	printf("Display for %d - %d index\n",left,right);
	for(int i=left;i<right;i++){                   
		printf("%d ",arr[i]);
	}
	printf("\n");
}
// function definition 
// it will seprate the all array
void merge_sort(int arr[],int left,int right)
{
	int mid;
	display(arr,left,(right+1));                     //call display function with range
	if(left >= right){
		return;
	}
	mid=(left+right)/2;                              //call merge_sort function with arr range
	merge_sort(arr,left,mid);
	merge_sort(arr,(mid+1),right);                   //call merge_sort function with arr range
	printf("-------Left subarray-------\n");
	display(arr,left,mid);                           //call display function
	printf("-------Right subarray------\n");
	display(arr,(mid+1),right);                      //call display function
	mearg(arr,left,mid,(mid+1),right);	
}
// function definition
// it will merge all saprate array
void mearg(int arr[],int first1,int last1,int first2,int last2)
{
        int *st=NULL;
	int a=first1,b=first2,c=0,x;
	x=(last1-first1+1)+(last2-first2+1);            //the x var will collect the size for allocating memory
	st=(int*)malloc(x*sizeof(int));                 //allocated memory in heap section for st 
	if(st==NULL){
		printf("malloc is failed");
	}
	while(a<=last1&&b<=last2){                      //this loop will run with range of 'a' and 'b'
		if(arr[a]<arr[b]){                      //if will compair the array element
			st[c]=arr[a];
			a++;
			c++;
		}else{
			st[c]=arr[b];
			b++;
			c++;
		}
	}
	while(a<=last1){                                 //this loop will run range of 'a'
		st[c]=arr[a];
		a++;
		c++;
	}
	while(b<=last2){                                //this loop will run range of 'b'
		st[c]=arr[b];
		b++;
		c++;
	}
	c=0;
	for(int i=first1;i<=last2;i++){                //this loop will store element from st pointer to int
		arr[i]=st[c];
		c++;
	}
	display(arr,first1,(last2+1));                 //call display function
	free(st);                                      //free st pointer from heap
}


