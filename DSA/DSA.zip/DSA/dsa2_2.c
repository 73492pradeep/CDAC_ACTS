/*Q2. Write a C/C++ program to implement Binary Search. We need to check for duplicate element
inputs, if found any should not insert into the input array. The array should manage in sorted order.
Apply a duplicacy check on the element while inserting the element, if found duplicate then discards
the input. The input element should insert in the array at the right position( index). Appropriate
shifting can be applied in the array in order to insert the input element at the right position. An
appropriate condition check needs to apply for element not found scenario.
(a) Binary Search ( iterative approach)
(b) Binary Search ( recursion approach )*/

//Binary search
//
#include<stdio.h>
#include<stdlib.h>
//function decleraction
void binary_search(int arr[],int start,int end,int ele);
void scan_arr(int arr[],int c);
void display(int arr[],int c);
int binaryRec(int arr[],int start,int end,int ele);
// main function
int main()
{
	int ele,c,start,end,choice;
	printf("Enter the element range  : ");
	scanf("%d",&c);                          //user can scan range of array
	int arr[c];
	scan_arr(arr,c);                         //call the  function
	start=0;
	end=c-1;
	while(1){                                //the loop will run infinit time 
		printf("\nEnter your choice :\n1->display\n2->binary_search\n3->binaryRec\n0->exit :");
		scanf("%d",&choice);
		switch(choice){                  //switch case will heap to user for chosing the function
			case 1:
				display(arr,c);                              //call display function
				break;
			case 2:
	                        printf("Enter the ele for search : ");
	                        scanf("%d",&ele);
				binary_search(arr,start,end,ele);            //call binary function with iterative approach
				break;
			case 3:
	                        printf("Enter the ele for search : ");
	                        scanf("%d",&ele);
				int x=binaryRec(arr,start,end,ele);          //call binary function with recursion approach
	                        if(arr[x]==ele)
	                        printf("\nThe ele %d Found at Index =  %d\n",ele,x);
				break;
			case 0:
				exit(0);                                    //press 0 for exit out of while loop
		}
	}
	return 0;
}
// function definition
// it will display the array
void display(int arr[],int c)
{
	for(int i=0;i<c;i++){                 //for loop will run till c var                            
		printf("%d ",arr[i]);
	}
}
// function definition 
// it will scan the all array
void scan_arr(int arr[],int c)
{
	printf("Enter the element : ");
	for(int i=0;i<c;i++){                //this for loop will run till c var
		scanf("%d",&arr[i]);         //it will scan the array till range
	}
}
// function definition 
// ti will search the element given by user
void binary_search(int arr[],int start,int end,int ele)
{
	int comp=0,pos=0,mid;
	mid= start + (end-start)/2;          // here user will find mid of array element
        while(start <= end){                 // while loop will run till start!>end
	    mid= start + (end-start)/2;
	      if(arr[mid]==ele){             //here if element found it will return element
		      pos=mid;
		 }
	      if(arr[mid]<ele){              // here we seprate left subarray
		      start=mid+1;
	      }
	      else
		      end=mid-1;             //here we seprate right subarray
	     
        }
	if(arr[pos]==ele)                   // if element is found it will print value given by user
	   printf("\nThe ele %d Found at Index =  %d\n",ele,pos);
}
// function definition
// it will search the element using recursion approach
int binaryRec(int arr[],int start,int end,int ele)
{
	int pos=0,mid;;
        if(start <= end){                  //it will stop until start!>end
	    mid= start + (end-start)/2;    //here user will find mid of array element
	      if(arr[mid]==ele){           //if ele is found ti will return element
		     return mid;
		 }
	      if(arr[mid]<ele){            
		      binaryRec(arr,(mid+1),end,ele);   //call function with range of right subarray
	      }
	      else{
		      binaryRec(arr,start,(mid-1),ele); //call function with range of legt subarray
	      }
        }
}
