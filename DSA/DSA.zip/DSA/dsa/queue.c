#include<stdio.h>
#include<stdlib.h>
void enqueue(int a[],int *f,int *r,int ele);
void dequeue(int a[],int *f1,int *r1);
void display(int arr[]);
#define MAX 5
int main()
{
    int a[MAX],ele;
    int front=-1,rear=-1,choice;
    for(int i=0;i<MAX;i++){
        a[i]=-99;
    }
    while(1){
        printf("\nEnter the choice :\n1->enqueue\n2->dequeue\n3->display\n0->exit : ");
        scanf("%d",&choice);
        switch(choice){
            case 1:
                   printf("Enter the ele for enqueue : ");
                   scanf("%d",&ele);
                   enqueue(a,&front,&rear,ele);
                   break;
            case 2:
                   dequeue(a,&front,&rear);
                   break;
            case 3:
                   display(a);
                   break;
            case 0:
                   exit(0);
        }
    }
}
void enqueue(int a[],int *f,int *r,int ele)
{
    if(*r==MAX-1){
        printf("Queue is full\n");
        return;
    }
    (*r)++;
    a[*r]=ele;
    if(*f==-1){
        *f=0;
    }
}
void dequeue(int a[],int *f1,int *r1)
{
    if(*f1==-1){
        printf("Queue is empty\n");
        return;
    }
    printf("Dequeue ele is = %d\n",a[*f1]);
    a[*f1]=-99;
    if(*f1==*r1){
        *f1=-1;
        *r1=-1;
    }else{
        (*f1)++;
    }
}
void display(int arr[])
{
    for(int i=0;i<MAX;i++){
        printf("%d ",arr[i]);
    }
}