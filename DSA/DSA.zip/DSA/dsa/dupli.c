#include<stdio.h>
#define MAX 10
int main()
{
	int a[MAX];
	int count=0;
	printf("Enter the ele : ");
	for(int i=0;i<MAX;i++){
		scanf("%d",&a[i]);
	}
	for(int i=0;i<MAX-1;i++){
		for(int j=i+1;j<MAX;j++){
			if(a[i]==a[j]){
				count++;
				for(int k=i;k<MAX;k++){
					if(a[i]==a[k+1]){
						i++;
					}
				}
			}i++;
		}
	}
	printf("The duplicate ele is = %d\n",count);
	return 0;
}
