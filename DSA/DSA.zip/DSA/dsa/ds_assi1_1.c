#include<stdio.h>
#include<stdlib.h>
void add_ele(int *a[]);
void del_ele(int *a[]);
void min_ele(int *a[]);
void max_ele(int *a[]);
void display(int *a[]);
void rev_ele(int *a[]);
void search_ele(int *a[]);
void count_ele(int *a[]);
void avg_ele(int *a[]);
void duplicate_ele(int *a[]);
void rev_arr_ele(int *a[]);
int main()
{

      int *a[9];
      for(int i=0;i<9;i++){
          a[i]=(int*)malloc(9*sizeof(int));
      }
      if(a==NULL){
	        printf("malloc is failed");
      }
      printf("Enter the element :\n");
      for(int i=0;i<7;i++){
	        scanf("%d",&(*a[i]));
      }
      int choice;
      while(1){
            printf("\nEnter the choice :\n1->add_ele\n2->del_ele\n3->min_ele\n4->max_ele\n5->display\n6->rev_arr\n7->search_ele\n8->count_ele\n9->avg_ele\n10->duplicate_ele\n11->rev_arr_ele\n0->exit : ");
            scanf("%d",&choice);
      switch(choice){
                case 1:
                      add_ele(a);
                      break;
                case 2:
                      del_ele(a);
                      break;
                case 3:
                      min_ele(a);
                      break;
                case 4:
                      max_ele(a);
                      break;
                case 5:
                      display(a);
                      break;
                case 6:
                      rev_ele(a);
                      break;
                case 7:
                      search_ele(a);
                      break;
                case 8:
                      count_ele(a);
                      break;
                case 9:
                      avg_ele(a);
                      break;
                case 10:
                      duplicate_ele(a);
                      break;
                case 11:
                      rev_arr_ele(a);
                      break;
                case 0:
                      exit(0);
      }
      }
      for(int i=0;i<9;i++){
	        free(a[i]);
      }
      return 0;
}
  void add_ele(int *a[])
      {
        int ele,pos;
        printf("\nenter the ele for add : ");
        scanf("%d",&ele);
        printf("enter the pos for add : ");
        scanf("%d",&pos);
        int i;
        for(i=7;i>=pos;i--){
	      *a[i+1]=*a[i];
        }
        *a[pos]=ele;
      }
  void del_ele(int *a[])
     {
      int pos1;
      printf("\nenter the pos for delet : ");
      scanf("%d",&pos1);
      int j;
      for(j=pos1;j<8;j++){
	      *a[j]=*a[j+1];
      }
    }
 void min_ele(int *a[])
    {
      int temp=*a[0];
      for(int i=0;i<9;i++){
	      if(temp>*a[i]){
		      temp=*a[i];
	      }
      }
      printf("Min element is = %d\n",temp);
    }
 void max_ele(int *a[])
    {
      int temp=*a[0];
      for(int i=0;i<9;i++){
	      if(temp<*a[i]){
		      temp=*a[i];
	      }
      }
      printf("Max element is = %d\n",temp);
    }
 void display(int *a[])
 {
     for(int i=0;i<9;i++){
	          printf("%d ",*a[i]);
       }
 }
 void rev_ele(int *a[])
 {
     for(int i=8;i>=0;i--){
	          printf("%d ",*a[i]);
       }
 }
 void search_ele(int *a[])
 {
    int ele;
    printf("\nEnter the ele for search : ");
    scanf("%d",&ele);
     for(int i=0;i<9;i++){
        if(*a[i]==ele){
	          printf("Element is present = %d\n",*a[i]);
            return;
        }
      }
            printf("\nElement is not present\n");
 }
 void count_ele(int *a[])
 {
  int count=0;
     for(int i=0;i<9;i++){
        if(*a[i]==0){
        }
        else{
          count++;
        }
      }
      printf("Element is = %d\n",count);
 }
 void avg_ele(int *a[])
 {
    int sum=0,j=0;
     for(int i=0;i<9;i++){
         if(*a[i]!=0){
          sum+=*a[i];
          j++;
         }
      }
     printf("The average of element is = %d\n",sum/j);
 }
 void duplicate_ele(int *a[])
 {
    for(int i=0;i<9;i++){
        for(int j=i+1;j<9;j++){
            if(*a[i]==*a[j]){
                  printf("The duplicate ele's index is = %d\n",j);
            }
        }
    }
 }
 void rev_arr_ele(int *a[])
 {
      int temp,n=9;
      for(int i=0;i<n/2;i++){
            temp=*a[i];
            *a[i]=*a[n-i-1];
            *a[n-i-1]=temp;
      }
 }

