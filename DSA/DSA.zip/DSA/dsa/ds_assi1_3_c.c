#include<stdio.h>
#include<stdlib.h>
struct student{
              char std_name[10];
              short int age;
              short int class;
              char subj[10];
              };
void add_std();
void display();
int main()
{   
    struct student *ptr;
    ptr=(struct student*)malloc(sizeof(struct student));
    if(ptr==NULL){
        printf("Malloc is faild\n");
    }
    int choice;
    while(1){
    printf("\nEnter the choice :\n1->add_std\n2->display\n0->exit : ");
    scanf("%d",&choice);
    switch(choice){
           case 1:
                  add_std(ptr);
                  break;
           case 2:
                  display(ptr);
                  break;
           case 0:
                  exit(0);
    }
    }
    return 0;   
}
void add_std(struct student *ptr1)
{
    printf("Enter the std name    : ");
    scanf("%s",&ptr1->std_name);
    printf("Enter the std age     : ");
    scanf("%hd",&ptr1->age);
    printf("Enter the std class   : ");
    scanf("%hd",&ptr1->class);
    printf("Enter the std subject : ");
    scanf("%s",&ptr1->subj);
}
void display(struct student *ptr2)
{
    printf("std name    : %s\n",ptr2->std_name);
    printf("Std age     : %hd\n",ptr2->age);
    printf("Std class   : %hd\n",ptr2->class);
    printf("Std subject : %s\n",ptr2->subj);
}