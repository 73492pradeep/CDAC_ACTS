#include<stdio.h>
#include<stdlib.h>
#define MAX 6
void merge_sort(int arr[],int first,int last);
void merge(int arr[],int f1,int l1,int f2,int l2);
void display(int arr[],int);
int main()
{
    int arr[6]={5,4,2,3,1,6};
    printf("\nthe element is\n");
    display(arr,MAX);
    merge_sort(arr,0,MAX-1);
    display(arr,MAX);
    return 0;
}
void merge_sort(int arr[],int first,int last)
{
    int mid;
    if(first>=last){
        return;
    }
    mid=(first+last)/2;
    merge_sort(arr,first,mid);
    merge_sort(arr,(mid+1),last);
    merge(arr,first,mid,(mid+1),last);
}
void merge(int arr[],int f1,int l1,int f2,int l2)
{
    int c=0,a,b;
    a=f1;b=f2;
    int size=(l1-f1+1)+(l2-f2+1);
    int *res;
    res=(int*)malloc(size*(sizeof(int)));
    if(res==NULL){
        printf("malloc is failed");
        return;
    }
    while(a<=l1 && b<=l2){
        if(arr[a]<arr[b]){
            res[c]=arr[a];
            a++;
            c++;
        }else{
            res[c]=arr[b];
            b++;
            c++;
        }
    }
    while(a<=l1){
        res[c]=arr[a];
        a++;
        c++;
    }
    while(b<=l2){
        res[c]=arr[b];
        b++;
        c++;
    }
    c=0;
    for(int i=f1;i<=l2;i++){
        arr[i]=res[c];
        c++;
    }
    free(res);
}
void display(int arr[],int last)
{
    for(int i=0;i<MAX;i++){
        printf("%d ",arr[i]);
    }
    printf("\n");
}