#include<stdio.h>
#include<stdlib.h>
void c_enqueue(int a[],int *f,int *r,int ele);
void c_dequeue(int a[],int *f1,int *r1);
void display(int arr[]);
#define MAX 5
int main()
{
    int a[MAX],ele;
    int front=-1,rear=-1,choice;
    for(int i=0;i<MAX;i++){
        a[i]=-99;
    }
    while(1){
        printf("\nEnter the choice :\n1->c_enqueue\n2->c_dequeue\n3->display\n0->exit : ");
        scanf("%d",&choice);
        switch(choice){
            case 1:
                   printf("Enter the ele for enqueue : ");
                   scanf("%d",&ele);
                   c_enqueue(a,&front,&rear,ele);
                   break;
            case 2:
                   c_dequeue(a,&front,&rear);
                   break;
            case 3:
                   display(a);
                   break;
            case 0:
                   exit(0);
        }
    }
}
void c_enqueue(int a[],int *f,int *r,int ele)
{
    if(((*f==0)&&(*r==MAX-1))||(*r+1==*f)){
        printf("C_queue is full\n");
        return;
    }
    if(*r==MAX-1){
        (*r)=0;
    }else{
        (*r)++;
    }
    a[*r]=ele;
    if(*f==-1){
        *f=0;
    }
}
void c_dequeue(int a[],int *f1,int *r1)
{
    if(*f1==-1){
        printf("C_queue is empty\n");
        return;
    }
    printf("Dequeue ele is = %d\n",a[*f1]);
    a[*f1]=-99;
    if(*f1==MAX-1&&*r1!=MAX-1){
        *f1=0;
    }else{
         if(*f1==*r1){
            *r1=-1;
            *f1=-1;
         }else{
            (*f1)++;
         }
    }
}
void display(int arr[])
{
    for(int i=0;i<MAX;i++){
        printf("%d ",arr[i]);
    }
}