#include<stdio.h>
#include<stdlib.h>
int main()
{
    int (*a)[3];
    int r=3,c=3;
    a=(int (*)[3])malloc(r*sizeof(int)*c);
    if(a==NULL){
        printf("Malloc is failed \n");
    }
    printf("Enter the element \n");
    for(int i=0;i<r;i++){
        for(int j=0;j<r;j++){
            scanf("%d",&a[i][j]);
        }
    }
    for(int i=0;i<r;i++){
        for(int j=0;j<r;j++){
            printf("%d ",a[i][j]);
        }
    }
    free(a);
}