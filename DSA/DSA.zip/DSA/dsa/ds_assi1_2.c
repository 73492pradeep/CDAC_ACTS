#include<stdio.h>
#include <stdlib.h>
struct emp{
           unsigned int emp_id;
           char emp_name[20];
           double salary;
           short int join_year;
          };
void add_emp(struct emp v[]);
void avg_emp(struct emp v[]);
void max_sal(struct emp v[]);
void min_sal(struct emp v[]);
void display(struct emp v[]);
void max_service(struct emp v[]);
void min_service(struct emp v[]);
int c=0;
int main()
{
    struct emp v[3];
    int choice;
    while(1){
        printf("\nEnter the choice : \n1->add_emp\n2->avg_emp\n3->max_avg\n4->min_avg\n5->display\n6->max_service\n7->min_service\n0->exit : ");
        scanf("%d",&choice);
        switch(choice){
            case 1:
                  add_emp(v);
                  break;
            case 2:
                  avg_emp(v);
                  break;
            case 3:
                  max_sal(v);
                  break;
            case 4:
                  min_sal(v);
                  break;
            case 5:
                  display(v);
                  break;
            case 6:
                  max_service(v);
                  break;
            case 7:
                  min_service(v);
                  break;
            case 0:
                  exit(0);
        }
    }
}
void add_emp(struct emp v[])
{
    printf("Enter the employee id     : ");
    scanf("%u",&v[c].emp_id);
    printf("Enter the employee name   : ");
    //__fpurge(stdin);
    scanf("%s",&v[c].emp_name);
    printf("Enter the employee salary : ");
    scanf("%lf",&v[c].salary);
    printf("Enter the join year       : ");
    scanf("%hd",&v[c].join_year);
    c++;
}
void avg_emp(struct emp v[])
{
    double sum=0;
    for(int i=0;i<c;i++){
        sum+=v[i].salary;
    }
    printf("The average salary of emp is = %.2lf\n",sum/c);
}
void max_sal(struct emp v[])
{
    double temp=v[0].salary;
    for(int i=0;i<c;i++){
        if(temp<v[i].salary){
            temp=v[i].salary;
        }
    }
    printf("The max salary is = %.2lf\n",temp);
}
void min_sal(struct emp v[])
{
    double temp=v[0].salary;
    for(int i=0;i<c;i++){
        if(temp>v[i].salary){
            temp=v[i].salary;
        }
    }
    printf("The min salary is = %.2lf\n",temp);
}
void display(struct emp v[])
{
    unsigned int id;
    printf("\nEnter the id for search : ");
    scanf("%u",&id);
    for(int i=0;i<c;i++){
        if(v[i].emp_id==id)
        {
           printf("Employee id     : %u\n",v[i].emp_id);
           printf("Employee name   : %s\n",v[i].emp_name);
           printf("Employee salary : %.2lf\n",v[i].salary);
           printf("Join year       : %hd\n",v[i].join_year);
           break;
        }
    }
}
void max_service(struct emp v[])
{
    int arr[3],current_y,temp;
    printf("\nEnter the current year : ");
    scanf("%d",&current_y);
    for(int i=0;i<c;i++){
        arr[i]=(current_y-v[i].join_year);
    }
    temp=arr[0];
    for(int i=0;i<c;i++){
        if(temp<arr[i]){
            temp=arr[i];
        }
    }
    printf("The maximum service is = %d\n",temp);
}
void min_service(struct emp v[])
{
    int arr[3],current_y,temp;
    printf("\nEnter the current year : ");
    scanf("%d",&current_y);
    for(int i=0;i<c;i++){
        arr[i]=(current_y-v[i].join_year);
    }
    temp=arr[0];
    for(int i=0;i<c;i++){
        if(temp>arr[i]){
            temp=arr[i];
        }
    }
    printf("The minimum service is = %d\n",temp);
}