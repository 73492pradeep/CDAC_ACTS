#include<stdio.h>
#include<stdlib.h>
struct node{
	   int data;
	   struct node *next;
           };
void insert();
void rev_list();
void display();
struct node *head=NULL;
int main()
{
	int choice;
	while(1){
		printf("\nEnter the choice :\n1->insert\n2->rev_list\n3->display\n0->exit :");
		scanf("%d",&choice);
		switch(choice){
			case 1:
				insert();
				break;
			case 2:
				rev_list();
				break;
			case 3:
				display();
				break;
			case 4:
				rev();
				break;
			case 0:
				exit(0);
		}
	}
	return 0;
}
void rev()
{
	int c=0;
	struct node *t1,*t2=head;
    while(t2!=NULL){
		t2=t2->next;
		c++;
	}
	for(int i=0;i<c;i++){
		t1=head;
		for(int j=0;j<c-i-1;j++){
			t1=t1->next;
		}
		printf("-->|%d|",t1->data);
	}
}
void insert()
{
	int ele;
	printf("Enter the ele for insert : ");
	scanf("%d",&ele);
	struct node *temp=NULL;
	struct node *trav=head;
	temp=(struct node*)malloc(sizeof(struct node));
	if(temp==NULL){
		printf("malloc is failed");
	}
	temp->data=ele;
	temp->next=NULL;
	if(head==NULL){
		head=temp;
	}else{
		while(trav->next!=NULL){
			trav=trav->next;
		}
		trav->next=temp;
	}
}
void rev_list()
{
	struct node *prev,*trav=head;
	prev=NULL;
	if(head==NULL){
		return;
	}else{
		while(trav!=NULL){
			trav=trav->next;
			head->next=prev;
			prev=head;
			head=trav;
		}
		head=prev;
	}
}
void display()
{
	struct node *temp=head;
	while(temp!=NULL){
		printf("-->|%d|",temp->data);
		temp=temp->next;
	}
}


