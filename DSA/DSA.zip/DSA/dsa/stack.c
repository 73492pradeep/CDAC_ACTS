#include<stdio.h>
#include<stdlib.h>
#define SIZE 5
void pussEle(int arr[],int *p,int e);
void popEle(int arr[],int *d);
void display(int arr[]);
int main()
{
    int arr[SIZE],ele;
    int top=-1,choice;
    for(int i=0;i<SIZE;i++){
        arr[i]=-99;
    }
    while(1){
        printf("\nEnter the choice :\n1->pussEle\n2->popEle\n3->display\n0->exit : ");
        scanf("%d",&choice);
        switch(choice){
            case 1:
                   printf("Enter the ele for add : ");
                   scanf("%d",&ele);
                   pussEle(arr,&top,ele);
                   break;
            case 2:
                   popEle(arr,&top);
                   break;
            case 3:
                   display(arr);
                   break;
            case 0:
                   exit(0);
        }
    }
}
void pussEle(int arr[],int *p,int e)
{
    if(*p==SIZE-1){
        printf("Stack is full\n");
    }else{
    (*p)++;
    arr[*p]=e;
    }
}
void popEle(int arr[],int *d)
{
     if(*d==-1){
        printf("Stack is empty\n");
     }else{
    printf("Pop ele is = %d\n",arr[*d]);
    arr[*d]=-99;
    (*d)--;
    }
}
void display(int arr[])
{
    for(int i=0;i<SIZE;i++){
        printf("%d ",arr[i]);
    }
}
