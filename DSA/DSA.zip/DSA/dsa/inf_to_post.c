#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define MAX 20
int stack[MAX];
char infix[MAX],postfix[MAX];
int top=-1;
void inTopost();
void display();
int precedence(char c);
int space(char c);
int isEmpty();
void push(char c);
char pop();
int main()
{
    printf("Enter the infix expretion :\n");
    gets(infix);
    for(int i=0;i<strlen(infix);i++){
        printf("%c",infix[i]);
    }
    inTopost();
    printf("\nThe postfix expretion is :\n");
    display();
    int x=strlen(postfix);
    for(int i=x-1;i>=0;i--){
        printf("%c",postfix[i]);
    }
    return 0;
}
void inTopost()
{
    int i,j=0;
    char symbol,next;
    for(i=0;i<strlen(infix);i++){
        symbol=infix[i];
        if(!space(symbol)){
        switch(symbol){
            case '(':
                     push(symbol);
                     break;
            case ')':
                     while((next=pop())!='(')
                         postfix[j++]=next;
                     break;
            case '+':
            case '-':
            case '*':
            case '/':
            case '^':
                     while(!isEmpty()&&precedence(stack[top])>=precedence(symbol))
                         postfix[j++]=pop();
                         push(symbol);
                         break;
            default:
                         postfix[j++]=symbol;
                         break;
        }
        }
    }
        while(!isEmpty())
        postfix[j++]=pop();
        postfix[j]='\0';
}
int precedence(char c)
{
    switch(c){
        case '^':
                 return 3;
        case '*':
        case '/':
                 return 2;
        case '+':
        case '-':
                 return 1;
        default:
                 return 0;
    }
}
void push(char c)
{
    if(top==MAX-1){
        printf("stack is full\n");
        return;
    }
    top++;
    stack[top]=c;
}
char pop()
{
    if(top==-1){
        printf("stack is empty\n");
        exit(1);
    }
    char c=stack[top];
    top--;
    return c;
}
int isEmpty()
{
    if(top==-1)
    return 1;
    else
    return 0;
}
int space(char c)
{
    if(c==' '||c=='\t')
    return 1;
    else
    return 0;
}
void display()
{
    for(int i=0;i<strlen(postfix);i++){
        printf("%c",postfix[i]);
    }
    printf("\n");
}