//linear search
#include<stdio.h>
int linear_search(int arr[],int x,int i,int ele);
int main()
{
	int ele,x,a;
	printf("enter the ele : ");
	scanf("%d",&ele);
	int arr[]={2,3,5,6,1,9,1,4,11,22,33,44,55,66};
	x=(sizeof(arr)/4);
	a=linear_search(arr,x,0,ele);
	printf("The element %d is found at pos %d\n",ele,a);
	return 0;
}
int linear_search(int arr[],int x,int i,int ele)
{
	if(i<x){
		if(arr[i]==ele){
			return i;
		}
		else{
			linear_search(arr,x,++i,ele);
		}
	}
}
		
