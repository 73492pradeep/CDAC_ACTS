/*Q1. Write a C/C++ program to implement below mentioned Searching
and Sorting Techniques.
(a) Bubble Sort
(b) Selection Sort
(c) Insertion Sort*/

#include<stdio.h>
#define SWAP(a,b) {int t=a;a=b;b=t;}  //micro defines fof swapping
#define SIZE 6
//function decleratioin
void bubble_sort(int arr[]);
void selection_sort(int arr[]);
void insertion_sort( int arr[]);
void display(int arr[]);
//main function
int main()
{
    int arr[SIZE]={60,50,40,30,20,10}; //array declearation + initialization
    printf("-----befor sorting ------\n");
    display(arr);             //function call
    bubble_sort(arr);       //function call
    //selection_sort(arr);    //function call
    //insertion_sort(arr);      //function call
    printf("\n-----after sorting ------\n");
    display(arr);             //function call
    return 0;
}
//function definition for bubble sort
void bubble_sort(int arr[SIZE])
{
    int flag=1;
    int iterations=0,comparisons=0;
    for(int i=0;i<SIZE-1&&flag==1;i++){  
        iterations++;
        flag=0;
        for(int j=0;j<SIZE-i-1;j++){
            comparisons++;
            if(arr[j]>arr[j+1]){
                SWAP(arr[j],arr[j+1]);
                flag=1;
            }
        }
    }
    printf("number of iterations are %d\n",iterations); 
    printf("number of Comparisons are %d\n",comparisons);
}
//function definition for selection sort
void selection_sort(int arr[])
{
    int iterations=0,comparisons=0;
    for(int i=0;i<SIZE-1;i++){
        iterations++;
        for(int j=i+1;j<SIZE;j++){
            comparisons++;
            if(arr[i]>arr[j]){
                SWAP(arr[i],arr[j]);
            }
        }
    }
    printf("number of iterations are %d\n",iterations); 
    printf("number of Comparisons are %d\n",comparisons);
}
//function definition for insertion sort
void insertion_sort( int arr[])
{
    int i; 
    int while_cnt = 0; 
    int iterations = 0; 
    for( i = 1; i < SIZE ; i++)
    {
        int j = i - 1; 
        int key = arr[i]; 
        
        while( j>=0 && key < arr[j])
        {
           arr[j+1] = arr[j]; 
           j--; 
        } 
        arr[j+1]=key; 
    }
}
//function definition for display
void display(int arr[SIZE])
{
    for(int i=0;i<SIZE;i++){
        printf("%d ",arr[i]);
    }
}
