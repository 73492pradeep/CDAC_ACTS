#include<stdio.h>
#include<stdlib.h>
int main()
{
    int *a[3];
    int r=3,c=3;
    for(int i=0;i<r;i++){
        a[i]=(int*)malloc(sizeof(int)*c);
    }
    if(a==NULL){
        printf("Malloc is failed \n");
    }
    printf("Enter the element \n");
    for(int i=0;i<r;i++){
        for(int j=0;j<r;j++){
            scanf("%d",&a[i][j]);
        }
    }
    for(int i=0;i<r;i++){
        for(int j=0;j<r;j++){
            printf("%d ",a[i][j]);
        }
    }
    for(int i=0;i<c;i++){
        free(a[i]);
    }
}