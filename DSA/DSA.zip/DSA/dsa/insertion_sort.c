#include<stdio.h>
#define MAX 10
void insertion_sort(int arr[],int n);
int main()
{
    int arr[MAX]={6,5,7,8,9,2,4,3,1,10};
    insertion_sort(arr,MAX-1);
    for(int i=0;i<MAX;i++){
        printf("%d ",arr[i]);
    }
    return 0;
}
void insertion_sort(int arr[],int n)
{
    //for(int i=1;i<MAX;i++){
        if(n<=1){
            return;
        }
        insertion_sort(arr,n-1);
        int temp=arr[n-1];
        int j=n-2;
        while(j>=0&&arr[j]>temp){
            arr[j+1]=arr[j];
            j--;
        }
        arr[j+1]=temp;
    //}
}