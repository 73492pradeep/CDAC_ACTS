#include<stdio.h>
#define MAX 9
#define SWAP(a,b) {int t=a;a=b;b=t;}
int partition(int arr[],int l,int up);
void quickSort(int arr[],int a,int b);
void display(int arr[]);
int main()
{
    int arr[MAX] = {5,4,6,2,3,7,2,1,11};
    display(arr);
    quickSort(arr,0,MAX-1);
    printf("\n");
    display(arr);
    return 0;
}
void display(int arr[])
{
    for(int i=0;i<MAX;i++){
        printf("%d ",arr[i]);
    }
}
void quickSort(int arr[],int low,int high)
{
    int x;
    if(low<high){
        x = partition(arr,low,high);
        quickSort(arr,low,(x-1));
        quickSort(arr,(x+1),high);
    }
}
int partition(int arr[],int l,int up)
{
    int pivot=arr[l];
    int start=l,end=up;
    while(start<end){
        while(arr[start]<=pivot){
            start++;
        }
        while(arr[end]>pivot){
            end--;
        }
        if(start<end){
            SWAP(arr[start],arr[end]);
        }
    }
    SWAP(arr[l],arr[end]);
    return end;
}