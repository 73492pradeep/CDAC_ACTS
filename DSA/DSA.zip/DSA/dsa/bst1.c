#include<stdio.h>
#include<stdlib.h>
struct node{
    struct node *left;
    int data;
    struct node *right;
};
void insert(struct node **p,int ele);
void inorder(struct node *p);
void priorder(struct node *p);
void postorder(struct node *p);
int main()
{
    struct node *root=NULL;
    int choice, ele;
    while(1){
        printf("\nEnter the choice :\n1->insert\n2->inorder\n3->priorder\n4->postorder\n0->exit : ");
        scanf("%d",&choice);
        switch(choice){
            case 1:
                   printf("\nEnter the element : ");
                   scanf("%d",&ele);
                   insert(&root,ele);
                   break;
            case 2:
                   inorder(root);
                   break;
            case 3:
                   priorder(root);
                   break;
            case 4:
                   postorder(root);
                   break;
            case 0:
                   exit(0);
        }
    }
}
void postorder(struct node *p)
{
    if(p!=NULL){
        postorder(p->left);
        postorder(p->right);
        printf("%d ",p->data);
    }
}
void priorder(struct node *p)
{
    if(p!=NULL){
        printf("%d ",p->data);
        priorder(p->left);
        priorder(p->right);
    }
}
void inorder(struct node *p)
{
    if(p!=NULL){
        inorder(p->left);
        printf("%d ",p->data);
        inorder(p->right);
    }
}
void insert(struct node **p,int ele)
{
    if((*p)==NULL){
        *p=(struct node *)malloc(sizeof(struct node));
        (*p)->data=ele;
        (*p)->left=NULL;
        (*p)->right=NULL;
    }else{
        if(ele<(*p)->data){
            insert(&((*p)->left),ele);
        }else{
            insert(&((*p)->right),ele);
        }
    }
}