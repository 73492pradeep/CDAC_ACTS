#include<stdio.h>
#define MAX 6
int binary(int arr[]);
int main()
{
    int x;
    int arr[MAX]={1,2,3,4,5,6};
    x=binary(arr);
    printf("index =%d\n",x);
    return 0;
}
int binary(int arr[])
{
    int ele,pos=0,mid;
    printf("Enter the ele : ");
    scanf("%d",&ele);
    int start=0,end=MAX-1;
    //mid=start+(end-start)/2;
    while(start<=end){
        mid=(end+start)/2;
        if(arr[mid]==ele){
            pos= mid;
        }
            if(ele>arr[mid]){
                start=mid+1;
            }else{
                end=mid-1;
            }
    }
    if(arr[pos]==ele)
	   printf("\nThe ele %d Found at Index =  %d\n",ele,pos);
}
