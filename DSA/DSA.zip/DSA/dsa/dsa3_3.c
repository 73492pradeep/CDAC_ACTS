/*Q3. Write a C/C++ program to implement single linked list in sorted
order. Implement below metioned functions. Apply all required
condition check & validation like list empty or not, while
inserting/deleting by position validate the position. Implement a policy
for duplicate value input.
a)insert b) displayList c)listNodeCount d) deleteFromEnd
e) deleteFromBeg f)deleteFromPos g) reverseDisplay*/

// structure member
#include<stdio.h>
#include<stdlib.h>
struct node{
	   int data;
	   struct node *next;
           };
// function decleration
int insert();
void sort_list();
void display_list();
void list_count();
void deletFromEnd();
void deletFromBeg();
void deletFromPos(int pos);
void rev_display();
void freeAllNode();
struct node *head=NULL;
int main()
{
	int choice,x,pos=0;
	while(1){          //loop will run infinite times until press 0
		printf("\nEnter the choice :\n1->insert\n2->display\n3->list_count\n4->deletFromEnd\n5->deletFromBeg\n6->deletFromPos\n7->rev_display\n8->freeAllNode\n0->exit :");
		scanf("%d",&choice);
		switch(choice){    // switch case will help to chose oprration
			case 1:
				x=insert();               //function call
				if(x==1){
					printf("You have entered duplicate ele");
				}
				sort_list();               //function call
				break;
			case 2:
				display_list();              //function call
				break;
			case 3:
				list_count();                 //function call
				break;
			case 4:
				deletFromEnd();                //function call
				break;
			case 5:
				deletFromBeg();                //function call
				break;
			case 6:
				printf("\nEnter the pos for delet : ");
				scanf("%d",&pos);
				deletFromPos(pos);              //function call
				break;
			case 7:
				rev_display();                  //function call
				break;
			case 8:
				freeAllNode();                   //function call
				break;
			case 0:
				exit(0);
		}
	}
	freeAllNode();                     //it will free all node
    free(head);                        //it will free head
	return 0;
}
// function definition
// user can add info at beg
int insert()
{
	int ele;
	printf("Enter the ele for insert : ");
	scanf("%d",&ele);
	struct node *temp=NULL;
	struct node *dup=NULL;
	temp=(struct node*)malloc(sizeof(struct node));   //allocated memory in  heap section for struct member
	if(temp==NULL){
		printf("malloc is failed");
	}
	temp->data=ele;
	temp->next=NULL;
	if(head==NULL){
		head=temp;
	}
	else{
	     dup=head;
  	      while(dup!=NULL){         //it will check duplicate prn
	            if(dup->data==temp->data){
	                   return 1;
		    }
	       	    dup=dup->next;
	      }
	      temp->next=head;        //new linklist wil add with linklist
	      head=temp;
       }
}
//this function will sort the list
void sort_list()
{
	int temp;
	struct node *t1,*t2=NULL;
	t1=head;
	if(head==NULL){
		return;
	}else{
		while(t1!=NULL){
			t2=t1->next;
			while(t2!=NULL){
				if(t1->data>t2->data){
					temp=t1->data;
					t1->data=t2->data;
					t2->data=temp;
				}t2=t2->next;
			}t1=t1->next;
		}
	}
}
// function definition
// it will display all linklist
void display_list()
{
	struct node *temp=head;
	if(head==NULL){
           printf("List is empty");
	}else{
	     while(temp!=NULL){
		printf("-->|%d|",temp->data);
		temp=temp->next;
             }
	}
}
//function definition
//It will count the linklist
void list_count()
{
	int count=0;
	struct node *temp=head;
	if(head==NULL){
		return;
	}
	while(temp!=NULL){
		count++;
		temp=temp->next;
	}
	printf("No.of link list is = %d\n",count);
}
//function definition
//user can delet linklist from end
void deletFromEnd()
{
	struct node *t1,*t2=NULL;
	t1=head;
	if(head==NULL){
		return;
	}
	while(t1->next!=NULL){
		t2=t1;
		t1=t1->next;
	}
	t2->next=t1->next;
	free(t1);
}
//function definition
//user can delet linklist from Beg
void deletFromBeg()
{
	struct node *t1=head;
	if(head==NULL){
		return;
	}
	head=head->next;
	free(t1);
}
//function definition
//user can delet linklist from pos
void  deletFromPos(int pos)
{
	int count=1;
	struct node *t1,*t2=NULL;
	t1=head;
	t2=t1->next;
	if(head==NULL){
		return;
	}
	if(pos==1){
		deletFromBeg();
	}else{
		while(count<pos-1){
			count++;
			t1=t2;
			t2=t2->next;
		}
		t1->next=t2->next;
		free(t2);
	}
}
//function definition
//it will reverse the linklist
void rev_display()
{
	int arr[10];
	int k=0;
	struct node *trav=head;
	if(head==NULL){
		return;
	}
	while(trav!=NULL){
		arr[k]=trav->data;
		trav=trav->next;
		k++;
	}
	for(int i=k-1;i>=0;i--){
		printf("-->|%d|",arr[i]);
	}
}
//function definition
//it will free all linklist
void freeAllNode()
{
	struct node *trav=head;
	if(head==NULL){
		return;
	}
	while(trav!=NULL){
		head=trav->next;
		free(trav);
		trav=head;
	}
}
