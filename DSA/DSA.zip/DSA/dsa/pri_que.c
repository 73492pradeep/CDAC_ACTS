#include<stdio.h>
#include<stdlib.h>
void enqueue(int a[],int ele);
void dequeue(int a[]);
void display(int arr[]);
#define MAX 5
int f=-1,r=-1,choice;
int main()
{
    int a[MAX],ele;
    for(int i=0;i<MAX;i++){
        a[i]=-99;
    }
    while(1){
        printf("\nEnter the choice :\n1->enqueue\n2->dequeue\n3->display\n0->exit : ");
        scanf("%d",&choice);
        switch(choice){
            case 1:
                   printf("Enter the ele for enqueue : ");
                   scanf("%d",&ele);
                   enqueue(a,ele);
                   break;
            case 2:
                   dequeue(a);
                   break;
            case 3:
                   display(a);
                   break;
            case 0:
                   exit(0);
        }
    }
}
void enqueue(int a[],int ele)
{
    if(r==MAX-1){
        printf("Queue is full\n");
        return;
    }
    if(r==-1){
        r++;
        a[r]=ele;
        if(f==-1){
            f=0;
        }
    }else if(a[r]>ele){
    int p=r;
    r++;
                while(a[p]>ele){
                    a[p+1]=a[p];
                    a[p]=ele;
                    p--;
                }
    }else{
        r++;
        a[r]=ele;  
    }
}
void dequeue(int a[])
{
    if(f==-1){
        printf("Queue is empty\n");
        return;
    }
    printf("Dequeue ele is = %d\n",a[f]);
    a[f]=-99;
    if(f==r){
        f=-1;
        r=-1;
    }else{
        f++;
    }
}
void display(int arr[])
{
    for(int i=0;i<MAX;i++){
        printf("%d ",arr[i]);
    }
}