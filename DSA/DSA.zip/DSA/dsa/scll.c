#include<stdio.h>
#include<stdlib.h>
struct node{
	       int data;
	       struct node *next;
           };
void display_list();
void insertAtBeg();
void insertAtPos();
void insertAtEnd();
void deletFromBeg();
void deletFromEnd();
void deletFromPos();
void deletByElement();
void rev_display();
void sortedList();
void rev_list();
void freeAllNode();
struct node *head=NULL;
int main()
{
	int choice;
	while(1){         
	printf("\nEnter the choice :\n1->display\n2->insertAtBeg\n3->insertAtPos\n4->insertAtEnd\n5->deletFromBeg\n6->deleatFromEnd\n7->deletFromPos\n8->deletByElement\n9->rev_Display\n10->sortedList\n11->rev_list\n12->freeAllNode\n0->exit : ");
	scanf("%d",&choice);
	switch(choice){    
	        case 1:
			    display_list();    
			    break;
	        case 2:
			    insertAtBeg();       
			    break;
		    case 3:
			    insertAtPos();        
			    break;
		    case 4:
			    insertAtEnd();        
			    break;
		    case 5:
			    deletFromBeg();         
			    break;
		    case 6:
			    deletFromEnd();         
			    break;
		    case 7:
			    deletFromPos();           
			    break;
		    case 8:
			    deletByElement();         
			    break;
			case 9:
			    rev_display();             
			    break;
			case 10:
				sortedList();              
				break;
			// case 11:
			// 	rev_list();                 
			// 	break;
			case 12:
				freeAllNode();              
				break;
		    case 0:
			    exit(0);
	}
	}
	freeAllNode();                 
	free(head);                     
	return 0;
}
void display_list()
{
	struct node *trav=head;
	if(head==NULL){
		return;
	}else{
	      while(trav->next!=head){
		        printf("-->|%d|",trav->data);
		        trav=trav->next;
	        }
	    printf("-->|%d|",trav->data);
	}
}
void insertAtBeg()
{
	int ele;
	printf("Enter the ele addAtBeg : ");
	scanf("%d",&ele);
	struct node *temp,*t1=head;
	temp=(struct node*)malloc(sizeof(struct node));   
	temp->data=ele;
	temp->next=NULL;
	if(head==NULL){
		head=temp;
		temp->next=head;
	}else{
		while(t1->next!=head){
			t1=t1->next;
		}
		temp->next=head;
		t1->next=temp;
		head=temp;
	}
}
void insertAtEnd()
{
	int ele;
	printf("Enter the ele addAtEnd : ");
	scanf("%d",&ele);
	struct node *temp,*trav;
	trav=head;
	temp=(struct node*)malloc(sizeof(struct node));    
	temp->data=ele;
	temp->next=NULL;
	if(head==NULL){
		head=temp;
		temp->next=head;
	}
	else{
		while(trav->next!=head){
			trav=trav->next;
		}
		trav->next=temp;
		temp->next=head;
	}
}
void insertAtPos()
{
	int ele,pos,count=1;
	printf("Enter the pos : ");
	scanf("%d",&pos);
	if(pos==1){
		insertAtBeg();
	}else{
	printf("Enter the ele addAtPos : ");
	scanf("%d",&ele);
	struct node *temp,*t1=head;
	struct node *t2=NULL;
	t2=t1->next;
	temp=(struct node*)malloc(sizeof(struct node));    
	temp->data=ele;
	temp->next=NULL;
	while(count<pos-1){
		t1=t2;
		t2=t2->next;
		count++;
	}
		temp->next=t1->next;
		t1->next=temp;
}
}
void deletFromBeg()
{
	struct node *t1,*trav=head;
	t1=head;
	if(head==NULL){
            return;
	}
	while(trav->next!=head){
		trav=trav->next;
	}
	head=t1->next;
	trav->next=head;
	free(t1);
}
void deletFromEnd()
{
	struct node *t1,*t2=NULL;
	t1=head;
	t2=t1->next;
	if(head==NULL){
		return;
	}else{
		while(t2->next!=head){
			t1=t2;
			t2=t2->next;
		}
		t1->next=t2->next;
		free(t2);
	}
}
void deletFromPos()
{
	int pos,count=1;
	printf("Enter the pos for deletFromPos : ");
	scanf("%d",&pos);
	struct node *trav=head;
	struct node *trav1=NULL;
	trav1=trav->next;
	if(pos==1){
		deletFromBeg();
	}else{
		while(count<pos-1){
			trav=trav1;
			trav1=trav1->next;
			count++;
		}
		trav->next=trav1->next;
		free(trav1);
	}
}
void deletByElement()
{
	int ele;
	printf("Entter the ele for deletByElement : ");
	scanf("%d",&ele);
	struct node *temp=head;
	struct node *temp1=head;
	if(head==NULL){
		return;
	}
	if(head->data==ele){
		 while(temp->next!=head){    
		        temp=temp->next;
		  } 
		  head=temp1->next;
		  temp->next=head;
		  free(temp1);
	}else{
          while(temp->data!=ele){
		        temp1=temp;     
		        temp=temp->next;
		  } 
		    temp1->next=temp->next;
		    free(temp);
		  }
}
void rev_display()
{
	int k=1;
	struct node *trav=head;
	struct node *t1=NULL;
	if(head==NULL){
		return;
	}
	while(trav->next!=head){
		trav=trav->next;
		k++;
	}
	for(int i=0;i<k;i++){
		t1=head;
		for(int j=0;j<k-i-1;j++){
			t1=t1->next;
		}
		printf("-->|%d|",t1->data);
	}
}
void sortedList()
{
	int temp;
	struct node *t1,*t2=NULL;
	if(head==NULL){
		return;
	}
	t1=head;
    while(t1->next!=head){
		t2=t1->next;
	       while(t2!=head){
		         if(t1->data>t2->data){
			        temp=t1->data;
			        t1->data=t2->data;
                    t2->data=temp;
		         }
				 t2=t2->next;
	        }
			t1=t1->next;
	}
}
void rev_list()
{
	struct node *prev,*trav=head;
	struct node *t1=head;
	prev=NULL;
	if(head==NULL){
		return;
	}else{
		while(trav->next!=head){
			trav=trav->next;
			head->next=prev;
			prev=head;
			head=trav;
		}
		trav->next=prev;
		t1->next=trav;
		//prev=NULL;
	}
	//printf("%u %u\n",head,t1->next);
}
void freeAllNode()
{
	struct node *t1,*trav=head;
	t1=head;
	if(head==NULL){
		return;
	}else{
	while(t1->next!=trav){
		head=t1->next;
		free(t1);
		t1=head;
	}
	free(t1);
	head=NULL;
	}
}


	



