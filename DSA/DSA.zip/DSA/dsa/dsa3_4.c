/*Q4. Write a C/C++ program to implement single linked list to store
Student Information ( StudentName and StudentPRN).
Implement below metioned functions. Apply all required condition
check & validation like list empty or not, while inserting/deleting by
position validate the position.
a)insertAtEnd b) insertAtBeg c) insertAtPos d) displayList
e)listNodeCount
f) deleteFromEnd
g) deleteFromBeg
h)deleteFromPos
i) deleteByElement j) reverseDisplay
k)freeAllNode*/
#include<stdio.h>    
#include<stdlib.h>
// structure member
struct stud{                 
	   char *std_name;         
	   unsigned int std_prn;  
	   struct stud *next;     
           };
//function decleration
int insertAtBeg();
int insertAtEnd();
int insertAtPos();
void display_list();
void list_count();
void deletFromEnd();
void deletFromBeg();
void deletFromPos(int pos);
void rev_display();
void freeAllNode();
void deletByElement();
struct stud *head=NULL;
int main()
{
	int choice,x,pos=0;
	while(1){             //loop will run infinite times until press 0
		printf("\nEnter the choice :\n1->insertAtBeg\n2->display\n3->list_count\n4->deletFromEnd\n5->deletFromBeg\n6->deletFromPos\n7->rev_display\n8->freeAllNode\n9->deletByElement\n10->insertAtEnd\n11->insertAtPos\n0->exit :");
		scanf("%d",&choice);
		switch(choice){    // switch case will help to chose oprration
			case 1:
			        x=insertAtBeg();           //function call
				if(x==1){
					printf("You have entered duplicate PRN No. ");
				}
				break;
			case 2:
				display_list();                  //function call
				break;
			case 3:
				list_count();                    //function call
				break;
			case 4:
				deletFromEnd();                    //function call
				break;
			case 5:
				deletFromBeg();                    //function call
				break;
			case 6:
				printf("\nEnter the pos for delet : ");
				scanf("%d",&pos);
				deletFromPos(pos);                   //function call
				break;
			case 7:
				rev_display();                     //function call
				display_list();                     //function call
				break;
			case 8:
				freeAllNode();                      //function call
				break;
			case 9:
				deletByElement();                    //function call
				break;
			case 10:
				insertAtEnd();                       //function call
				break;
			case 11:
				insertAtPos();                       //function call
				break;
			case 0:
				exit(0);
		}
	}
	freeAllNode();
	free(head);
	return 0;
}
// function definition
// user can insert info at beg
int insertAtBeg()
{
	char *name;
	int prn1;
	name=(char*)malloc(sizeof(char));    //allocated memory in heap section
	printf("Enter the Name : ");
	scanf("%s",name);
	printf("Enter the PRN  : ");
	scanf("%d",&prn1);
	struct stud *temp=NULL;
	struct stud *dup=NULL;
	temp=(struct stud*)malloc(sizeof(struct stud));  //allocated memory in  heap section for struct member
	if(temp==NULL){
		printf("malloc is failed");
	}
	temp->std_name=name;
	temp->std_prn=prn1;
	temp->next=NULL;
	if(head==NULL){
		head=temp;
	}
	else{
	     dup=head;
  	      while(dup!=NULL){             //it will check duplicate prn
	            if(dup->std_prn==temp->std_prn){
	                   return 1;
		    }
	       	    dup=dup->next;
	      }
	      temp->next=head;     //new linklist wil add with linklist
	      head=temp;
       }
}
//function definition
//user can insert info at end pos
int insertAtEnd()
{
	char *name;
	int prn1;
	name=(char*)malloc(sizeof(char));     //allocated memory for user name in heap
	printf("Enter the Name : ");
	scanf("%s",name);
	printf("Enter the PRN  : ");
	scanf("%d",&prn1);
	struct stud *temp=NULL;
	struct stud *trav=head;
	struct stud *dup=NULL;
	temp=(struct stud*)malloc(sizeof(struct stud));  //allocated memory in heap section for now list 
	if(temp==NULL){
		printf("malloc is failed");
	}
	temp->std_name=name;
	temp->std_prn=prn1;
	temp->next=NULL;
	if(head==NULL){
		head=temp;
	}
	else{
	     dup=head;
  	      while(dup!=NULL){       // it will check duplicate prn
	            if(dup->std_prn==temp->std_prn){
	                   return 1;
		    }
	       	    dup=dup->next;
	      }
	      while(trav->next!=NULL){   //new linklist will add with linklist
		      trav=trav->next;
	      }
	      trav->next=temp;
       }
}
//function defition 
//user can insert at pos in linklist
int insertAtPos()
{
	char *name;
	int prn1,pos=0,count=1;
	name=(char*)malloc(sizeof(char));    // memory allocated in heap section for name
	printf("Enter the pos for addAtPos  : ");
	scanf("%d",&pos);
        if(pos==1){
		insertAtBeg();
	}else{
	printf("Enter the Name : ");
	scanf("%s",name);
	printf("Enter the PRN  : ");
	scanf("%d",&prn1);
	struct stud *temp=NULL;
	struct stud *dup=NULL;
	struct stud *t1,*t2=NULL;
	t1=head;
	t2=t1->next;
	temp=(struct stud*)malloc(sizeof(struct stud));  //memory allocated in heap section for new linklist
	if(temp==NULL){
		printf("malloc is failed");
	}
	temp->std_name=name;
	temp->std_prn=prn1;
	temp->next=NULL;
	if(head==NULL){
		head=temp;
	}
	else{
	     dup=head;
  	      while(dup!=NULL){         // it will check duplicate prn
	            if(dup->std_prn==temp->std_prn){
	                   return 1;
		    }
	       	    dup=dup->next;
	      }
	      while(count<pos-1){
		      t1=t2;
		      t2=t2->next;
		      count++;
	      }
	      temp->next=t1->next;
	      t1->next=temp;
       }
      }
}
// function definition
// it will print all linklist
void display_list()
{
	struct stud *t;
	t=head;
	if(head==NULL){
           printf("There is no student's list\n");
	}else{
	     while(t!=NULL){
		printf("Student name : %s\n",t->std_name);
		printf("Student prn  : %d\n",t->std_prn);
		t=t->next;
             }
	}
}
//function definition
//It will count the linklist
void list_count()
{
	int count=0;
	struct stud *temp=head;
	if(head==NULL){
		return;
	}
	while(temp!=NULL){
		count++;
		temp=temp->next;
	}
	printf("No.of student's list is = %d\n",count);
}
//function definition
//user can delet linklist from end
void deletFromEnd()
{
	struct stud *t1,*t2=NULL;
	t1=head;
	if(head==NULL){
		return;
	}
	while(t1->next!=NULL){
		t2=t1;
		t1=t1->next;
	}
	t2->next=t1->next;
	free(t1);
}
//function definition
//user can delet linklist from Beg
void deletFromBeg()
{
	struct stud *t1=head;
	if(head==NULL){
		return;
	}
	head=head->next;
	free(t1);
}
//function definition 
//user can delet linklist from pos
void  deletFromPos(int pos)
{
	int count=1;
	struct stud *t1,*t2=NULL;
	t1=head;
	t2=t1->next;
	if(head==NULL){
		return;
	}
	if(pos==1){
		deletFromBeg();
	}else{
		while(count<pos-1){
			count++;
			t1=t2;
			t2=t2->next;
		}
		t1->next=t2->next;
		free(t2);
	}
}
//function definition
//it will reverse the linklist
void rev_display()
{
	struct stud *prev,*trav=head;
	prev=NULL;
	if(head==NULL){
		return;
	}else{
		while(trav!=NULL){
			trav=trav->next;
			head->next=prev;
			prev=head;
			head=trav;
		}
		head=prev;
	}
}
//function definition
//it will free all linklist
void freeAllNode()
{
	struct stud *trav=head;
	if(head==NULL){
		return;
	}
	while(trav!=NULL){
		head=trav->next;
		free(trav);
		trav=head;
	}
}
//function definition
//it will delet by entering the ele
void deletByElement()
{
	int p;
	printf("Enter the PRN for delet : ");
	scanf("%d",&p);
	struct stud *t1,*t2=NULL;
	t1=head;
	t2=t1->next;
	if(head->std_prn==p){
		head=t1->next;
		free(t1);
	}else{
		while(t2!=NULL){
			if(t2->std_prn==p){
				t1->next=t2->next;
				free(t2);
			}
			t1=t2;
			t2=t2->next;
		}
	}
}
